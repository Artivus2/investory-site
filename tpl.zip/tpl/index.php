<!doctype html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
        <title>Fxartinvest</title>
        <link href="style/main/normalize.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/bootstrap-grid.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/owl.carousel.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/owl.theme.default.css" rel="stylesheet" type="text/css"/>
        <link href="style/css/style.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/Roboto/Roboto.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
    </head> 
    <body>
        <header>
            <div class="top-header">
                <div class="container">
                    <div class="row">
                        <div class="top__header-left col-md-6">
                            <ul class="top__header-left-list">
                                <li class="top__header-left-item"><a href="#" class="top__header-left-item-active">Главная</a></li>
                                <li class="top__header-left-item"><a href="#">О компании</a></li>
                                <li class="top__header-left-item"><a href="#">Инвестиции</a></li>
                                <li class="top__header-left-item"><a href="#">Партнеру</a></li>
                                <li class="top__header-left-item"><a href="#">Вебинары</a></li>
                                <li class="top__header-left-item"><a href="#">Контакты</a></li>
                            </ul>
                        </div>
                        <div class="top__header-right offset-sm-2 col-md-4">
                            <div class="dropdown">
                                <div class="dropbtn">Русский</div>
                                <div class="dropdown-content">
                                    <a href="#">English</a>
                                </div>
<!--                                <a href="#" id="select">
                                    <img src="images/header-icon-russia.png" alt="Русская версия"/>
                                    Русский
                                    <img src="images/header-icon-arrow.png" alt=""/>
                                </a>
                                <a href="#" class="d-none">
                                    <img src="images/header-icon-united-kingdom.png" alt=""/>
                                    Англизкий
                                </a>-->
                            </div>
                            <div class="top__header-right-lk">
                                <a href="#" class="cabinet">
                                    <img src="images/header-icon-unclock.png" alt=""/>
                                    Личный кабинет
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <nav>
                <div class="container">
                    <div class="row">
                        <div class="nav__logo col-md-3">
                            <a href="#">
                                <img src="images/logo.png" alt="">
                            </a>
                        </div>
                        <div class="header__menu col-md-7">
                            <ul class="header__menu-nav-list">
                                <li class="nav__item"><a href="#" class="nav__item-active">Инвестиции</a></li>
                                <li class="nav__item"><a href="#">Партнеру</a></li>
                                <li class="nav__item"><a href="#">Вебинары</a></li>
                                <li class="nav__item"><a href="#">Условия использования</a></li>
                            </ul> 
                        </div>
                        <div class="header__social col-md-2">
                            <ul class="social__list">
                                <li><a href="#" target="blank"><i class="fab fa-vk"></i></a></li>
                                <li><a href="#" target="blank"><i class="fab fa-tg"></i></a></li>
                                <li><a href="#" target="blank"><i class="fab fa-vk"></i></a></li>
                                <li><a href="#" target="blank"><i class="fab fa-vk"></i></a></li>
                            </ul>
                        </div>

                    </div>

                </div>

            </nav>
        </header>
        <div class="section__1">
            <div class="owl-carousel owl-theme">
                <div class="item" style="background-image: url(images/section-bg-1.jpg);">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12 content__slide">
                                <h1>Истинное стремление к саморазвитию</h1>
                                <p>Сделайте вашу торговлю более эффективной!  Внесите депозит прямо сейчас и получите 100% бонус на ваш Торговый счет</p>
                                <a href="#" class="btn__green">Инвестировать сейчас</a>
                            </div>
                        </div>  
                    </div>
                </div>
                <div class="item">
                    <h4>2</h4>
                    <img class="owl-lazy" data-src="images/section-bg-4.jpg" alt="Image_main">
                </div>
                <div class="item">
                    <h4>3</h4>
                    <img class="owl-lazy" data-src="images/section-bg-7.jpg" alt="Image_main">
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="owl-navigation">
                            <button type="button" role="presentation" class="owl-prev"><i class="fa fa-chevron-left"></i></button>
                            <button type="button" role="presentation" class="owl-next"><i class="fa fa-chevron-right"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section__2">
            <h2>Мы рады приветствовать Вас на нашей инвестиционной платформе</h2>
            <div class="container">
                <div class="section__content">
                    <div class="row">
                        <div class="section__content-left col-md-6">
                            <div class="section__bg-ridge"></div>
                            <img src="images/section-img-2.jpg" alt="Инвестиционная программа">
                        </div>
                        <div class="section__content-right col-md-6">
                            <p>
                                Наша компания использует несколько проверенных торговых систем на рынке Форекс. Уменьшение (деверсификация) рисков реализуется посредством использования нескольких (на данный момент 7 ) торговых счетов, что в свою очередь позволяет контролировать риски и просадки на торговых счетах своевременно 24/5. </p>
                            <p>
                                В среднем торговые роботы приносят прибыль порядка 1% , ежедневно по рабочим дням. Таким образом, позволяет в полной мере выплачивать проценты нашим инвесторам в течение срока работы депозита. Тело депозита (сумма инвестиции) включено в ежесуточные выплаты и выплачивается в течении 365 календарных дней(~240 рабочих) равными долями + % в соответствии с тарифным планом.
                            </p>
                            <a class="btn__border" href="#">О нас</a>
                        </div>     
                    </div>

                </div>
            </div>
        </div>


        <div class="section__3">
            <div class="container">
                <div class="section__content">
                    <div class="row">
                        <div class="section__content-text col-md-4">
                            <h2>Наши преимущества</h2>
                            <p>Наша миссия - обеспечение роста благосостояния наших инвесторов. </p>
                        </div>
                        <div class="section__content-list col-md-8">
                            <div class="section__list-left col-md-6">
                                <div class="section__content-item">
                                    <div class="item__circle">
                                        <img src="images/section-3-icon1.png" alt="">
                                    </div>
                                    <p>Торговля на валютных парах несколькими проверенными торговыми системами</p>
                                </div>
                                <div class="section__content-item">
                                    <div class="item__circle">
                                        <img src="images/section-3-icon2.png" alt="">
                                    </div>
                                    <p>Торговля на валютных парах несколькими проверенными торговыми системами</p>
                                </div>
                            </div>
                            <div class="section__list-right col-md-6">
                                <div class="section__content-item">
                                    <div class="item__circle">
                                        <img src="images/section-3-icon3.png" alt="">
                                    </div>
                                    <p>Торговля на валютных парах несколькими проверенными торговыми системами</p>
                                </div>
                                <div class="section__content-item">
                                    <div class="item__circle">
                                        <img src="images/section-3-icon4.png" alt="">
                                    </div>
                                    <p>Торговля на валютных парах несколькими проверенными торговыми системами</p>
                                </div>
                            </div>               
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section__4">
            <h2>Калькулятор доходности</h2>
            <div class="container">
                <div class="calculator">
                    <div class="row">
                        <div class="offset-md-2 col-md-8">
                            <div class="type-wallet">
                                <span>Сумма инвестиции</span>
                                <div class="wallets">
                                    <button class="active" data-slider="rub">₽</button>
                                    <button data-slider="dollar">$</button>
                                    <button data-slider="bitcoin">₿</button>
                                </div>
                            </div>
                            <div class="calc rub">
                                <div id="sliderCalcRub" class="theme"></div>
                                <div class="calc-tabs">
                                    <div></div>
                                    <div><span>200 000</span></div>
                                    <div></div>
                                    <div><span>400 000</span></div>
                                    <div></div>
                                    <div><span>600 000</span></div>
                                    <div></div>
                                    <div><span>800 000</span></div>
                                    <div></div>
                                    <div></div>
                                </div>
                                <div class="row info">
                                    <div class="col-md-6">
                                        <p>Ежедневное начисление <br><span class="gray">(по рабочим дням Форекс):</span></p>
                                        <p><b>Сумма к начислению: <span id="numberRub">1 600</span> руб.</b></p>
                                    </div>
                                    <div class="offset-md-1 col-md-5">
                                        <p>Общая прибыль за расчетный период <br><span class="gray">(~240 рабочих дней)</span></p>
                                        <p><b>Итоговая сумма: <span id="totalNumberRub">380 000</span> руб.</b></p>
                                    </div>
                                </div>
                            </div>
                            <div class="calc dollar">
                                <div id="sliderCalcDollar" class="theme"></div>
                                <div class="calc-tabs">
                                    <div></div>
                                    <div><span>4 000</span></div>
                                    <div></div>
                                    <div><span>8 000</span></div>
                                    <div></div>
                                    <div><span>12 000</span></div>
                                    <div></div>
                                    <div><span>16 000</span></div>
                                    <div></div>
                                    <div></div>
                                </div>
                                <div class="row info">
                                    <div class="col-md-6">
                                        <p>Ежедневное начисление <br><span class="gray">(по рабочим дням Форекс):</span></p>
                                        <p><b>Сумма к начислению: <span id="numberDollar">36</span> $</b></p>
                                    </div>
                                    <div class="offset-md-1 col-md-5">
                                        <p>Общая прибыль за расчетный период <br><span class="gray">(~240 рабочих дней)</span></p>
                                        <p><b>Итоговая сумма: <span id="totalNumberDollar">8 650</span> $</b></p>
                                    </div>
                                </div>
                            </div>
                            <div class="calc bitcoin">
                                <div id="sliderCalcBitcoin" class="theme"></div>
                                <div class="calc-tabs">
                                    <div></div>
                                    <div><span>0.400 000</span></div>
                                    <div></div>
                                    <div><span>0.780 000</span></div>
                                    <div></div>
                                    <div><span>1.170 000</span></div>
                                    <div></div>
                                    <div><span>1.550 000</span></div>
                                    <div></div>
                                    <div></div>
                                </div>
                                <div class="row info">
                                    <div class="col-md-6">
                                        <p>Ежедневное начисление <br><span class="gray">(по рабочим дням Форекс):</span></p>
                                        <p><b>Сумма к начислению: <span id="numberBitcoin">0.002765</span> ₿</b></p>
                                    </div>
                                    <div class="offset-md-1 col-md-5">
                                        <p>Общая прибыль за расчетный период <br><span class="gray">(~240 рабочих дней)</span></p>
                                        <p><b>Итоговая сумма: <span id="totalNumberBitcoin">0.663600</span> ₿</b></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="section__5">
            <h2>Наши партнеры</h2>
            <div class="partner">
                <div class="container">
                    <div class="row">
                        <div class="col-md-6">
                            <a href="#">
                                <img src="images/section-5-partner2.jpg" alt="">
                            </a>

                        </div>
                        <div class="col-md-6">
                            <a href="#">
                                <img src="images/section-5-partner1.jpg" alt="">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section__6">
                <div class="section__device"></div>
            <div class="container">
                <div class="section__content">
                    <div class="row">
                        <div class="section__content-left col-md-6">
                            <h2>Удобный личный кабинет для Вас</h2>
                            <p>Заработок инвесторов: Регистрация. Пройдите простую процедуру регистрации на сайте. Для вашего удобства мы не требуем от вас личных данных для верификации - только краткая информация для персонализации пользователя в системе и связи с вам</p>
                            <a class="btn__border" href="#">Зарегистрироваться</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section__7">
               <div class="container">
                <div class="section__content">
                 <h2>Инвестируйте в свое будущее</h2>
                 <p>FXArtinvest дает вам возможность преумножить ваш доход, став лидером в социальной торговой сети</p>
                 <a class="btn__green" href="#">Инвестировать сейчас</a>
              </div>
            </div>
        </div>

        <div class="section__8">
            <h2>Платежные системы</h2>
            <div class="container">
                <div class="row">
                    <div class="credit__sistem">
                        <div class="credit__sistem-item">
                            <a href=""><img src="images/section-8-icon-sberbank.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""><img src="images/section-8-icon-yandex.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""><img src="images/section-8-icon-tinkov.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""><img src="images/section-8-icon-alfa.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""> <img src="images/section-8-icon-bitcoin.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""><img src="images/section-8-icon-advcash.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""> <img src="images/section-8-icon-qiwi.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""> <img src="images/section-8-icon-payeer.png" alt=""></a>
                        </div>
                        <div class="credit__sistem-item">
                            <a href=""><img src="images/section-8-icon-perfect.png" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer>
            <div class="container">
                <div class="footer__content">
                <div class="row">
                    <div class="col-md-3">
                        <a class="footer__logo" href="#">
                            <img src="images/logo.png" alt="">
                        </a>
                    </div>
                    <div class="col-md-2">              
                        <ul>
                            <li><h4>Меню</h4></li>
                            <li><a href="#">Главная</a></li>
                            <li><a href="#">О компании</a></li>
                            <li><a href="#">Инвестиции</a></li>
                            <li><a href="#">Партнеру</a></li>
                            <li><a href="#">Вебинары</a></li>
                            <li><a href="#">Контакты</a></li>
                            <li><a href="#">Личный кабинет</a></li>
                        </ul>
                    </div>
                    <div class="offset-sm-1 col-md-2">
                        <ul>
                            <li><h4>Личный кабинет</h4></li>
                            <li><a href="#">Личные данные</a></li>
                            <li><a href="#">Панель управления</a></li>
                            <li><a href="#">История</a></li>
                            <li><a href="#">Партнеру</a></li>
                            <li><a href="#">Аналитика</a></li>
                        </ul>
                    </div>
                    <div class="offset-sm-1 col-md-2">
                        <ul class="footer__social">
                            <li><h4>Мы в соц сетях</h4></li>
                            <li>
                                <a href="#">
                                     <img src="images/header-icon-social-vk.png" alt="">
                                     <span>Vkontakte</span>
                                </a>
                                
                               
                            </li>
                            <li>
                                <a href="#">
                                    <img src="images/header-icon-social-tg.png" alt="">
                                    <span>Telegram</span>  
                                </a>
                                 
                            </li>
                            <li>
                                <a href="#">
                                    <img src="images/header-icon-social-inst.png" alt="">
                                    <span>Instagram</span>
                                </a>
                                
                            </li>
                            <li>
                                <a href="#">
                                 <img src="images/header-icon-social-youtube.png" alt="">     
                                 <span>YouTube</span>                            </a>
                                 
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
                <div class="footer__text offset-md-1 col-md-10">
                    <p class="offset-md-1 col-md-10">Компания FX ArtInvest имеет все необходимые документы. Деятельность по приему инвестиций, а также оказанию услуг доверительного управления осуществляется на законных основаниях. Используя сайт платформы, вы автоматически принимаете условия соглашения и обязуетесь выполнять правила системы.</p>
                    <div class="confidentialit__agreements">
                        <div class="confidentialit_list">
                            <ul>
                                <li><a href="#">Публичная оферта</a></li>
                                <li><a href="#">Политика конфиденциальности Условия Использования</a></li>
                                <li><a href="#"> Условия Использования</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__underline"> </div>
        </footer>
    </body>
    <script src="script/jquery.js" type="text/javascript"></script>
    <script src="script/jquery-ui.min.js" type="text/javascript"></script>
    <script src="script/owl.carousel.min.js" type="text/javascript"></script>
    <script src="script/script.js" type="text/javascript"></script>
</html>