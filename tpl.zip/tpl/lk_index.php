<? include 'lk_head.php'; ?>

        <div class="container">
            <div class="row">

                <? include 'lk_sidebar.php'; ?>
                <div class="col-md-12 col-lg-9 content">

                    <div class="content__logo">
                        <a href="/">
                            <img src="images/logo.png" alt="">
                        </a>
                    </div>


                    <div class="greeting">
                        <h5>Добро пожаловать в личный кабинет</h5>
                        <div class="timer">
                            Время сервера
                            <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                        </div>
                    </div>

                    <div class="row purses">
                        <h3 class="col-md-12">Ваш баланс</h3>
                        <div class="col-md-4">
                            <div class="purse">
                                <span class="summa">1 021</span>
                                <span class="currency">рублей</span>
                                <span class="wallet" data-currency="RUB">
                                    <i class="fal fa-wallet"></i>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="purse">
                                <span class="summa">0.50</span>
                                <span class="currency">долларов</span>
                                <span class="wallet" data-currency="USD">
                                    <i class="fal fa-wallet"></i>
                                </span>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="purse">
                                <span class="summa">0.000001</span>
                                <span class="currency">биткоинов</span>
                                <span class="wallet" data-currency="BTC">
                                    <i class="fal fa-wallet"></i>
                                </span>
                            </div>
                        </div>
                    </div>


                    <div class="referal_link">
                        <h3>Ваша реферальная ссылка</h3>
                        <div class="referal_link_flex">
                            <div class="link" id="referal_link">https://www.fxartinvest.com/?ref=admin2</div>
                            <button class="copy" data-clipboard-action="copy" data-clipboard-target="#referal_link">
                                Скопировать
                            </button>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-4">

                            <div class="investions_plans_wallets">

                                <h3>Ваши инвестиции</h3>

                                <div class="investions_plan_wallets">
                                    <span class="wallet" data-currency="RUB">
                                        <i class="fal fa-ruble-sign"></i>
                                    </span>
                                    <span class="currency">Рублей</span>
                                    <span class="summa">1 000</span>
                                </div>
                                <div class="investions_plan_wallets">
                                    <span class="wallet" data-currency="USD">
                                        <i class="fal fa-dollar-sign"></i>
                                    </span>
                                    <span class="currency">Долларов</span>
                                    <span class="summa">0.50</span>
                                </div>
                                <div class="investions_plan_wallets">
                                    <span class="wallet" data-currency="BTC">
                                        <i class="fal fa-btc"></i>
                                    </span>
                                    <span class="currency">Биткоинов</span>
                                    <span class="summa">0.00001</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="calendar" data-year="<?=date("Y")?>" data-month="<?=date("m")-1?>">
                                <?if(false):?>
                                <div class="calendar_head">
                                    <h3>Календарь рабочих дней Форекс</h3>
                                    <div class="select_date">
                                        <a class="prev_month" href="#">
                                            <i class="fal fa-angle-left"></i>
                                        </a>
                                        <span class="this_date">Август 2019</span>
                                        <a class="next_month" href="#">
                                            <i class="fal fa-angle-right"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="calendar_body">
                                    <div class="calendar_daysweek">
                                        <div class="calendar_dayweek">
                                            <span>ПН</span>
                                        </div>
                                        <div class="calendar_dayweek">
                                            <span>ВТ</span>
                                        </div>
                                        <div class="calendar_dayweek">
                                            <span>СР</span>
                                        </div>
                                        <div class="calendar_dayweek">
                                            <span>ЧТ</span>
                                        </div>
                                        <div class="calendar_dayweek">
                                            <span>ПТ</span>
                                        </div>
                                        <div class="calendar_dayweek">
                                            <span>СБ</span>
                                        </div>
                                        <div class="calendar_dayweek">
                                            <span>ВС</span>
                                        </div>
                                    </div>
                                    <div class="calendar_days">
                                        <div class="calendar_day other_month">
                                            <span>29</span>
                                        </div>
                                        <div class="calendar_day other_month">
                                            <span>30</span>
                                        </div>
                                        <div class="calendar_day other_month">
                                            <span>31</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>1</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>2</span>
                                        </div>
                                        <div class="calendar_day freeday start_freeday">
                                            <span>3</span>
                                        </div>
                                        <div class="calendar_day freeday end_freeday">
                                            <span>4</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>5</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>6</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>7</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>8</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>9</span>
                                        </div>
                                        <div class="calendar_day freeday start_freeday">
                                            <span>10</span>
                                        </div>
                                        <div class="calendar_day freeday end_freeday">
                                            <span>11</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>12</span>
                                        </div>
                                        <div class="calendar_day holiday">
                                            <span>13</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>14</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>15</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>16</span>
                                        </div>
                                        <div class="calendar_day freeday start_freeday">
                                            <span>17</span>
                                        </div>
                                        <div class="calendar_day freeday end_freeday">
                                            <span>18</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>19</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>20</span>
                                        </div>
                                        <div class="calendar_day holiday start_holiday">
                                            <span>21</span>
                                        </div>
                                        <div class="calendar_day holiday">
                                            <span>22</span>
                                        </div>
                                        <div class="calendar_day holiday">
                                            <span>23</span>
                                        </div>
                                        <div class="calendar_day holiday end_holiday">
                                            <span>24</span>
                                        </div>
                                        <div class="calendar_day freeday">
                                            <span>25</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>26</span>
                                        </div>
                                        <div class="calendar_day freeday">
                                            <span>27</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>28</span>
                                        </div>
                                        <div class="calendar_day this_day">
                                            <span>29</span>
                                        </div>
                                        <div class="calendar_day">
                                            <span>30</span>
                                        </div>
                                        <div class="calendar_day freeday start_freeday">
                                            <span>31</span>
                                        </div>
                                        <div class="calendar_day other_month freeday end_freeday">
                                            <span>1</span>
                                        </div>
                                    </div>

                                </div>
                                <div class="calendar_footer">
                                    <span class="today">Сегодня</span>
                                    <span class="holiday">Праздничный день</span>
                                    <span class="freeday">Не торговый день</span>
                                </div>
                                <?endif;?>
                            </div>
                        </div>

                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="table_block">
                                <h3>Последние действия</h3>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>№</th>
                                            <th>Действие</th>
                                            <th>Дата</th>
                                            <th>Сумма</th>
                                            <th>Тариф</th>
                                            <th>Статус</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td data-label="№">135</td>
                                            <td data-label="Действие">
                                                <span class="font-success">Начисление</span>
                                            </td>
                                            <td data-label="Дата">
                                                16.08.19
                                            </td>
                                            <td data-label="Сумма">
                                                <span class="font-green">+7 <i class="fal fa-ruble-sign"></i></span>
                                            </td>
                                            <td data-label="Тариф">
                                                Старт
                                            </td>
                                            <td data-label="Статус">
                                                <span class="label label-success">Начислено</span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td data-label="№">135</td>
                                            <td data-label="Действие">
                                                <span class="font-warning">Вывод</span>
                                            </td>
                                            <td data-label="Дата">
                                                16.08.19
                                            </td>
                                            <td data-label="Сумма">
                                                <span class="font-danger">+7 <i class="fal fa-ruble-sign"></i></span>
                                            </td>
                                            <td data-label="Тариф">
                                                Старт
                                            </td>
                                            <td data-label="Статус">
                                                <span class="label label-warning">В ожидании</span>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="pagination">
                                    <ul>
                                        <li class="active">
                                            <a href="#">1</a>
                                        </li>
                                        <li>
                                            <a href="#">2</a>
                                        </li>
                                        <li>
                                            <a href="#">3</a>
                                        </li>
                                        <li>
                                            <a href="#">4</a>
                                        </li>
                                        <li>
                                            <a href="#">5</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

        <? include 'lk_footer.php'; ?>
    </body>


</html>


