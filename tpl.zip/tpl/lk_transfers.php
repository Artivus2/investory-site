<? include 'lk_head.php'; ?>

<div class="container">
    <div class="row">

        <? include 'lk_sidebar.php'; ?>
        <div class="col-md-12 col-lg-9 content">

            <div class="content__logo">
                <a href="/">
                    <img src="images/logo.png" alt="">
                </a>
            </div>


            <div class="greeting">
                <h5>Добро пожаловать в личный кабинет</h5>
                <div class="timer">
                    Время сервера
                    <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                </div>
            </div>

            <div class="row purses">
                <h3 class="col-md-12">Ваш баланс</h3>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">1 021</span>
                        <span class="currency">рублей</span>
                        <span class="wallet" data-currency="rub">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.50</span>
                        <span class="currency">долларов</span>
                        <span class="wallet" data-currency="usd">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.000001</span>
                        <span class="currency">биткоинов</span>
                        <span class="wallet" data-currency="btc">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="form_block">
                        <h3>Внутренний перевод</h3>
                        <form class="">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Логин или E-mail получателя</label>
                                        <input type="text" id="">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Кошелек</label>
                                        <div class="select">
                                            <select>
                                                <option>RUB</option>
                                                <option>USD</option>
                                                <option>BTC</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Сумма перевода</label>
                                        <input type="text" id="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8 col-sm-6 col-xs-12 form_help">
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 text-right">
                                    <button type="submit" class="btn__green">Перевод</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-sm-12">
                    <div class="table_block">
                        <h3>История внутренних переводов</h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Дата</th>
                                    <th>Сумма</th>
                                    <th>Отправитель</th>
                                    <th>Получатель</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td data-label="№">135</td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-green">+7 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Отправитель">
                                        admin
                                    </td>
                                    <td data-label="Получатель">
                                        admin2
                                    </td>
                                    <td data-label="Статус">
                                        <span class="label label-success">Отправлен</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td data-label="№">135</td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-danger">+7 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Отправитель">
                                        user1
                                    </td>
                                    <td data-label="Получатель">
                                        admin
                                    </td>
                                    <td data-label="Статус">
                                        <span class="label label-warning">Получен</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="pagination">
                            <ul>
                                <li class="active">
                                    <a href="#">1</a>
                                </li>
                                <li>
                                    <a href="#">2</a>
                                </li>
                                <li>
                                    <a href="#">3</a>
                                </li>
                                <li>
                                    <a href="#">4</a>
                                </li>
                                <li>
                                    <a href="#">5</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<? include 'lk_footer.php'; ?>
</body>


</html>


