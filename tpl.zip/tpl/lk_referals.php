<? include 'lk_head.php'; ?>

<div class="container">
    <div class="row">

        <? include 'lk_sidebar.php'; ?>
        <div class="col-md-12 col-lg-9 content">

            <div class="content__logo">
                <a href="/">
                    <img src="images/logo.png" alt="">
                </a>
            </div>


            <div class="greeting">
                <h5>Добро пожаловать в личный кабинет</h5>
                <div class="timer">
                    Время сервера
                    <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                </div>
            </div>

            <div class="row purses">
                <h3 class="col-md-12">Ваш баланс</h3>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">1 021</span>
                        <span class="currency">рублей</span>
                        <span class="wallet" data-currency="rub">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.50</span>
                        <span class="currency">долларов</span>
                        <span class="wallet" data-currency="usd">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.000001</span>
                        <span class="currency">биткоинов</span>
                        <span class="wallet" data-currency="btc">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
            </div>
            
  <div class="referal_link">
                        <h3>Ваша реферальная ссылка</h3>
                        <div class="referal_link_flex">
                            <div class="link">
                                https://www.fxartinvest.com/?ref=admin2
                            </div>
                            <a href="#" class="copy">Скопировать</a>
                        </div>
                    </div>

            

            <div class="row">
                <div class="col-sm-12 referal_statistics">
                    <h3>Таблица рефельной активности</h3>
                    
                    <ul>
                        <li>
                            <h4>Количество переходов по партнерской ссылке</h4>
                            <span class="count"> 2 </span>
                        </li>
                        <li>
                            <h4>Общее количество партнеров (с инвестициями)</h4>
                            <span class="count"> 1 (0) </span>
                        </li>
                        <li>
                            <h4>Количество партнеров 1 линии</h4>
                            <span class="count"> 1 </span>
                        </li>
                        <li>
                            <h4>Количество партнеров 2 линии</h4>
                            <span class="count"> 0 </span>
                        </li>
                        <li>
                            <h4>Количество партнеров 3 линии</h4>
                            <span class="count"> 0 </span>
                        </li>
                        <li>
                            <h4>Количество партнеров 4 линии</h4>
                            <span class="count"> 0 </span>
                        </li>
                        <li>
                            <h4>Количество партнеров 5 линии</h4>
                            <span class="count"> 0 </span>
                        </li>
                    </ul>
                </div>
            </div>


            
            <div class="row">
                <div class="col-sm-12">
                    <div class="table_block">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>
                                        <i class="fa fa-user-friends"></i>
                                    </th>
                                    <th>ID</th>
                                    <th>Логин</th>
                                    <th>Дата регистрации</th>
                                    <th>Сумма инвестиций</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td class="hidden-xs">
                                        <i class="fa fa-user"></i>
                                    </td>
                                    <td data-label="ID">
                                        100
                                    </td>
                                    <td data-label="Логин">
                                        admin
                                    </td>
                                    <td data-label="Дата регистрации">
                                        01.08.2019
                                    </td>
                                    <td data-label="Сумма инвестиций">
                                        <span class="font-success">1000$</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="hidden-xs">
                                        <i class="fa fa-reply"></i>
                                    </td>
                                    <td data-label="ID">
                                        150
                                    </td>
                                    <td data-label="Логин">
                                        admin
                                    </td>
                                    <td data-label="Дата регистрации">
                                        01.08.2019
                                    </td>
                                    <td data-label="Сумма инвестиций">
                                        <span class="font-success">1000$</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<? include 'lk_footer.php'; ?>
</body>


</html>


