<!doctype html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
        <title>Document</title>
        <link href="style/main/normalize.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/bootstrap-grid.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/owl.carousel.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/owl.theme.default.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/Roboto/Roboto.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/scss/lk_style.css" rel="stylesheet" type="text/css"/>
        <link href="style/scss/lk_adaptiv.css" rel="stylesheet" type="text/css"/>
    </head> 
    <body>
        <header>
            <div class="top-header">
                <div class="container">
                    <div class="row">
                        <div class="top__header-left col-lg-6">
                            <ul class="top__header-left-list">
                                <li class="top__header-left-item"><a href="#" class="top__header-left-item-active">Главная</a></li>
                                <li class="top__header-left-item"><a href="#">О компании</a></li>
                                <li class="top__header-left-item"><a href="#">Инвестиции</a></li>
                                <li class="top__header-left-item"><a href="#">Партнеру</a></li>
                                <li class="top__header-left-item"><a href="#">Вебинары</a></li>
                                <li class="top__header-left-item"><a href="#">Контакты</a></li>
                            </ul>
                        </div>
                        <div class="top__header-right offset-lg-2 col-lg-4">
                            <div class="nav-toogle">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                            <div class="top__header-right-board">
                                <div class="top__header-right-language dropdown" data-dropdown="dropdown">
                                    <a href="#" class="dropdown-toggle"> Русский </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">English</a></li>
                                    </ul>
                                </div>
                                
                                <div class="top__header-right-lk dropdown dropdown-right" data-dropdown="dropdown">

                                    <a href="#" class="dropdown-toggle"> <img class="user_avatar" src="images/avatar.jpg"></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="#">Профиль</a></li>
                                        <li><a href="#">Настройки</a></li>
                                        <li><a href="#">Выход</a></li>
                                    </ul>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </header>