<aside class="col-md-3 sidebar">
                    <div class="sidebar_mobile_insert">
                    <button class="close-menu"></button>
                    <div class="sidebar__logo">
                        <a href="/">
                            <img src="images/logo.png" alt="">
                        </a>
                    </div>

                    <ul class="sidebar-menu-mobile">
                        <li class="top__header-left-item"><a href="#" class="top__header-left-item-active">Главная</a></li>
                        <li class="top__header-left-item"><a href="#">О компании</a></li>
                        <li class="top__header-left-item"><a href="#">Инвестиции</a></li>
                        <li class="top__header-left-item"><a href="#">Партнеру</a></li>
                        <li class="top__header-left-item"><a href="#">Вебинары</a></li>
                        <li class="top__header-left-item"><a href="#">Контакты</a></li>
                        <li><div class="hr"></div></li>
                    </ul>

                    <ul class="sidebar_menu">
                        <li class="active">
                            <a href="/tpl/lk_index.php">
                                <i class="fal fa-th-large"></i>
                                Главная</a>
                        </li>
                        <li>
                            <a href="/tpl/lk_refill.php">
                                <i class="fal fa-piggy-bank"></i>
                                Пополнение
                            </a>
                        </li>
                        <li>
                            <a href="/tpl/lk_withdraw.php">
                                <i class="fal fa-credit-card"></i>
                                Вывод средств
                            </a>
                        </li>
                        <li>

                            <a href="/tpl/lk_deposits.php#new">
                                <i class="fal fa-wallet"></i>
                                Создать депозит
                            </a>
                        </li>
                        <li>
                            <a href="/tpl/lk_deposits.php#list">
                                <i class="fal fa-receipt"></i>
                                Мои депозиты
                            </a>
                        </li>
                        <li>
                            <a href="/tpl/lk_transfers.php">
                                <i class="fal fa-retweet"></i>
                                Внутрений перевод
                            </a>
                        </li>
                        <li>
                            <a href="/tpl/lk_referals.php">
                                <i class="fal fa-user-friends"></i>
                                Мои партнеры
                            </a>
                        </li>
                        <li>
                            <a href="/tpl/lk_referals_history.php">
                                <i class="fal fa-list-alt"></i>
                                История реферальных
                            </a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="/tpl/lk_trade.php">
                                <i class="fal fa-coins"></i>
                                Торговля
                            </a>
                        </li>
                        <li>
                            <a href="/tpl/lk_analytics.php">
                                <i class="fal fa-chart-line"></i>
                                Аналитика
                            </a>
                        </li>
                    </ul>
                    </div>
                </aside>