<footer>
    <div class="container">
        <div class="footer__content">
            <div class="row">
                <div class="col-lg-3 col-md-4">
                    <a class="footer__logo" href="#">
                        <img src="images/logo.png" alt="">
                    </a>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-4 col-6">              
                    <ul>
                        <li><h4>Меню</h4></li>
                        <li><a href="#">Главная</a></li>
                        <li><a href="#">О компании</a></li>
                        <li><a href="#">Инвестиции</a></li>
                        <li><a href="#">Партнеру</a></li>
                        <li><a href="#">Вебинары</a></li>
                        <li><a href="#">Контакты</a></li>
                        <li><a href="#">Личный кабинет</a></li>
                    </ul>
                </div>
                <div class="offset-lg-1 col-lg-2 col-md-3 col-sm-4 col-6">
                    <ul>
                        <li><h4>Личный кабинет</h4></li>
                        <li><a href="#">Личные данные</a></li>
                        <li><a href="#">Панель управления</a></li>
                        <li><a href="#">История</a></li>
                        <li><a href="#">Партнеру</a></li>
                        <li><a href="#">Аналитика</a></li>
                    </ul>
                </div>
                <div class="offset-lg-1 col-lg-2 col-md-3 col-sm-4">
                    <ul class="footer__social">
                        <li><h4>Мы в соц сетях</h4></li>
                        <li>
                            <a href="#">
                                <img src="images/header-icon-social-vk.png" alt="">
                                <span>Vkontakte</span>
                            </a>


                        </li>
                        <li>
                            <a href="#">
                                <img src="images/header-icon-social-tg.png" alt="">
                                <span>Telegram</span>  
                            </a>

                        </li>
                        <li>
                            <a href="#">
                                <img src="images/header-icon-social-inst.png" alt="">
                                <span>Instagram</span>
                            </a>

                        </li>
                        <li>
                            <a href="#">
                                <img src="images/header-icon-social-youtube.png" alt="">     
                                <span>YouTube</span>                            </a>

                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer__text offset-md-1 col-md-10">
            <p class="offset-md-1 col-md-10">Компания FX ArtInvest имеет все необходимые документы. Деятельность по приему инвестиций, а также оказанию услуг доверительного управления осуществляется на законных основаниях. Используя сайт платформы, вы автоматически принимаете условия соглашения и обязуетесь выполнять правила системы.</p>
            <div class="confidentialit__agreements">
                <div class="confidentialit_list">
                    <a href="#">Публичная оферта</a> | <a href="#">Политика конфиденциальности</a> | <a href="#">Условия Использования</a>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__underline"> </div>
</footer>
<script src="script/jquery.js" type="text/javascript"></script>
<script src="script/jquery-ui.min.js?v=1.2" type="text/javascript"></script>
<script src="script/owl.carousel.min.js" type="text/javascript"></script>
<script src="script/clipboard.min.js" type="text/javascript"></script>
<script src="script/lk_script.js?v=1.1" type="text/javascript"></script>