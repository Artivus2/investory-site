<? include 'lk_head.php'; ?>

<div class="container">
    <div class="row">

        <? include 'lk_sidebar.php'; ?>
        <div class="col-md-12 col-lg-9 content">

            <div class="content__logo">
                <a href="/">
                    <img src="images/logo.png" alt="">
                </a>
            </div>


            <div class="greeting">
                <h5>Добро пожаловать в личный кабинет</h5>
                <div class="timer">
                    Время сервера
                    <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                </div>
            </div>

            <div class="row purses">
                <h3 class="col-md-12">Ваш баланс</h3>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">1 021</span>
                        <span class="currency">рублей</span>
                        <span class="wallet" data-currency="rub">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.50</span>
                        <span class="currency">долларов</span>
                        <span class="wallet" data-currency="usd">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.000001</span>
                        <span class="currency">биткоинов</span>
                        <span class="wallet" data-currency="btc">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="form_block">
                        <h3>Вывод средств</h3>
                        <form class="">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Кошелек</label>
                                        <div class="select">
                                            <select>
                                                <option>RUB</option>
                                                <option>USD</option>
                                                <option>BTC</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Платежная система</label>
                                        <div class="select">
                                            <select>
                                                <option>RUB</option>
                                                <option>USD</option>
                                                <option>BTC</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Сумма вывода</label>
                                        <input type="text" id="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-8 col-xs-12 form_help">
                                </div>
                                <div class="col-sm-4 col-xs-12 text-right">
                                    <button type="submit" class="btn__green">Выплатить</button>
                                </div>
                            </div>
                        </form>

                        <div class="pay_systems">
                            <h3>Платежные системы</h3>

                            <ul>
                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-sberbank.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-yandex.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-tinkov.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-alfa.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-bitcoin.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-advcash.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-qiwi.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-payeer.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                                <li>
                                    <div class="pay_system">
                                        <img src="images/section-8-icon-perfect.png" />
                                        <h4>
                                            мин. 100 
                                            <i class="fal fa-ruble-sign"></i>
                                        </h4>
                                        <p>
                                            комиссия 2.5% от суммы
                                        </p>
                                    </div>
                                </li>

                            </ul>


                        </div>


                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-sm-12">
                    <div class="table_block">
                        <h3>История вывода средств</h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Дата</th>
                                    <th>Сумма</th>
                                    <th>Счет</th>
                                    <th>Система</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td data-label="№">135</td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-green">+7 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Счет">
                                        USD
                                    </td>
                                    <td data-label="Система">
                                        Payeer
                                    </td>
                                    <td data-label="Статус">
                                        <span class="label label-success">Начислено</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td data-label="№">135</td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-danger">+7 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Счет">
                                        RUB
                                    </td>
                                    <td data-label="Система">
                                        Quwu
                                    </td>
                                    <td data-label="Статус">
                                        <span class="label label-warning">В ожидании</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="pagination">
                            <ul>
                                <li class="active">
                                    <a href="#">1</a>
                                </li>
                                <li>
                                    <a href="#">2</a>
                                </li>
                                <li>
                                    <a href="#">3</a>
                                </li>
                                <li>
                                    <a href="#">4</a>
                                </li>
                                <li>
                                    <a href="#">5</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<? include 'lk_footer.php'; ?>
</body>


</html>


