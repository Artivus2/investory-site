<? include 'lk_head.php'; ?>

<div class="container">
    <div class="row">

        <? include 'lk_sidebar.php'; ?>
        <div class="col-md-12 col-lg-9 content">

            <div class="content__logo">
                <a href="/">
                    <img src="images/logo.png" alt="">
                </a>
            </div>


            <div class="greeting">
                <h5>Добро пожаловать в личный кабинет</h5>
                <div class="timer">
                    Время сервера
                    <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                </div>
            </div>

            <div class="row purses">
                <h3 class="col-md-12">Ваш баланс</h3>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">1 021</span>
                        <span class="currency">рублей</span>
                        <span class="wallet" data-currency="rub">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.50</span>
                        <span class="currency">долларов</span>
                        <span class="wallet" data-currency="usd">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.000001</span>
                        <span class="currency">биткоинов</span>
                        <span class="wallet" data-currency="btc">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
            </div>
           

            

            
            <div class="row">
                <div class="col-sm-12">
                    <div class="table_block">
                        <h3>История рефельных начислений</h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Дата</th>
                                    <th>Сумма</th>
                                    <th>Логин</th>
                                    <th>Сумма депозита</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td data-label="ID">
                                        100
                                    </td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-green">+7 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Логин">
                                        user1
                                    </td>
                                    <td data-label="Сумма депозита">
                                        1000$
                                    </td>
                                </tr>
                                <tr>
                                    <td data-label="ID">
                                        150
                                    </td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-green">+17 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Логин">
                                        user2
                                    </td>
                                    <td data-label="Сумма депозита">
                                        1000$
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="pagination">
                            <ul>
                                <li class="active">
                                    <a href="#">1</a>
                                </li>
                                <li>
                                    <a href="#">2</a>
                                </li>
                                <li>
                                    <a href="#">3</a>
                                </li>
                                <li>
                                    <a href="#">4</a>
                                </li>
                                <li>
                                    <a href="#">5</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<? include 'lk_footer.php'; ?>
</body>


</html>


