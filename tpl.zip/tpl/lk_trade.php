<? include 'lk_head.php'; ?>

<div class="container">
    <div class="row">

        <? include 'lk_sidebar.php'; ?>
        <div class="col-md-12 col-lg-9 content">

            <div class="content__logo">
                <a href="/">
                    <img src="images/logo.png" alt="">
                </a>
            </div>


            <div class="greeting">
                <h5>Добро пожаловать в личный кабинет</h5>
                <div class="timer">
                    Время сервера
                    <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                </div>
            </div>

            <div class="row purses">
                <h3 class="col-md-12">Ваш баланс</h3>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">1 021</span>
                        <span class="currency">рублей</span>
                        <span class="wallet" data-currency="rub">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.50</span>
                        <span class="currency">долларов</span>
                        <span class="wallet" data-currency="usd">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.000001</span>
                        <span class="currency">биткоинов</span>
                        <span class="wallet" data-currency="btc">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
            </div>
            
  
            <div class="trade_text">
                Вы желаете зарабатывать на Forex, но не хотите вникать в тонкости совершения торговых операций или просто не обладаете достаточным опытом для ведения прибыльной торговли. Мы предоставляем Вам возможность работать с опытным трейдером от платформы Fxartinvest, копируя его сделки на свой счёт. подробнее...
            </div>
            

            <div class="trade_widget">
                
<iframe src="https://staticmy.roboforex.com/ru/informers/providers/frame/large/54614/" width="405" height="508" frameborder="0"></iframe>
            </div>
            
            
            
        </div>

    </div>
</div>

<? include 'lk_footer.php'; ?>
</body>


</html>


