<? include 'lk_head.php'; ?>

<div class="container">
    <div class="row">

        <? include 'lk_sidebar.php'; ?>
        <div class="col-md-12 col-lg-9 content">

            <div class="content__logo">
                <a href="/">
                    <img src="images/logo.png" alt="">
                </a>
            </div>


            <div class="greeting">
                <h5>Добро пожаловать в личный кабинет</h5>
                <div class="timer">
                    Время сервера
                    <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                </div>
            </div>

            <div class="row purses">
                <h3 class="col-md-12">Ваш баланс</h3>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">1 021</span>
                        <span class="currency">рублей</span>
                        <span class="wallet" data-currency="rub">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.50</span>
                        <span class="currency">долларов</span>
                        <span class="wallet" data-currency="usd">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.000001</span>
                        <span class="currency">биткоинов</span>
                        <span class="wallet" data-currency="btc">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="form_block">
                        <h3>Настройки</h3>
                        <form class="">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">ФИО</label>
                                        <input type="text" id="" value="Иван">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Номер телефона</label>
                                        <input type="text" id="" value="8-800-000-0000">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">E-mail</label>
                                        <input type="text" id="" value="info@mail.ru">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-8 col-sm-6 col-xs-12 form_help">
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12 text-right">
                                    <button type="submit" class="btn__green">Сохранить</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-sm-12">
                    <div class="form_block">
                        <h3>Пароль</h3>
                        <form class="">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Пароль</label>
                                        <input type="text" id="" value="Иван">
                                    </div>
                                </div>
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Еще раз</label>
                                        <input type="text" id="" value="8-800-000-0000">
                                    </div>
                                </div>
                                <div class="col-sm-4 text-right">
                                    <button type="submit" class="btn__green">Сохранить</button>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 form_help">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="form_block">
                        <h3>Платежные реквизиты</h3>
                        <form class="">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">Сбербанк</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">Яндекс Деньги</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">Тинькофф</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">Альфа-Банк</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">QIWI кошелек </label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">AdvCash кошелек</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">Payeer кошелек</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">Perfect Money</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="control-group">
                                        <label class="control-label">ID биткоин кошелька</label>
                                        <input type="text" id="" value="">
                                    </div>
                                </div>
                                <div class="col-sm-6 text-right">
                                    <button type="submit" class="btn__green">Сохранить</button>
                                </div>
                                
                            </div>
                        </form>
                    </div>
                </div>
            </div>


        </div>

    </div>
</div>

<? include 'lk_footer.php'; ?>
</body>


</html>


