<? include 'lk_head.php'; ?>

<div class="container">
    <div class="row">

        <? include 'lk_sidebar.php'; ?>
        <div class="col-md-12 col-lg-9 content">

            <div class="content__logo">
                <a href="/">
                    <img src="images/logo.png" alt="">
                </a>
            </div>


            <div class="greeting">
                <h5>Добро пожаловать в личный кабинет</h5>
                <div class="timer">
                    Время сервера
                    <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
                </div>
            </div>

            <div class="row purses">
                <h3 class="col-md-12">Ваш баланс</h3>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">1 021</span>
                        <span class="currency">рублей</span>
                        <span class="wallet" data-currency="rub">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.50</span>
                        <span class="currency">долларов</span>
                        <span class="wallet" data-currency="usd">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="purse">
                        <span class="summa">0.000001</span>
                        <span class="currency">биткоинов</span>
                        <span class="wallet" data-currency="btc">
                            <i class="fal fa-wallet"></i>
                        </span>
                    </div>
                </div>
            </div>

            <div class="row" id="new">
                <div class="col-sm-12">
                    <div class="form_block">
                        <h3>Создать депозит</h3>
                        <form class="new_deposit">
                            <div class="row">
                                <div class="col-sm-4">
                                    <div class="control-group">
                                        <label class="control-label">Счет</label>
                                        <div class="select">
                                            <select name="currency">
                                                <option value="RUB">RUB</option>
                                                <option value="USD">USD</option>
                                                <option value="BTC">BTC</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-5">
                                    <div class="control-group">
                                        <label class="control-label">Сумма</label>
                                        <input type="text" id="">
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <button type="submit" class="btn__green btn_block">Создать</button>
                                </div>
                            </div>
                            <br />
                        </form>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="investions_plans">
                        <h3>Инвестиционные планы</h3>

                        <ul>
                            <li data-currency="RUB" data-min="1000" data-max="29999">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_1.png" />
                                    Старт
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.70%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        1000р
                                    </span>
                                    <span class="max_summa">
                                        29999р
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="RUB" data-min="30000" data-max="199999">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_2.png" />
                                    Стандарт
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.80%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        30000р
                                    </span>
                                    <span class="max_summa">
                                        199999р
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="RUB" data-min="200000" data-max="599999">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_3.png" />
                                    Бизнес
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.90%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        200000р
                                    </span>
                                    <span class="max_summa">
                                        599999р
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="RUB" data-min="600000" data-max="1000000">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_4.png" />
                                    VIP
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        1.00%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        600000р
                                    </span>
                                    <span class="max_summa">
                                        1000000р
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="USD" data-min="15" data-max="499">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_1.png" />
                                    Старт
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.70%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        15$
                                    </span>
                                    <span class="max_summa">
                                        499$
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="USD" data-min="500" data-max="2999">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_2.png" />
                                    Стандарт
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.80%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        500%
                                    </span>
                                    <span class="max_summa">
                                        2999%
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="USD" data-min="3000" data-max="9999">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_3.png" />
                                    Бизнес
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.90%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        3000$
                                    </span>
                                    <span class="max_summa">
                                        9999$
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="USD" data-min="10000" data-max="20000">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_4.png" />
                                    VIP
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        1.00%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        10000$
                                    </span>
                                    <span class="max_summa">
                                        20000$
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="BTC" data-min="0.015000" data-max="0.054000">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_1.png" />
                                    Старт
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.70%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        0.015000
                                    </span>
                                    <span class="max_summa">
                                        0.054000
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="BTC" data-min="0.055000" data-max="0.294000">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_2.png" />
                                    Стандарт
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.80%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        0.055000
                                    </span>
                                    <span class="max_summa">
                                        0.294000
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="BTC" data-min="0.295000" data-max="0.954000">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_3.png" />
                                    Бизнес
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        0.90%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        0.295000
                                    </span>
                                    <span class="max_summa">
                                        0.954000
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                            <li data-currency="BTC" data-min="0.955000" data-max="1.950000">
                                <div class="plan_name">
                                    <img src="images/daposit_plan_4.png" />
                                    VIP
                                </div>
                                <div class="plan_data">
                                    <span class="procent_in_day">
                                        1.00%
                                        <label>В день</label>
                                    </span>
                                    <span class="count_days">
                                        365
                                        <label>Дней</label>
                                    </span>
                                    <span class="min_summa">
                                        0.955000
                                    </span>
                                    <span class="max_summa">
                                        1.950000
                                    </span>
                                </div>
                                <div class="plan_status">

                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>


            <div class="row" id="list">
                <div class="col-sm-12">
                    <div class="table_block">
                        <h3>История вывода средств</h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>№</th>
                                    <th>Дата</th>
                                    <th>Сумма</th>
                                    <th>Счет</th>
                                    <th>Система</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td data-label="№">135</td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-green">+7 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Счет">
                                        USD
                                    </td>
                                    <td data-label="Система">
                                        Payeer
                                    </td>
                                    <td data-label="Статус">
                                        <span class="label label-success">Начислено</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td data-label="№">135</td>
                                    <td data-label="Дата">
                                        16.08.19
                                    </td>
                                    <td data-label="Сумма">
                                        <span class="font-danger">+7 <i class="fal fa-ruble-sign"></i></span>
                                    </td>
                                    <td data-label="Счет">
                                        RUB
                                    </td>
                                    <td data-label="Система">
                                        Quwu
                                    </td>
                                    <td data-label="Статус">
                                        <span class="label label-warning">В ожидании</span>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <div class="pagination">
                            <ul>
                                <li class="active">
                                    <a href="#">1</a>
                                </li>
                                <li>
                                    <a href="#">2</a>
                                </li>
                                <li>
                                    <a href="#">3</a>
                                </li>
                                <li>
                                    <a href="#">4</a>
                                </li>
                                <li>
                                    <a href="#">5</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
</div>

<? include 'lk_footer.php'; ?>
</body>


</html>


