<!doctype html>
<html lang="ru">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
        <title>Document</title>
        <link href="style/main/normalize.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/bootstrap-grid.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/owl.carousel.css" rel="stylesheet" type="text/css"/>
        <link href="style/main/owl.theme.default.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/Roboto/Roboto.css" rel="stylesheet" type="text/css"/>
        <link href="fonts/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="style/scss/style.css" rel="stylesheet" type="text/css"/>
        <link href="style/scss/adaptiv.css" rel="stylesheet" type="text/css"/>
    </head> 
    <body>
        <header>
            <div class="top-header">
                <div class="container">
                    <div class="row">
                        <div class="top__header-left col-lg-6">
                            <ul class="top__header-left-list">
                                <li class="top__header-left-item"><a href="#" class="top__header-left-item-active">Главная</a></li>
                                <li class="top__header-left-item"><a href="#">О компании</a></li>
                                <li class="top__header-left-item"><a href="#">Инвестиции</a></li>
                                <li class="top__header-left-item"><a href="#">Партнеру</a></li>
                                <li class="top__header-left-item"><a href="#">Вебинары</a></li>
                                <li class="top__header-left-item"><a href="#">Контакты</a></li>
                            </ul>
                        </div>
                        <div class="top__header-right offset-lg-2 col-lg-4">
                            <div class="nav-toogle">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                            <div class="top__header-right-board">
                                <div class="dropdown">
                                    <div class="dropbtn">Русский</div>
                                    <div class="dropdown-content">
                                        <a href="#">English</a>
                                    </div>
                                </div>
                                <div class="top__header-right-lk">
                                    <a href="#" class="cabinet">
                                        <img src="images/header-icon-unclock.png" alt=""/>
                                        Личный кабинет
                                    </a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <nav>
                <div class="container">
                    <div class="row">
                        <div class="nav__logo col-lg-3 col-6">
                            <a href="#">
                                <img src="images/logo.png" alt="">
                            </a>
                        </div>
                        <div class="header__menu col-lg-7">
                            <ul class="header__menu-nav-list">
                                <ul class="header__menu-mobile">
                                    <button class="close-menu"></button>
                                    <li class="top__header-left-item"><a href="#" class="top__header-left-item-active">Главная</a></li>
                                    <li class="top__header-left-item"><a href="#">О компании</a></li>
                                    <li class="top__header-left-item"><a href="#">Инвестиции</a></li>
                                    <li class="top__header-left-item"><a href="#">Партнеру</a></li>
                                    <li class="top__header-left-item"><a href="#">Вебинары</a></li>
                                    <li class="top__header-left-item"><a href="#">Контакты</a></li>
                                    <li><div class="hr"></div></li>
                                </ul>
                                <li class="nav__item"><a href="#" class="nav__item-active">Инвестиции</a></li>
                                <li class="nav__item"><a href="#">Партнеру</a></li>
                                <li class="nav__item"><a href="#">Вебинары</a></li>
                                <li class="nav__item"><a href="#">Условия использования</a></li>
                            </ul> 
                        </div>
                        <div class="header__social col-lg-2 col-6">
                            <ul class="social__list">
                                <li><a href="#" target="blank"><i class="fab fa-vk"></i></a></li>
                                <li><a href="#" target="blank"><i class="fab fa-telegram-plane"></i></a></li>
                                <li><a href="#" target="blank"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#" target="blank"><i class="fab fa-youtube"></i></a></li>
                            </ul>
                        </div>

                    </div>

                </div>

            </nav>
        </header>
        <div class="breadcrumb article">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <h2 class="breadcrumb__title">Запуск нового сайта</h2>
                        <p class="breadcrumb__text">22.07.2019</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="section__article">  
            <div class="container">
                <div class="owl-carousel owl-theme">
                    <div class="item" style="background-image: url(images/article_slide.jpg);"></div>
                    <div class="item" style="background-image: url(images/article_slide.jpg);"></div>
                    <div class="item" style="background-image: url(images/article_slide.jpg);"></div>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="owl-navigation">
                                <button type="button" role="presentation" class="owl-prev"><i class="fal fa-long-arrow-left"></i></button>
                                <button type="button" role="presentation" class="owl-next"><i class="fal fa-long-arrow-right"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="row">
                                <div class="section__article-text">
                <p>5 лет подряд мы успешно выдерживаем ежегодный аудит, проводимый компанией KPMG, по завершении которого все наши ключевые показатели публикуются на сайте.</p>
                <p>Говоря о ключевых показателях, мы не можем не отметить высокий уровень качества наших сервисов — среднее время зачисления средств занимает 6.2 минуты, а среднее время рассмотрения заявки на вывод средств занимает 3 часа и 30 минут!</p>
                <p>Мы знаем, что скорость является одним из главных приоритетов в торговле — средняя скорость исполнения ордера 0.834 секунды!</p>
                <p>Очередной успешно пройденный аудит является доказательством нашего стремления к высоким стандартам качества предлагаемых продуктов и услуг!</p>    
                <ul>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
                <ul>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
                <div class="share__social">
                    <p>Поделиться</p>
                    <div class="social__list">
                        <a href="#"></a>
                        <a href="#"></a>
                        <a href="#"></a>
                        <a href="#"></a>
                        <a href="#"></a>
                        <a href="#"></a>
                    </div>
                </div>
                <a href="#" class="btn__green">К списку новостей</a>
            </div>
                </div>
            </div>

        </div>
        
        
        
        
        
        
        
        
        
        <footer>
            <div class="container">
                <div class="footer__content">
                <div class="row">
                    <div class="col-lg-3 col-md-4">
                        <a class="footer__logo" href="#">
                            <img src="images/logo.png" alt="">
                        </a>
                    </div>
                    <div class="col-lg-2 col-md-2 col-sm-4 col-6">              
                        <ul>
                            <li><h4>Меню</h4></li>
                            <li><a href="#">Главная</a></li>
                            <li><a href="#">О компании</a></li>
                            <li><a href="#">Инвестиции</a></li>
                            <li><a href="#">Партнеру</a></li>
                            <li><a href="#">Вебинары</a></li>
                            <li><a href="#">Контакты</a></li>
                            <li><a href="#">Личный кабинет</a></li>
                        </ul>
                    </div>
                    <div class="offset-lg-1 col-lg-2 col-md-3 col-sm-4 col-6">
                        <ul>
                            <li><h4>Личный кабинет</h4></li>
                            <li><a href="#">Личные данные</a></li>
                            <li><a href="#">Панель управления</a></li>
                            <li><a href="#">История</a></li>
                            <li><a href="#">Партнеру</a></li>
                            <li><a href="#">Аналитика</a></li>
                        </ul>
                    </div>
                    <div class="offset-lg-1 col-lg-2 col-md-3 col-sm-4">
                        <ul class="footer__social">
                            <li><h4>Мы в соц сетях</h4></li>
                            <li>
                                <a href="#">
                                     <img src="images/header-icon-social-vk.png" alt="">
                                     <span>Vkontakte</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src="images/header-icon-social-tg.png" alt="">
                                    <span>Telegram</span>  
                                </a>
                                 
                            </li>
                            <li>
                                <a href="#">
                                    <img src="images/header-icon-social-inst.png" alt="">
                                    <span>Instagram</span>
                                </a>
                                
                            </li>
                            <li>
                                <a href="#">
                                 <img src="images/header-icon-social-youtube.png" alt="">     
                                 <span>YouTube</span>                            </a>
                                 
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
                <div class="footer__text offset-md-1 col-md-10">
                    <p class="offset-md-1 col-md-10">Компания FX ArtInvest имеет все необходимые документы. Деятельность по приему инвестиций, а также оказанию услуг доверительного управления осуществляется на законных основаниях. Используя сайт платформы, вы автоматически принимаете условия соглашения и обязуетесь выполнять правила системы.</p>
                    <div class="confidentialit__agreements">
                        <div class="confidentialit_list">
                            <a href="#">Публичная оферта</a> | <a href="#">Политика конфиденциальности</a> | <a href="#">Условия Использования</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer__underline"> </div>
        </footer>
    </body>
    <script src="script/jquery.js" type="text/javascript"></script>
    <script src="script/jquery-ui.min.js?v=1.2" type="text/javascript"></script>
    <script src="script/owl.carousel.min.js" type="text/javascript"></script>
    <script src="script/script.js?v=1.2" type="text/javascript"></script>
</html>