
    $(function () {

        var methods = {
            init: function (options) {

                options = $.extend({
                    type: "current"
                }, options);

                return this.each(function () {
                    methods.calendar($(this));
                });
            },
            
            calendar: function(calendar){
                    var current_year = Number(new Date().getFullYear());
                    var current_month = Number(calendar.data("month"));
                    var current_date = new Date(current_year, current_month, 1);

 

                    var count_days = new Date(current_date.getFullYear(), current_date.getMonth() + 1, 0).getDate();
                    var count_days_prev = new Date(current_date.getFullYear(), current_date.getMonth(), 0).getDate();
                    var count_days_prev_view = new Date(current_date.getFullYear(), current_date.getMonth(), 0).getDay();
                    var day_week_next = new Date(current_date.getFullYear(), current_date.getMonth(), count_days).getDay();
                    if (day_week_next == 0) {
                        day_week_next = 7;
                    }
                    var count_days_next_view = 7 - day_week_next;


                var body_options = {
                    current_year: current_year,
                    current_month: current_month,
                    count_days: count_days,
                    count_days_prev: count_days_prev,
                    count_days_prev_view: count_days_prev_view,
                    day_week_next: day_week_next,
                    count_days_next_view: count_days_next_view,
                };


                    var calendar_head = methods.head(calendar, current_year, current_month);
                    var calendar_body = methods.body(body_options);
                    var calendar_footer = methods.footer;

                    calendar.html("")
                            .append(calendar_head)
                            .append(calendar_body)
                            .append(calendar_footer);

            },

            head: function (calendar, year, month) {
                var date =  new Date(year, month, 1); 
                var months_ru = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"];
                
                return $("<div />", {
                    'class': "calendar_head"
                }).html(
                        $("<h3 />", {text: "Календарь рабочих дней Форекс"})
                        .add($('<div />', {
                            'class': 'select_date'
                        })
                                .append($("<a />", {'class': "prev_month", 'href': "#", html: "<i class='fal fa-angle-left'></i>",
                                    click: function () {
                                        calendar.calendar("prev");
                                        return false;
                                    }}))
                                .append($("<span />", {'class': "this_date", 'text': months_ru[date.getMonth()]+" "+date.getFullYear()}))
                                .append($("<a />", {'class': "next_month", 'href': "#", html: "<i class='fal fa-angle-right'></i>",
                                    click: function () {
                                        calendar.calendar("next");
                                        return false;
                                    }}))

                                )
                        );
            },
            body: function (options) {
                var calendar_days = $("<div />", {'class': "calendar_days"});

                for (d = 1; d <= options.count_days_prev_view; d++) {
                    var day = options.count_days_prev - options.count_days_prev_view + d;
                    var day_class = methods.day_classes("other_month", new Date(options.current_year, options.current_month - 1, day));
                    calendar_days.append($("<div />", {'class': day_class, html: $("<span />", {text: day})}))
                }
                for (day = 1; day <= options.count_days; day++) {
                    var day_class = methods.day_classes("current_month", new Date(options.current_year, options.current_month, day));
                    calendar_days.append($("<div />", {'class': day_class, html: $("<span />", {text: day})}))
                }
                for (d = 1; d <= options.count_days_next_view; d++) {
                    var day = d;
                    var day_class = methods.day_classes("other_month", new Date(options.current_year, options.current_month + 1, day));
                    calendar_days.append($("<div />", {'class': day_class, html: $("<span />", {text: day})}))
                }

                calendar_days.find("div.calendar_day").each(function (k, day) {
                     var day_next = calendar_days.find("div.calendar_day").eq(k + 1);
                     var day_prev = calendar_days.find("div.calendar_day").eq(k - 1);
                    if ($(day).hasClass("freeday")) {
                       
                        if (day_prev.hasClass("freeday") == false && day_next.hasClass("freeday") == true) {
                            $(day).addClass("start_freeday")
                        }else if (day_next.hasClass("freeday") == false && day_prev.hasClass("freeday") == true) {
                            $(day).addClass("end_freeday")
                        }
                    }
                    if ($(day).hasClass("holiday")) {
                        if (day_prev.hasClass("holiday") == false && day_next.hasClass("holiday") == true) {
                            $(day).addClass("start_holiday")
                        }else if (day_next.hasClass("holiday") == false && day_prev.hasClass("holiday") == true) {
                            $(day).addClass("end_holiday")
                        }
                    }
                });

                var calendar_body = $("<div />", {'class': "calendar_body"})
                        .append(
                                $("<div />", {'class': "calendar_daysweek"})
                                .append($("<div />", {'class': "calendar_dayweek", text: "ПН"}))
                                .append($("<div />", {'class': "calendar_dayweek", text: "ВТ"}))
                                .append($("<div />", {'class': "calendar_dayweek", text: "СР"}))
                                .append($("<div />", {'class': "calendar_dayweek", text: "ЧТ"}))
                                .append($("<div />", {'class': "calendar_dayweek", text: "ПТ"}))
                                .append($("<div />", {'class': "calendar_dayweek", text: "СБ"}))
                                .append($("<div />", {'class': "calendar_dayweek", text: "ВС"}))
                                )
                        .append(calendar_days);
                return calendar_body;
            },
            footer: function ( ) {

                return $("<div />", {
                    'class': "calendar_footer"
                }).append($("<span />", {'class': "today", 'text': 'Сегодня'}))
                        .append($("<span />", {'class': "holiday", 'text': 'Праздничный день'}))
                        .append($("<span />", {'class': "freeday", 'text': 'Не торговый день'}))

            },
            day_classes: function (type, date) {
                var classes = [];
                var week_day = Number(date.getDay());
                var date_format = date.getFullYear() + "-" + (Number(date.getMonth()) + 1) + "-" + date.getDate();

                classes.push("calendar_day");
                if (type == "other_month") {
                    classes.push("other_month");
                }
                var holidays = [
                    date.getFullYear()+"-1-1", 
                    date.getFullYear()+"-1-2", 
                    date.getFullYear()+"-1-3", 
                    date.getFullYear()+"-1-4", 
                    date.getFullYear()+"-1-5",
                    date.getFullYear()+"-1-6", 
                    date.getFullYear()+"-1-7", 
                    date.getFullYear()+"-1-8", 
                    date.getFullYear()+"-2-23", 
                    date.getFullYear()+"-3-8",
                    date.getFullYear()+"-5-1", 
                    date.getFullYear()+"-5-9", 
                    date.getFullYear()+"-6-12", 
                    date.getFullYear()+"-11-4"
                ];

                if (holidays.in_array(date_format)) {
                    classes.push("holiday");
                }else if (week_day == 6 || week_day == 0) {
                    classes.push("freeday");
                }
                
                if (date.getFullYear() == new Date().getFullYear() && date.getMonth() == new Date().getMonth() && date.getDate() == new Date().getDate()) {
                    classes.push("this_day");
                }
                return classes.join(' ');
            },
            prev: function ( ) {
                var current_month = Number($(this).attr("data-month"));
                $(this).data("month", current_month-1).attr({"data-month": current_month-1});
                methods.calendar($(this));
            },
            next: function ( ) {
                var current_month = Number($(this).attr("data-month"));
                $(this).data("month", current_month+1).attr({"data-month": current_month+1});
                methods.calendar($(this));
            }
        };

        $.fn.calendar = function (method) {
            if (methods[method]) {
                return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
            } else if (typeof method === 'object' || !method) {
                return methods.init.apply(this, arguments);
            } else {
                $.error('Метод с именем ' + method + ' не существует для jQuery.calendar');
            }
        };

    });


    $(function () {
        clock();
        $('.nav-toogle, .close-menu').click(function () {
            $('body').toggleClass('open_menu');
        });

        new ClipboardJS('.referal_link .copy');

// теперь можно задавать плагин с настройками по умолчанию:
        $(".calendar").calendar();

        $("form.new_deposit select[name=currency]").change(function(){
            var currency = $(this).val();
            $(".investions_plans li").addClass("hide");
            $(".investions_plans li").each(function(k, el){
                if($(el).data("currency") == currency){
                    $(el).removeClass("hide");
                }
            })
        }).change();
        
        $(".pay_systems li").click(function(){
            var currency = $(this).data("currency");
            var summa = $(this).data("summa");
            var paysystem = $(this).data("paysystem");
            var form = $(this).parents(".form_block").find("form");
            form.find("[name=currency]").val(currency);
            form.find("[name=summa]").val(summa);
            form.find("[name=paysystem]").val(paysystem);
        })
    });

    Array.prototype.in_array = function (p_val) {
        for (var i = 0, l = this.length; i < l; i++) {
            if (this[i] == p_val) {
                return true;
            }
        }
        return false;
    }


    function clock() {
        var datetime = new Date(new Date().toLocaleString("en-US", {timeZone: "Europe/Moscow"}));
        var hours = datetime.getHours();
        var minutes = datetime.getMinutes();
        var seconds = datetime.getSeconds();

        if (hours <= 9) {
            hours = "0" + hours;
        }
        if (minutes <= 9) {
            minutes = "0" + minutes;
        }
        if (seconds <= 9) {
            seconds = "0" + seconds;
        }
        $(".greeting .timer").find(".hours").text(hours);
        $(".greeting .timer").find(".minutes").text(minutes);
        $(".greeting .timer").find(".seconds").text(seconds);
        setTimeout("clock()", 1000);
    }




    !function ($) {
        "use strict"
        $.fn.dropdown = function (selector) {
            return this.each(function () {
                $(this).delegate(selector || d, 'click', function (e) {
                    var parent = $(this).parent()
                            , isActive = parent.hasClass('open')

                    clearMenus()
                    !isActive && parent.toggleClass('open')
                    return false
                })
            })
        }
        var d = 'a.menu, .dropdown-toggle'
        function clearMenus() {
            $(d).parent().removeClass('open')
        }
        $(function () {
            $('html').bind("click", clearMenus)
            $('body').dropdown('[data-dropdown] > .dropdown-toggle')
        })
        

        
    }(window.jQuery || window.ender);
