$(document).ready(function() {
    $('.owl-carousel').owlCarousel({
        loop:true,
        autoplay:false,
        autoplayTimeout:5000,
        lazyLoad: true,
        lazyLoadEager: 3,
        autoHeight: true,
        margin:0,
        nav:false,
        dots:false,
        //navText : ["<i class=\"fa fa-chevron-left\"></i>","<i class=\"fa fa-chevron-right\"></i>"],
        autoplayHoverPause:true,
        animateOut: 'fadeOut',
        responsive:{
            0:{
                items:1
            },
            600:{
                items:1
            },
            1000:{
                items:1
            }
        }
    })

    $('.owl-navigation .owl-next').click(function() {
        $('.owl-carousel').trigger('next.owl.carousel');
    });
    $('.owl-navigation .owl-prev').click(function() {
        $('.owl-carousel').trigger('prev.owl.carousel');
    });

    function numberFace(i) {
        return Math.round(i).toLocaleString();
    }

    // rub
    $("#sliderCalcRub").slider({
        min: 1000,
        max: 1000000,
        range: "min",
        value: 200000,
        step: 1000,
        start: setAmountRub,
        slide: setAmountRub,
        change: setAmountRub
    });
    function setAmountRub(event, ui) {
        var amount = ui ? ui.value : 0;
        var percent = 0;

        if(amount >= 600000) {
            percent = 1.0;
        } else if(amount >= 200000) {
            percent = 0.9;
        } else if(amount >= 30000) {
            percent = 0.8;
        } else {
            percent = 0.7;
        }
        var count1 = amount / 100 * percent;
        var count2 = count1 * 240;

        tooltipRub.text(numberFace(ui.value));
        $("#numberRub").html(numberFace(count1));
        $("#totalNumberRub").html(numberFace(count2));
    }
    var tooltipRub = $('<div class="tooltip" id="tooltipRub">200 000</div>');
    $("#sliderCalcRub .ui-slider-handle").append(tooltipRub).hover(
        function() {
            $('#tooltipRub').addClass('active');
        }, function() {
            $('#tooltipRub').removeClass('active');
        }
    );

    // dollar
    $("#sliderCalcDollar").slider({
        min: 15,
        max: 20000,
        range: "min",
        value: 4000,
        step: 15,
        start: setAmountDollar,
        slide: setAmountDollar,
        change: setAmountDollar,
    });
    function setAmountDollar(event, ui) {
        var amount = ui ? ui.value : 0;
        var percent = 0;

        if(amount >= 10000) {
            percent = 1.0;
        } else if(amount >= 3000) {
            percent = 0.9;
        } else if(amount >= 500) {
            percent = 0.8;
        } else {
            percent = 0.7;
        }
        var count1 = amount / 100 * percent;
        var count2 = count1 * 240;

        tooltipDollar.text(numberFace(ui.value));
        $("#numberDollar").html(numberFace(count1));
        $("#totalNumberDollar").html(numberFace(count2));
    }
    var tooltipDollar = $('<div class="tooltip" id="tooltipDollar">4 000</div>');
    $("#sliderCalcDollar .ui-slider-handle").append(tooltipDollar).hover(
        function() {
            $('#tooltipDollar').addClass('active');
        }, function() {
            $('#tooltipDollar').removeClass('active');
        }
    );

    $(".input").focus(function() {
        $(this).parent().addClass("is-completed");
    }), $(".input").focusout(function() {
        "" === $(this).val() && $(this).parent().removeClass("is-completed");
    });

    // bitcoin
    $("#sliderCalcBitcoin").slider({
        min: 0.015000,
        max: 1.950000,
        range: "min",
        value: 0.400000,
        step: 0.001000,
        start: setAmountBitcoin,
        slide: setAmountBitcoin,
        change: setAmountBitcoin
    });
    function setAmountBitcoin(event, ui) {
        var amount = ui ? ui.value : 0;
        var percent = 0;

        if(amount >= 600000) {
            percent = 1.0;
        } else if(amount >= 200000) {
            percent = 0.9;
        } else if(amount >= 30000) {
            percent = 0.8;
        } else {
            percent = 0.7;
        }
        var count1 = amount / 100 * percent;
        var count2 = count1 * 240;

        tooltipBitcoin.text(ui.value.toFixed(6));
        $("#numberBitcoin").html(count1.toFixed(6));
        $("#totalNumberBitcoin").html(count2.toFixed(6));
    }
    var tooltipBitcoin = $('<div class="tooltip" id="tooltipBitcoin">0.400</div>');
    $("#sliderCalcBitcoin .ui-slider-handle").append(tooltipBitcoin).hover(
        function() {
            $('#tooltipBitcoin').addClass('active');
        }, function() {
            $('#tooltipBitcoin').removeClass('active');
        }
    );


    setTimeout(function(){
        $("#sliderCalcRub").slider("value", 200000);
        $("#sliderCalcDollar").slider("value", 4000);
        $("#sliderCalcBitcoin").slider("value", 0.400000);
    }, 1000);

    $('.calc.dollar, .calc.bitcoin').fadeOut(0);

    $('.wallets button').click(function() {
        var name = $(this).attr('data-slider')
        $('.calc').fadeOut(0);
        $('.wallets button').removeClass('active');
        $('.'+name).fadeIn(0);
        $(this).addClass('active');
    });

    $('.nav-toogle, .close-menu').click(function() {
        $('.header__menu').toggleClass('active');
        $('body').toggleClass('open_menu');
    });

    $('.dropdown .dropbtn').click(function(){
        $('.dropdown').toggleClass('active');
    });

// flip 
    $('.flip-containers').click(function(){
        $('.flip-containers').removeClass('hover');
        $(this).addClass('hover');
    });
// end flip


// FAQ
 $('.faq-select .item').click(function(){
        $('.faq-select .item').removeClass('active');
        $('.faq-select .text-mob').removeClass('active');
        $('.faq .text > div').removeClass('active');
        $(this).addClass('active');
        var id = $(this).attr('data-id');
        $('.faq .text div[data-id='+id+']').addClass('active');
        $('.faq-select .text-mob[data-id='+id+']').addClass('active');
    });
  // Graphick plagin Charts
    var config = {
      type: 'line',
        data: {
            labels: ['Янв 2019', 'Фев 2019', 'Март 2019', 'Апр 2019', 'Май 2019', 'Июнь 2019', 'Июль 2019'],
            datasets: [{
                label: '',
                backgroundColor: 'rgba(89, 168, 26, 0.05)',
                borderColor: 'rgba(89, 168, 26, 1)',
                lineTension: 0, 
                data: [
                    18,16,30,35.66,30,42,38,45,60,0
                ],
                borderWidth: 2,
                fill: true,
                fillColor: "rgba(0, 0, 0, 1)",
                pointBorderColor: 'rgba(89, 168, 26, 1)',
                pointBackgroundColor: '#ffffff',
                pointRadius: 10,
                pointHoverRadius: 20,
                pointHitRadius: 40,
                pointBorderWidth: 2,
                strokeColor: "rgba(255.255,255,1)",
                pointStrokeColor: "rgba(255,255,255,1.00)",
            }]
        },
        options: {
            maintainAspectRatio: false,
            legend: {
                display: false,
                position: 'top',
                labels: {
                    boxWidth: 80,
                    fontColor: 'black'
                }
            },
            responsive: true,
            title: {
                display: false,
                text: 'Chart.js Line Chart'
            },
            tooltips: {
                intersect: false,
                yPadding: 10,
                xPadding: 14,
                x: 100,
                y: 100,
                caretSize: 6,
                caretX: 70,
                caretY: 70,
                caretHeight: 200,
                xAlign: 'bottom',
                backgroundColor: 'rgba(89, 168, 26, 1)',
                titleFontColor: '#000000',
                titleFontSize: 0,
                titleMarginBottom: -4,
                bodyFontSize: 17,
                bodyFontStyle: '600',
                bodySpacing: 20,
                bodyFontFamily: 'Roboto',
                cornerRadius: 12,
                bodyFontColor: '#ffffff',
                borderColor: 'rgba(0,0,0,1)',
                borderWidth: 1,
                footerMarginTop: 10,
                footerMarginBottom: 100,
                footerSpacing: 50,
                callbacks: {
                    callback: function (value) { 
                        if (value == 0 || value == 20 || value == 40 || value == 60) { 
                            return value+'%';
                        } 
                    },
                    labelColor: function(tooltipItem, chart) {
                        return {
                            borderColor: 'rgb(255, 0, 0)',
                            backgroundColor: 'rgb(255, 0, 0)'
                        };
                    },
                    labelTextColor: function(tooltipItem, chart) {
                        return '#543453';
                    },
                    label: function(tooltipItems, data) { 
                        return tooltipItems.yLabel + "%";
                    }
                }
            },
            hover: {
                mode: 'nearest',
                intersect: true
            },
            scales: {
                xAxes: [{
                    display: true,
                    scaleLabel: {
                        display: false,
                        labelString: 'Month'
                    },
                    gridLines: {
                        color: "rgba(0, 0, 0, 0)",
                        drawOnChartArea: true,
                        lineWidth: 7,
                    },
                    tooltipFormat: 'll HH:mm',
                    ticks: {
                        fontSize: 13,
                        fontColor: '#a0acb9',
                        tickMarkLength: 30,
                    }
                }],
                yAxes: [{
                    display: true,
                    scaleLabel: {
                        display: false,
                        labelString: 'Value'
                    },
                    ticks: {
                        beginAtZero: true,
                        callback: function (value) { 
                            if (value == 0 || value == 20 || value == 40 || value == 60) { 
                                return value+'%      ';
                            } 
                        },
                        min: 0,
                        fontSize: 20,
                        fontColor: '#a0acb9',
                        tickMarkLength: 30,
                    }
                }]
            }
        }
    };

    Chart.defaults.global.defaultFontFamily = "Roboto";
    Chart.defaults.global.defaultFontSize = 15;

    var ctx = document.getElementById('line-chart').getContext('2d');
    var lineChart = new Chart(ctx, config);

    var originalStroke = ctx.stroke;
    ctx.stroke = function () {
        ctx.save();
        ctx.shadowColor = 'rgba(89, 168, 26, 0.4)';
        ctx.shadowBlur = 20;
        ctx.shadowOffsetX = -0;
        ctx.shadowOffsetY = -10;
        originalStroke.apply(this, arguments)
        ctx.restore();
    }
});


!function ($) {
    "use strict"
    $.fn.dropdown = function (selector) {
        return this.each(function () {
            $(this).delegate(selector || d, 'click', function (e) {
                var parent = $(this).parent()
                        , isActive = parent.hasClass('open')

                clearMenus()
                !isActive && parent.toggleClass('open')
                return false
            })
        })
    }
    var d = 'a.menu, .dropdown-toggle'
    function clearMenus() {
        $(d).parent().removeClass('open')
    }
    $(function () {
        $('html').bind("click", clearMenus)
        $('body').dropdown('[data-dropdown] > .dropdown-toggle')
    })
    
}(window.jQuery || window.ender);
