<?php

session_start();
ob_start();
//if(!empty($_POST["PAYMENT_ID"])){
//    $fileopen=fopen("pm.txt", "a+");
//    fwrite($fileopen, "----".serialize($_SERVER["REDIRECT_URL"])."\r\n");
//    fwrite($fileopen, "0----".serialize($_POST)."\r\n");
//    fclose($fileopen);
//}

require_once ("config.php" );
require(CLASSES . "/includeDB.php" );
$DB = DB::dbinc();
require(CLASSES . "/date.php" );
require(CLASSES . "/data.php" );
require(CLASSES . "/form.php" );
require(CLASSES . "/file.php" );
require(CLASSES . "/message.php" );
require(CLASSES . "/language.php" );
require(CLASSES . "/config.php" );

require(CLASSES . "/controller.php" );
require(CLASSES . "/url.php" );

$URL = new url();
$URL->urlcheck();

require(CLASSES . "/access.php" );
$access = access::check_session();

if (!empty($URL)) {
    $urlDataArr = controller::getStringToGetArray($URL->url);
} else {
    $urlDataArr = $_GET;
}

language::change();



//Начисления по депозитам
$URL->get_to_component(["com"=>"invest", "act"=>"accrual"]);
if(!empty($_GET["ref"])){
    $URL->get_to_component(["com"=>"user", "act"=>"referal_session"]);
}


if ($URL->access == 1 && $access == false) {
    if (!empty($urlDataArr["view"])) {
        controller::redirect("/");
    } else {
        echo "no access";
        exit; 
    }
}

$data = $URL->get_to_component($urlDataArr);


if (
        (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || 
        $urlDataArr["ajax"] == 1 || 
        $_GET["ajax"] == 1) {
    if (is_object($data)) {
        echo $data->content;
    } elseif (is_string($data)) {
        echo $data;
    }
    exit;
}

if (empty($data)){
    controller::redirect("/");
}
    
if (file_exists(TEMPLATE_PATH . "/" . $URL->template . ".php")) {
    require( TEMPLATE_PATH . "/" . $URL->template . ".php");
}else{
    require( TEMPLATE_PATH . "/default.php" );
}
$template = ob_get_clean();

$siteBlocks['title'] = language::lang_text((!empty($data->title)) ? $data->title : $URL->title);
$siteBlocks['description'] = language::lang_text((!empty($data->description)) ? $data->description : $URL->description);
$siteBlocks['keywords'] = language::lang_text((!empty($data->keywords)) ? $data->keywords : $URL->keywords);

$siteBlocks['scripts'] = $data->scripts;

$siteBlocks['content_head'] = $data->content_head;
$siteBlocks['content'] = $data->content;

$siteBlocks['lk_sidebar']   = $URL->get_to_component(["com" => "menu", "view" => "user_menu"]);
$siteBlocks['footer']       = $URL->get_to_component(["com" => "common", "view" => "footer"]);
$siteBlocks['head']         = $URL->get_to_component(["com" => "common", "view" => "head"]);
$siteBlocks['lk_head']      = $URL->get_to_component(["com" => "common", "view" => "lk_head"]);

//$siteBlocks['footer_menu']  = $siteBlocks['top_menu'];

foreach ($siteBlocks as $k_blocks => $data_block) {
    if (is_object($data_block)) {
        $template = str_replace("{" . $k_blocks . "}", $data_block->content, $template);
    } elseif (is_string($data_block)) {
        $template = str_replace("{" . $k_blocks . "}", $data_block, $template);
    } else {
        $template = str_replace("{" . $k_blocks . "}", "", $template);
    }
}



echo $template;


unset($_SESSION['message']);
unset($DB);
unset($URL);
exit;
