<?php

class config {

    function get($data, $format = "all") {
        $where = "";
        if($format != "all"){
            $format = "row";
        }
        
        if (!empty($data["name"])) {
            $where .= " AND `name` = '{$data["name"]}' ";
        }
        if (!empty($data["type"])) {
            $where .= " AND `type` = '{$data["type"]}' ";
        }
        $sql = "SELECT * FROM `config` WHERE 1=1 $where ";
        $result = DB::select($sql, $format);
        return $result;
    }

}
