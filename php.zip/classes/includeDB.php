<?php

class DB {

    public function dbinc() {
        try {
            $db = new PDO(DB_DSN, DB_USERNAME, DB_PASSWORD);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $db->exec("set names utf8");
            if (isset($_SESSION) && !empty($_SESSION['user']['id'])) {
                $time_zone = $_SESSION['user']['time_zone'];
                $db->exec("set time_zone = '$time_zone:00'");
            } else {
                $db->exec("set time_zone = '+3:00'");
            }
        } catch (PDOException $e) {
                echo 'Connection error: ' . $e->getMessage();
                die();
        } 
        // $options = array( PDO:: MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8');
        // $db = new PDO( DB_DSN, DB_USERNAME, DB_PASSWORD, $options);
        return $db;
    }

    static function insert($sql, $data) {
        global $DB;
        if (empty($sql) || empty($data)) {
            return false;
        }
        foreach ($data as $key => $value) {
            $set1[] = "`$key`";
            $set2[] = ":$key";
        }

        $set1_str = implode(', ', $set1);
        $set2_str = implode(', ', $set2);
        $set_str = '(' . $set1_str . ') VALUES (' . $set2_str . ')';

        $sql = preg_replace("#\?set#is", $set_str, $sql);
        $st = $DB->prepare($sql);
        foreach ($data as $key => $value) {
            $st->bindValue(":$key", $value);
        }
        return array('return' => $st->execute(), 'id' => $DB->lastInsertId());
    }

    static function update($sql, $data) {
        if (empty($sql) || empty($data)) {
            return false;
        }
        global $DB;
        foreach ($data as $key => $value) {
            $set[] = "`$key`=:$key";
        }
        $set_str = implode(', ', $set);

        $sql = preg_replace("#\?set#is", $set_str, $sql);
        $st = $DB->prepare($sql);
        foreach ($data as $key => $value) {
            $st->bindValue(":$key", $value);
        }

        return array('return' => $st->execute(), 'count' => $st->rowCount());
    }

    static function select($sql, $fetch = 'row', $count = false) {
        global $DB;
        $st = $DB->query($sql);
        $st->setFetchMode(PDO::FETCH_OBJ);
        if ($fetch == 'row') {
            $fetch_fn = 'fetch';
        } elseif ($fetch == 'all') {
            $fetch_fn = 'fetchAll';
        } elseif ($fetch == 'column') {
            $fetch_fn = 'fetchColumn';
        } elseif ($fetch == 'attribute') {
            $fetch_fn = 'getAttribute';
        } elseif ($fetch == 'attribute') {
            $fetch_fn = 'rowCount';
        }
        if ($count == true) {
            return array('return' => $st->$fetch_fn(PDO::FETCH_ASSOC), 'count' => $st->rowCount());
        } else {
            return $st->$fetch_fn(PDO::FETCH_ASSOC);
        }
    }

    static function delete($sql) {
        global $DB;
        return $DB->exec($sql);
    }

}

?>
