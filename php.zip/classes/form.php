<?php

class form {

   // static function select($data, $dafault = null, $name = null, $class = null, $multiple = false, $size = 1, $key_null = true, $required = false) {
    static function select($data = array()) {
        $return = '';
        $required = ($data["required"] == true) ? 'required' : '';

        
        if (!empty($data['list'])) {
   
            $return .= ($data["multiple"] == false) ? "<select $required size='{$data["size"]}' name='{$data["name"]}' class='{$data["class"]}'>" : "<select $required size='{$data["size"]}' multiple name='{$data["name"]}' class='{$data["class"]}'>";
            
            
            foreach ($data['list'] as $key => $text) {
                $key_value = $key;
                if($key === 0 && $key_null === false){
                    $key_value = "";
                }
                if (is_array($data["dafault"]) == true) {
                    if (in_array($key, $data["dafault"]) == true) {
                        $return .= "<option value='$key_value' selected='selected'>$text</option>";
                        if($data["multiple"] == false){
                            unset($data["dafault"][$key]);
                        }
                    } else {
                        $return .= "<option value='$key_value'>$text</option>";
                    }
                } else {
                    $return .= ($data["dafault"] == $key) ? "<option value='$key_value' selected='selected'>$text</option>" : "<option value='$key_value'>$text</option>";
                }
            }
            $return .= '</select>';
        }
        return $return;
    }
    
        
   function list_checkbox($data) {
        $return = '';
        if (is_array($data["checked"]) == false) {
            $data["checked"] = explode(',', $data["checked"]);
        }
        if (!empty($data['list'])) {
            foreach ($data['list'] as $key => $text) {
                if (!empty($data["start_wrp"])) {
                    $return .= $data["start_wrp"];
                }
                $checked = (in_array($key, $data["checked"])) ? "checked" : "";
                $return .= " <input type='checkbox' value='$key' name='" . $data['name'] . "' $checked/> ".$text ;
                if (!empty($data["end_wrp"])) {
                    $return .= $data["end_wrp"];
                }
            }
        }
        return $return;
    }
    
    function list_radio($data) {
        $return = '';
        if (!empty($data['list'])) {
            foreach ($data['list'] as $key => $text) {
                if (!empty($data["start_wrp"])) {
                    $return .= $data["start_wrp"];
                }
                $checked = ($key == $data["checked"]) ? "checked" : "";
                $return .= " <input type='radio' value='$key' name='" . $data['name'] . "' $checked/> ".$text ;
                if (!empty($data["end_wrp"])) {
                    $return .= $data["end_wrp"];
                }
            }
        }
        return $return;
    }

}
