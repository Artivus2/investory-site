<?php

class file {

    // Функция изменения размера
    // Изменяет размер изображения в зависимости от type:
    //	type = 1 - Оставляем размер. Но не более 800
    // 	type = 2 - большое изображение
    //	rotate - поворот на количество градусов (желательно использовать значение 90, 180, 270)
    //	quality - качество изображения (по умолчанию 75%)
    function resize($file, $dir, $new_name, $size = null, $rotate = null, $quality = null) {


        // Качество изображения по умолчанию
        if ($quality == null)
            $quality = 75;

        // Cоздаём исходное изображение на основе исходного файла
        if ($file['type'] == 'image/jpeg') {
            $source = imagecreatefromjpeg($file['tmp_name']);
        } elseif ($file['type'] == 'image/png') {
            $source = imagecreatefrompng($file['tmp_name']);
            //Отключаем режим сопряжения цветов
            imagealphablending($source, false);

//Включаем сохранение альфа канала
            imagesavealpha($source, true);
        } elseif ($file['type'] == 'image/gif') {
            $source = imagecreatefromgif($file['tmp_name']);
        } else {
            return false;
        }
        // Поворачиваем изображение
        if ($rotate != null)
            $src = imagerotate($source, $rotate, 0);
        else
            $src = $source;

        // Определяем ширину и высоту изображения
        $w_src = imagesx($src);
        $h_src = imagesy($src);
     
        // Если ширина больше заданной
        if ($w_src > $h_src) {
            // Вычисление пропорций
            $ratio = $h_src / $size;
            
            $w_dest = round($w_src / $ratio);
            $h_dest = $size;
            $offset = round($w_dest - $size);
            $w_dest = $size;       
            
            // Создаём пустую картинку
            $dest = imagecreatetruecolor($size, $size);
               
            imageAlphaBlending($dest, false);
            imageSaveAlpha($dest, true);
            // Копируем старое изображение в новое с изменением параметров
            imagecopyresampled($dest, $src, 0, 0, $w_dest, 0, $w_dest, $h_dest, $w_src-$offset*$ratio, $h_src);
            // Вывод картинки и очистка памяти           
            if ($file['type'] == 'image/png') {
                imagepng($dest, $dir . $new_name);
            } else {
                imagejpeg($dest, $dir . $new_name, $quality);
            }
            imagedestroy($dest);
            imagedestroy($src);
            return $dir . $new_name;
        }elseif ($h_src > $w_src) {
            // Вычисление пропорций
            $ratio = $w_src / $size;
            
            $h_dest = round($h_src / $ratio);
            $w_dest = $size;
            $offset = round($h_dest - $size);
            $h_dest = $size;       
            
            // Создаём пустую картинку
            $dest = imagecreatetruecolor($size, $size);
               
            imageAlphaBlending($dest, false);
            imageSaveAlpha($dest, true);
            // Копируем старое изображение в новое с изменением параметров
            imagecopyresampled($dest, $src, 0, 0, 0, $w_dest, $w_dest, $h_dest, $w_src, $h_src-$offset*$ratio);
            // Вывод картинки и очистка памяти           
            if ($file['type'] == 'image/png') {
                imagepng($dest, $dir . $new_name);
            } else {
                imagejpeg($dest, $dir . $new_name, $quality);
            }
            imagedestroy($dest);
            imagedestroy($src);
            return $dir . $new_name;
        } else {
            // Вычисление пропорций
            $h_dest = $size;
            $w_dest = $size;
            
            // Создаём пустую картинку
            $dest = imagecreatetruecolor($h_dest, $w_dest);
               
            imageAlphaBlending($dest, false);
            imageSaveAlpha($dest, true);
            // Копируем старое изображение в новое с изменением параметров
            imagecopyresampled($dest, $src, 0, 0, 0, 0, $h_dest, $w_dest, $w_src, $h_src);
            // Вывод картинки и очистка памяти           
            if ($file['type'] == 'image/png') {
                imagepng($dest, $dir . $new_name);
            } else {
                imagejpeg($dest, $dir . $new_name, $quality);
            }
            imagedestroy($dest);
            imagedestroy($src);
            return $dir . $new_name;
        }
    }

    //Плучение расштрение из файла
    function getExtension($str) {
        $i = strrpos($str, ".");
        if (!$i) {
            return "";
        }
        $l = strlen($str) - $i;
        $ext = substr($str, $i + 1, $l);
        return $ext;
    }
}
