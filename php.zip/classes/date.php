<?php

class date {
    
    function dateformat($data) {
        $return = "";
        if (empty($data["date"])) {
            $data["date"] = date("Y-m-d H:i:s");
        }
        
        $date_split = self::dateSplit($data["date"]);
        $date_split["month"] = self::monthText($date_split["month"], 1);
        $return .= $date_split["day"] . " " . $date_split["month"];
        if ($data["year"]) {
            $return .= " " . $date_split["year"];
        }
        if ($data["time"]) {
            $return .= " " . $date_split["hour"] . " " . $date_split["minute"];
        }
        return $return;
    }


    function timeFormat($date, $type) {
        $dateblok = explode(' ', $date);
        $time = explode(':', $dateblok[1]);
        $return['hour'] = $time[0];
        $return['minute'] = $time[1];
        $return['second'] = $time[2];

        switch ($type) {
            case 'h:m':
                return $return['hour'] . ':' . $return['minute'];
                break;

            default :
                return $return['hour'] . ':' . $return['minute'] . ':' . $return['second'];
        }
    }
    
   
    function dateFormatView($data = array()) {
        $data["datenull"] = (empty($data["datenull"])) ? "<small>Не указана</small>" : $data["datenull"];
        $data["formatReturn"] = (!isset($data["formatReturn"])) ? 0 : $data["formatReturn"];
        $data["time"] = (!isset($data["time"])) ? true : $data["time"];
        $data["realtime"] = (!isset($data["realtime"])) ? true : $data["realtime"];
        $data["dateformat"] = (!isset($data["dateformat"])) ? "d.m.Y" : $data["dateformat"];
        $data["timeformat"] = (!isset($data["timeformat"])) ? "H:i" : $data["timeformat"];
        $data["time_zone"] = (!isset($data["time_zone"])) ? $_SESSION['user']["time_zone"] : $data["time_zone"];

        if ($data["datetime"] == '0000-00-00 00:00:00' || $data["datetime"] == null || $data["datetime"] == '0000-00-00') {
            return $data["datenull"];
        }

        $datetime = $data["datetime"];
        $time_diff = intval(str_replace('+', '', $data["time_zone"])) - 3;
        
        $datetime_real = date("Y-m-d H:i:s", ($data["time_zone"] !== false) ? strtotime("$time_diff hour", strtotime($data["datetime"])) : strtotime($data["datetime"]));
        
        if ($data["realtime"] == true) {
            $data["datetime"] = $datetime_real;
        } elseif ($data["formatReturn"] == 2) {
            $datetime = date("Y-m-d H:i:s", ($data["time_zone"] !== false) ? strtotime("$time_diff hour", strtotime($data["datetime"])) : strtotime($data["datetime"]));
        }

        $month = date("m", strtotime($data["datetime"]));
        if ($data["month"] == "text") {
            $monthText = date::monthText($month, 0);
            $data["dateformat"] = str_replace("m", $monthText, $data["dateformat"]);
        } elseif ($data["month"] == "text1") {
            $monthText = date::monthText($month, 1);
            $data["dateformat"] = str_replace("m", $monthText, $data["dateformat"]);
        }

        $date = date($data["dateformat"], strtotime($data["datetime"]));
        if ($data["time"] == true) {
            $time = date($data["timeformat"], strtotime($data["datetime"]));

            if ($data["formatReturn"] == 0) {
                $return = $date . " <small>" . $time . "</small>";
            } elseif ($data["formatReturn"] == 2) {
                $return = "<span class='tooltips' data-original-title='МСК " . date($data["dateformat"] . " " . $data["timeformat"], strtotime($datetime)) . "' data-placement='top' data-container='body'>" . $date . " " . $time . "</span>";
            } elseif ($data["formatReturn"] == 1) {
                $return = $date;
                if(!empty($date) && !empty($time)){
                    $return.= " ";
                }
                 $return.= $time;
            }
        } else {
            $return = $date;
        }



        return trim($return);
    }


    function dateDiffView($date) {

        if ($date > 0) {

            $hour = floor($date / 3600);

            $minute = floor(($date - ($hour * 3600)) / 60);
            return $hour . "<small>ч</small> : " . $minute . "<small>мин</small>";
        } else {
            return "0мин";
        }
    }

//$dec = склонение 1/2

    function monthText($month = null, $dec = null, $demo = null) {
         $month = (strlen($month) == 1) ? '0'.$month : $month;
        if ($dec == 1) {
            $monthArr = array(
                '01' => "Января",
                '02' => "Февраля",
                '03' => "Марта",
                '04' => "Апреля",
                '05' => "Мая",
                '06' => "Июня",
                '07' => "Июля",
                '08' => "Августа",
                '09' => "Сентября",
                '10' => "Октября",
                '11' => "Ноября",
                '12' => "Декабря",
            );
        } else {
            $monthArr = array(
                '01' => "Январь",
                '02' => "Февраль",
                '03' => "Март",
                '04' => "Апрель",
                '05' => "Май",
                '06' => "Июнь",
                '07' => "Июль",
                '08' => "Август",
                '09' => "Сентябрь",
                '10' => "Октябрь",
                '11' => "Ноябрь",
                '12' => "Декабрь",
            );
        }
        if ($demo == true) {
            $monthArr = array(
                '01' => "Янв",
                '02' => "Фев",
                '03' => "Мар",
                '04' => "Апр",
                '05' => "Май",
                '06' => "Июн",
                '07' => "Июл",
                '08' => "Авг",
                '09' => "Сен",
                '10' => "Окт",
                '11' => "Ноя",
                '12' => "Дек",
            );
        }
        if ($month != null) {
            return $monthArr[$month];
        } else {
            return $monthArr;
        }
    }

    //$ru Для русского формата (перый понедельник)
    //$day день недели
    function day_week_text($day, $ru = false, $demo=false) {
        if ($demo == false) {
            $day_week = array("Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"); 
        }elseif($demo == true){
            $day_week = array("Вск", "Пон", "Втор", "Ср", "Четв", "Пят", "Суб", "Вск"); 
        }
        if($ru == true){
            if($day=6){
                $day = 0;
            }else{
                $day = $day+1;
            }
        }
        return $day_week[$day];
    }

    /*
     * $date (string) 0000-00-00 00:00:00
     */

// Date difference function. Will be using below
    function datediff($dateto, $interval = null, $type = 1, $using_timestamps = false) {
        /*
          $interval can be:
          yyyy - Number of full years
          q - Number of full quarters
          m - Number of full months
          y - Difference between day numbers
          (eg 1st Jan 2004 is "1", the first day. 2nd Feb 2003 is "33". The datediff is "-32".)
          d - Number of full days
          w - Number of full weekdays
          ww - Number of full weeks
          h - Number of full hours
          n - Number of full minutes
          s - Number of full seconds (default)
         */
        //$type - 0 thisdate-dateto
        //$type - 1  dateto-thisdate
// select the timezone for your countdown
        $timezone = trim($_GET['timezone']);
//putenv("TZ=$timezone");
// Getting the current time
        $datefrom = date("Y-m-d H:i:s"); // current time -- NO NEED TO CHANGE

        if (!$using_timestamps) {
            $datefrom = strtotime($datefrom, 0);
            $dateto = strtotime($dateto, 0);
        }
        if ($type == 1) {
            $difference = $dateto - $datefrom; // Difference in seconds
        } else {
            $difference = $datefrom - $dateto; // Difference in seconds
        }
        switch ($interval) {

            case 'yyyy': // Number of full years

                $years_difference = floor($difference / 31536000);
                if (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom), date("j", $datefrom), date("Y", $datefrom) + $years_difference) > $dateto) {
                    $years_difference--;
                }
                if (mktime(date("H", $dateto), date("i", $dateto), date("s", $dateto), date("n", $dateto), date("j", $dateto), date("Y", $dateto) - ($years_difference + 1)) > $datefrom) {
                    $years_difference++;
                }
                $datediff = $years_difference;
                break;

            case "q": // Number of full quarters

                $quarters_difference = floor($difference / 8035200);
                while (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom) + ($quarters_difference * 3), date("j", $dateto), date("Y", $datefrom)) < $dateto) {
                    $months_difference++;
                }
                $quarters_difference--;
                $datediff = $quarters_difference;
                break;

            case "m": // Number of full months

                $months_difference = floor($difference / 2678400);
                while (mktime(date("H", $datefrom), date("i", $datefrom), date("s", $datefrom), date("n", $datefrom) + ($months_difference), date("j", $dateto), date("Y", $datefrom)) < $dateto) {
                    $months_difference++;
                }
                $months_difference--;
                $datediff = $months_difference;
                break;

            case 'y': // Difference between day numbers

                $datediff = date("z", $dateto) - date("z", $datefrom);
                break;

            case "d": // Number of full days

                $datediff = floor($difference / 86400);
                break;

            case "w": // Number of full weekdays

                $days_difference = floor($difference / 86400);
                $weeks_difference = floor($days_difference / 7); // Complete weeks
                $first_day = date("w", $datefrom);
                $days_remainder = floor($days_difference % 7);
                $odd_days = $first_day + $days_remainder; // Do we have a Saturday or Sunday in the remainder?
                if ($odd_days > 7) { // Sunday
                    $days_remainder--;
                }
                if ($odd_days > 6) { // Saturday
                    $days_remainder--;
                }
                $datediff = ($weeks_difference * 5) + $days_remainder;
                break;

            case "ww": // Number of full weeks

                $datediff = floor($difference / 604800);
                break;

            case "h": // Number of full hours

                $datediff = floor($difference / 3600);
                break;

            case "n": // Number of full minutes

                $datediff = floor($difference / 60);
                break;

            default: // Number of full seconds (default)

                $datediff = $difference;
                break;
        }

        return $datediff;
    }

    /*
     * переводим минуты в день/час/минута
     */

    function secToDate($datediff, $null = true) {
        $datediffD = 0;
        $datediffh = 0;
        $datediffi = 0;
        if ($datediff >= 1440) {
            $datediffD = floor($datediff / 1440); //количество дней
            $datediffh = floor(($datediff - ($datediffD * 1440)) / 60);
            $datediffi = ($datediff - ($datediffD * 1440)) % 60;
        } elseif ($datediff < 1440 and $datediff >= 60) {
            $datediffD = 0;
            $datediffh = floor(($datediff - ($datediffD * 1440)) / 60);
            $datediffi = ($datediff - ($datediffD * 1440)) % 60;
        } elseif ($datediff < 60 and $datediff >= 1) {
            $datediffi = ($datediff - ($datediffD * 1440)) % 60;
        }
        if ($null == true) {

            //если показывать нулевые дни, часы и минуты
            $datediffText = $datediffD . ' д ' . $datediffh . ' ч ' . $datediffi . ' мин';
        } else {

            //НЕ ПОКАЗЫВАТЬ нулевые дни часы и минуты
            if ($datediffD == '0') {
                if ($datediffh == '0') {
                    $datediffText = $datediffi . ' мин';
                } else {
                    $datediffText = $datediffh . ' ч ' . $datediffi . ' мин';
                }
            } else {
                $datediffText = $datediffD . ' д ' . $datediffh . ' ч ' . $datediffi . ' мин';
            }
        }
        return $datediffText;
    }


    function dateSplit($date) {
        $dateblok = explode(' ', $date);
        $date = explode('-', $dateblok[0]);
        $time = explode(':', $dateblok[1]);

        $return['year'] = $date[0];
        $return['month'] = $date[1];
        $return['day'] = $date[2];

        $return['hour'] = $time[0];
        $return['minute'] = $time[1];
        $return['second'] = $time[2];
        return $return;
    }

}

?>
