<?php

class message {

    function new_msg($name, $type, $text) {
        $_SESSION["message"][$name] = ["type" => $type, "text" => $text];
    }

    function msg($name, $before_html="", $affter_html="") {
        $return = "";
        if (!empty($_SESSION["message"][$name])) {
            if(empty($before_html)){
                $before_html = "<div class='alert alert-{$_SESSION["message"][$name]["type"]}'>";
            }
            if(empty($affter_html)){
                $affter_html = "</div>";
            }
            
            $return .= $before_html;
            $return .= language::lang_text($_SESSION["message"][$name]["text"]);
            $return .= $affter_html;
        }
        unset($_SESSION["message"][$name]);
        return $return;
    }
    
    function is_msg($name, $type = ""){
        if(empty($_SESSION["message"][$name])){
            return false;
        }
        if(!empty($type) && $_SESSION["message"][$name]["type"] != $type){
            return false;
        }
        return true;
    }

}
