<?php

class Controller {

    /*
    public function getMenu($get) {

        $get = Controller::getFormat($get);


        if ($get["com"] != '') {
            require( COM_PATH . "/" . $get["com"] . "/com_" . $get["com"] . ".php");
            $componentClass = "com" . $get["com"];

            $return = $componentClass::construct($get);

            return $return;
        } else {
            require( COM_PATH . "/ankets/com_ankets.php" );
            return comAnkets::construct($get);
        }
    }

    function type_request_ajax($url_data) {
        if ((isset($_SERVER['HTTP_X_REQUESTED_WITH']) && !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || $_GET['ajax'] || !empty($url_data['url']['ajax'])) {
            return true;
        }
        return false;
    }

    function data($url_data) {
        global $URL;
        if (!empty($url_data)) {
            parse_str($url_data['url'], $urlDataArr);
        } else {
            $urlDataArr = $_GET;
        }

        $data = $URL->get_to_component($urlDataArr);

        if (controller::type_request_ajax($url_data) == true) {
            echo $data;
            //echo (is_array($data))? json_encode($data): $data;
            exit;
        } elseif (empty($data)) {
            controller::redirect("/");
        }
        return $data;
    }

    function data_to_template($template, $blocks) {
        //$siteBlocks['list_stores'] = $URL->get_to_component(array('com' => 'stores', 'view' => 'list_stores'));
        //$siteBlocks['sidebar_shop'] = ($url_data['alias'] == "shop") ? $data->sidebar_shop : "";
        //$siteBlocks['init_script'] = $data->init_script;

        foreach ($blocks as $k_blocks => $block) {
            if (is_object($block)) {
                $template = str_replace("{" . $k_blocks . "}", $block->content, $template);
            } elseif (is_string($block)) {
                $template = str_replace("{" . $k_blocks . "}", $block, $template);
            } else {
                $template = str_replace("{" . $k_blocks . "}", "", $template);
            }
        }

        return $template;
    }

    function template($url_data) {
        $template = $url_data["template"];
        if (file_exists(TEMPLATE_PATH . "/$template/index.php")) {
            require( TEMPLATE_PATH . "/$template/index.php" );
        } elseif (file_exists(TEMPLATE_PATH . "/$template.php")) {
            require( TEMPLATE_PATH . "/$template.php" );
        }
        return ob_get_clean();
    }
*/
    function getStringToGetArray($url) {
        $getString = str_replace('?', '', $url);
        $newVars = array();
        parse_str($getString, $newVars);
        return $newVars;
    }

    function getFormat($get) {
        $lin["com"] = isset($get['com']) ? $get['com'] : "";
        $lin["view"] = isset($get['view']) ? $get['view'] : "";
        $lin["act"] = isset($get['act']) ? $get['act'] : "";
        $lin["id"] = isset($get['id']) ? $get['id'] : "";
        $lin["type"] = isset($get['type']) ? $get['type'] : "";
        $lin["status"] = isset($get['status']) ? $get['status'] : "";
        return $lin;
    }

    //переадресация на другой номер
    function redirect($link = null, $dop_link = "") {

        if ($link == "") {
            $url = $_SERVER["HTTP_REFERER"];
        } else {
            $url = $link;
        }
        if (!empty($dop_link)) {
            $url = Controller::add_get_url($dop_link, $url);
        }
        header("Location: $url");
        flush();
        // echo "<script type='text/javascript'>document.location = '$url';</script>";
        exit;
    }

    function returnUrl($link = null) {
        $link = Controller::getStringToGetArray($link);

        return Controller::getMenu($link);
    }

    function urlToGetString($url) {
        
    }

    function generateNumer($length = 8) {
        $chars = '0123456789';
        $numChars = strlen($chars);
        $string = '';
        for ($i = 0; $i < $length; $i++) {
            $string .= substr($chars, rand(1, $numChars) - 1, 1);
        }
        return $string;
    }

    function translitText($text) {

        $converter = array(
            'а' => 'a', 'б' => 'b', 'в' => 'v',
            'г' => 'g', 'д' => 'd', 'е' => 'e',
            'ё' => 'e', 'ж' => 'zh', 'з' => 'z',
            'и' => 'i', 'й' => 'y', 'к' => 'k',
            'л' => 'l', 'м' => 'm', 'н' => 'n',
            'о' => 'o', 'п' => 'p', 'р' => 'r',
            'с' => 's', 'т' => 't', 'у' => 'u',
            'ф' => 'f', 'х' => 'h', 'ц' => 'c',
            'ч' => 'ch', 'ш' => 'sh', 'щ' => 'sch',
            'ь' => '', 'ы' => 'y', 'ъ' => '',
            'э' => 'e', 'ю' => 'yu', 'я' => 'ya',
            'А' => 'A', 'Б' => 'B', 'В' => 'V',
            'Г' => 'G', 'Д' => 'D', 'Е' => 'E',
            'Ё' => 'E', 'Ж' => 'Zh', 'З' => 'Z',
            'И' => 'I', 'Й' => 'Y', 'К' => 'K',
            'Л' => 'L', 'М' => 'M', 'Н' => 'N',
            'О' => 'O', 'П' => 'P', 'Р' => 'R',
            'С' => 'S', 'Т' => 'T', 'У' => 'U',
            'Ф' => 'F', 'Х' => 'H', 'Ц' => 'C',
            'Ч' => 'Ch', 'Ш' => 'Sh', 'Щ' => 'Sch',
            'Ь' => '', 'Ы' => 'Y', 'Ъ' => '',
            'Э' => 'E', 'Ю' => 'Yu', 'Я' => 'Ya',
        );
        $newtext = strtr($text, $converter);

        return $newtext;
    }

    /* ОБРЕЗКА ТЕКСТА ДО ОПРЕДЕЛЕННОЙ ДЛИНЫ
     * 
     * $string - Текст который будем обрезать
     * $length - длина до которой обрезаем текст
     */

    function trimmingText($string, $length) {
        $string = strip_tags($string);
        $string = mb_substr($string, 0, $length);
        $string = rtrim($string, "!,.-");
        // $string =  mb_substr($string, 0, mb_strrpos($string, ' '));

        return $string;
    }

    //Форматирование сот. телефона в формат 79001234567
    function phoneformat($phone, $seven = true) {
        //удаляем все символы из пароля, оставляем только цыфры
        $phone = preg_replace('/\D/', '', $phone);
        //Проверяем количество символов, если 8ка не введена то все хорошо. 
        //иначе проверяем первый символ если он 8ка или 7ка то стираеим его
        if ($phone[0] == "8" || $phone[0] == "7") {
            $phone = substr($phone, 1);
        }
        $count = 10;
        if ($seven == true) {
            //Добавляем вначале 7ку
            $phone = '7' . $phone;
            $count = 11;
        }
        
        //Финальная проверка на наличие одних цыфр и на количество символов
        if (!preg_match('/[0-9]{' . $count . '}/i', $phone)) {
            return false;
        } else {
            return $phone;
        }
    }

    //Форматирование сот. телефона в формат 8 900 123 4567
    function phoneFormatBack($phone) {

        $phoneN = "";
        for ($x = 0; $x < strlen($phone); $x++) {
            //var_dump($x)
            if ($x == 0) {
                if ($phone[$x] == 7) {
                    $phone[$x] = 8;
                }
                $phoneN .= $phone[$x] . ' ';
            } elseif ($x == 3) {
                $phoneN .= $phone[$x] . ' ';
            } elseif ($x == 6) {
                $phoneN .= $phone[$x] . ' ';
            } else {
                $phoneN .= $phone[$x];
            }
        }
        return $phoneN;
    }

    function hashpassword($password) {
        return md5('' . $password . 'ainix');
    }

    /*
      //переадресация на другой номер
      function redirect($link = null) {
      if ($link == "") {
      $url = $_SERVER["HTTP_REFERER"];
      } else {
      $url = $link;
      }
      header("Location: $url");
      flush();
      // echo "<script type='text/javascript'>document.location = '$url';</script>";
      exit;
      }
     */

    function userIP() {
        $ip = "0.0.0.0";
        if (( isset($_SERVER['HTTP_X_FORWARDED_FOR']) ) && (!empty($_SERVER['HTTP_X_FORWARDED_FOR']) )) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (( isset($_SERVER['HTTP_CLIENT_IP'])) && (!empty($_SERVER['HTTP_CLIENT_IP']) )) {
            $ip = explode(".", $_SERVER['HTTP_CLIENT_IP']);
            $ip = $ip[3] . "." . $ip[2] . "." . $ip[1] . "." . $ip[0];
        } elseif ((!isset($_SERVER['HTTP_X_FORWARDED_FOR'])) || (empty($_SERVER['HTTP_X_FORWARDED_FOR']))) {
            if ((!isset($_SERVER['HTTP_CLIENT_IP'])) && (empty($_SERVER['HTTP_CLIENT_IP']))) {
                $ip = $_SERVER['REMOTE_ADDR'];
            }
        }
        return $ip;
    }

    function getOS($userAgent = null) {
        if (empty($userAgent)) {
            $userAgent = $_SERVER['HTTP_USER_AGENT'];
        }
        // Создадим список операционных систем в виде элементов массива
        $oses = array(
            'iPhone' => '(iPhone)',
            'Windows 3.11' => 'Win16',
            'Windows 95' => '(Windows 95)|(Win95)|(Windows_95)', // Используем регулярное выражение
            'Windows 98' => '(Windows 98)|(Win98)',
            'Windows 2000' => '(Windows NT 5.0)|(Windows 2000)',
            'Windows XP' => '(Windows NT 5.1)|(Windows XP)',
            'Windows 2003' => '(Windows NT 5.2)',
            'Windows Vista' => '(Windows NT 6.0)|(Windows Vista)',
            'Windows 7' => '(Windows NT 6.1)|(Windows 7)',
            'Windows NT 4.0' => '(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)',
            'Windows ME' => 'Windows ME',
            'Open BSD' => 'OpenBSD',
            'Sun OS' => 'SunOS',
            'Linux' => '(Linux)|(X11)',
            'Safari' => '(Safari)',
            'Macintosh' => '(Mac_PowerPC)|(Macintosh)',
            'QNX' => 'QNX',
            'BeOS' => 'BeOS',
            'OS/2' => 'OS/2',
            'Search Bot' => '(nuhk)|(Googlebot)|(Yammybot)|(Openbot)|(Slurp/cat)|(msnbot)|(ia_archiver)'
        );

        foreach ($oses as $os => $pattern) {
            if (eregi($pattern, $userAgent)) { // Пройдемся по массиву $oses для поиска соответствующей операционной системы.
                return $os;
            }
        }
        return 'Unknown'; // Хрен его знает, чего у него на десктопе стоит.
    }

    function getBrowser() {
        $user_agent = $_SERVER["HTTP_USER_AGENT"];
        if (strpos($user_agent, "Firefox") !== false)
            $browser = "Firefox";
        elseif (strpos($user_agent, "Opera") !== false)
            $browser = "Opera";
        elseif (strpos($user_agent, "Chrome") !== false)
            $browser = "Chrome";
        elseif (strpos($user_agent, "MSIE") !== false)
            $browser = "Internet Explorer";
        elseif (strpos($user_agent, "Safari") !== false)
            $browser = "Safari";
        else
            $browser = "Неизвестный";
        
        return $browser;
    }

    function time_zone_list() {
        return array(
            '+2' => "Калининградское время   MSK–1 (UTC+2)",
            '+3' => "Московское время        MSK   (UTC+3)",
            '+4' => "Самарское время         MSK+1 (UTC+4)",
            '+5' => "Екатеринбургское время  MSK+2 (UTC+5)",
            '+6' => "Омское время            MSK+3 (UTC+6)",
            '+7' => "Красноярское время      MSK+4 (UTC+7)",
            '+8' => "Иркутское время         MSK+5 (UTC+8)",
            '+9' => "Якутское время          MSK+6 (UTC+9)",
            '+10' => "Владивостокское время   MSK+7 (UTC+10)",
            '+11' => "Среднеколымское время   MSK+8 (UTC+11)",
            '+12' => "Камчатское время        MSK+9 (UTC+12)",
        );
    }

    static function send_mail($data) {

        if ($data["check_subscription"] == true) {
            //Проверяем статус подписчика
            $subscription = DB::select("SELECT * FROM `subscriptions` s WHERE s.`email` = '" . $data["email"] . "' LIMIT 1", "row");
            if (empty($subscription)) {
                DB::insert("INSERT INTO `subscriptions` ?set", ["email" => $data["email"], "date_created" => date('Y-m-d H:i:s')]);
            }

            if ($subscription['status'] != 1) {
                return false;
            }
        }

        $code = (!empty($data["code"])) ? $data["code"] : md5(time() . $data["email"] . rand(11, 99));

        require_once( LIB . "/libmail.php" );
        $mail_message_title = $data["title"];
        $mail_message_text = $data["text"];


        if(file_exists(TEMPLATE_PATH . "/mail.php")){
            ob_start();
            require_once( TEMPLATE_PATH . "/mail.php" );
            $body = ob_get_clean();
        }else{
            $body = $mail_message_text;
        }
        

        $status_send = 1;
        $error_send = "";

        $m = new Mail('utf-8');  // можно сразу указать кодировку, можно ничего не указывать ($m= new Mail;)
        $m->From(SMTP_FROM); // от кого Можно использовать имя, отделяется точкой с запятой
//        $m->smtp_on(SMTP_HOST, SMTP_MAIL, SMTP_PASSWORD, SMTP_POSRT); // используя эу команду отправка пойдет через smtp       
        $m->To($data["email"]);   // кому, в этом поле так же разрешено указывать имя
        $m->Subject($data["title"]);
        $m->Body($body, 'html');
        $m->Priority(4); // установка приоритета
        $m->Send();    // а теперь пошла отправка  
        if(!$m->status_mail["status"]){
            $status_send = 0;
            $error_send = (string) $m->status_mail["message"];
        }
        
        //записываем в базу письмо
        DB::insert("INSERT INTO `mails` ?set", [
            "title" => $data["title"], 
            "text" => $data["text"], 
            "html" => $body, 
            "date_send" => date('Y-m-d H:i:s'), 
            "user" => (int) $_SESSION['user']['id'], 
            "email" => $data["email"], 
            "store" => "", 
            "code" => $code, 
            "no_browser" => (int) $date["no_browser"], 
            "status"=>$status_send,
            "error"=>$error_send
                ]);
    }

    /**
     * Возвращает сумму прописью
     * @author runcore
     * @uses morph(...)
     */
    function num_propis($num, $kop_vivod = false) {
        $nul = 'ноль';
        $ten = array(
            array('', 'один', 'два', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять'),
            array('', 'одна', 'две', 'три', 'четыре', 'пять', 'шесть', 'семь', 'восемь', 'девять'),
        );
        $a20 = array('десять', 'одиннадцать', 'двенадцать', 'тринадцать', 'четырнадцать', 'пятнадцать', 'шестнадцать', 'семнадцать', 'восемнадцать', 'девятнадцать');
        $tens = array(2 => 'двадцать', 'тридцать', 'сорок', 'пятьдесят', 'шестьдесят', 'семьдесят', 'восемьдесят', 'девяносто');
        $hundred = array('', 'сто', 'двести', 'триста', 'четыреста', 'пятьсот', 'шестьсот', 'семьсот', 'восемьсот', 'девятьсот');
        $unit = array(// Units
            array('копейка', 'копейки', 'копеек', 1),
            array('рубль', 'рубля', 'рублей', 0),
            array('тысяча', 'тысячи', 'тысяч', 1),
            array('миллион', 'миллиона', 'миллионов', 0),
            array('миллиард', 'милиарда', 'миллиардов', 0),
        );
        //
        list($rub, $kop) = explode('.', sprintf("%015.2f", floatval($num)));
        $out = array();
        if (intval($rub) > 0) {
            foreach (str_split($rub, 3) as $uk => $v) { // by 3 symbols
                if (!intval($v))
                    continue;
                $uk = sizeof($unit) - $uk - 1; // unit key
                $gender = $unit[$uk][3];
                list($i1, $i2, $i3) = array_map('intval', str_split($v, 1));
                // mega-logic
                $out[] = $hundred[$i1]; # 1xx-9xx
                if ($i2 > 1)
                    $out[] = $tens[$i2] . ' ' . $ten[$gender][$i3];# 20-99
                else
                    $out[] = $i2 > 0 ? $a20[$i3] : $ten[$gender][$i3];# 10-19 | 1-9
                // units without rub & kop
                if ($uk > 1)
                    $out[] = $this->morph($v, $unit[$uk][0], $unit[$uk][1], $unit[$uk][2]);
            } //foreach
        } else
            $out[] = $nul;
        $out[] = $this->morph(intval($rub), $unit[1][0], $unit[1][1], $unit[1][2]); // rub
        if ($kop_vivod == true) {
            $out[] = $kop . ' ' . $this->morph($kop, $unit[0][0], $unit[0][1], $unit[0][2]); // kop
        }
        return trim(preg_replace('/ {2,}/', ' ', join(' ', $out)));
    }

    /**
     * Склоняем словоформу
     * @ author runcore
     */
    function morph($n, $f1, $f2, $f5) {
        $n = abs(intval($n)) % 100;
        if ($n > 10 && $n < 20)
            return $f5;
        $n = $n % 10;
        if ($n > 1 && $n < 5)
            return $f2;
        if ($n == 1)
            return $f1;
        return $f5;
    }

//доабляет новые ГЕт параметры к текущим
    /*
      $url = 'http://z-site.ru/?my_param=hello&my_param_2=bye';
      echo  controller::add_get_url(array('my_param_2'=>'goodbye','new_param'=>'this is new param'),$url); // http://z-site.ru/?my_param=hello&my_param_2=goodbye&new_param=this+is+new+param

      $url = 'http://z-site.ru/';
      echo  controller::add_get_url(array('my_param_2'=>'goodbye','new_param'=>'this is new param'),$url); // http://z-site.ru/?my_param_2=goodbye&new_param=this+is+new+param
     */
    function add_get_url($a_data, $url = false) {
        $http = $_SERVER['HTTPS'] ? 'https' : 'http';

        if ($url === false) {
            //  $url = $http . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        }
        $query_str = parse_url($url);

        $path = !empty($query_str['path']) ? $query_str['path'] : '';
        $scheme = !empty($query_str['scheme']) ? $query_str['scheme'] . '://' : '';
        $return_url = $scheme . $query_str['host'] . $path;
        $query_str = !empty($query_str['query']) ? $query_str['query'] : false;
        $a_query = array();
        if ($query_str) {
            parse_str($query_str, $a_query);
        }
        $a_query = array_merge($a_query, $a_data);
        $s_query = http_build_query($a_query);
        if ($s_query) {
            $s_query = '?' . $s_query;
        }
        return $return_url . $s_query;
    }

    function delete_get_url($a_data, $url = false) {
        $http = $_SERVER['HTTPS'] ? 'https' : 'http';

        if ($url === false) {
            $url = $http . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        }
        $query_str = parse_url($url);
        $path = !empty($query_str['path']) ? $query_str['path'] : '';
        $scheme = !empty($query_str['scheme']) ? $query_str['scheme'] . '://' : '';
        $return_url = $scheme . $query_str['host'] . $path;
        $query_str = !empty($query_str['query']) ? $query_str['query'] : false;

        $a_query = array();
        if ($query_str) {
            parse_str($query_str, $a_query);
        }

        foreach ($a_data as $key => $data) {
            if (gettype($data) == 'array') {
                foreach ($data as $key2 => $data2) {
                    unset($a_query[$key][$key2]);
                }
            } else {
                unset($a_query[$key]);
            }
        }
        // $a_query = array_merge($a_query, $a_data);
        $s_query = http_build_query($a_query);
        if ($s_query) {
            $s_query = '?' . $s_query;
        }
        return $return_url . $s_query;
    }

    //Для мульти занрузки файдов. пересортировывает массив
    function reArrayFiles(&$file_post) {

        $file_ary = array();
        $file_count = count($file_post['name']);
        $file_keys = array_keys($file_post);

        for ($i = 0; $i < $file_count; $i++) {
            foreach ($file_keys as $key) {
                $file_ary[$i][$key] = $file_post[$key][$i];
            }
        }

        return $file_ary;
    }

    //Плучение расштрение из файла
    function getExtension($str) {
        $i = strrpos($str, ".");
        if (!$i) {
            return "";
        }
        $l = strlen($str) - $i;
        $ext = substr($str, $i + 1, $l);
        return $ext;
    }

    function formatNumber($number, $decimals = 2, $dec_point = ".", $thousands_sep = ",") {
        $nachkomma = abs($in - floor($in));
        $strnachkomma = number_format($nachkomma, $decimals, ".", "");

        for ($i = 1; $i <= $decimals; $i++) {
            if (substr($strnachkomma, ($i * -1), 1) != "0") {
                break;
            }
        }
        return number_format($in, ($decimals - $i + 1), $dec_point, $thousands_sep);
    }

    function plural_form($number, $after) {
        $cases = array(2, 0, 1, 1, 1, 2);
        echo $number . ' ' . $after[($number % 100 > 4 && $number % 100 < 20) ? 2 : $cases[min($number % 10, 5)]];
    }
    
    function telegram($message) {
        $message .= " / ".date::dateFormatView(["datetime" => date("Y-m-d H:i:s"), "formatReturn"=>1]);
        $token = "713376179:AAEgsOz0Mp-IXsWFO6BW9NkvZ6wSeN_-Pd0"; //наш токен от telegram bot -а
        $chatid = "295992690"; //ИД чата telegrm
        $tbot = file_get_contents("https://api.telegram.org/bot".$token."/sendMessage?chat_id=".$chatid."&text=".urlencode($message));
    }

    function as_md5($pass) {
        $pass = md5(KEY . md5("Z&" . KEY . "x_V" . htmlspecialchars($pass, ENT_QUOTES, "")));
        return $pass;
    }
    
    
    function getCaptcha($SecretKey) {
        $Response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".G_RECAPTCHA_PRIVAT."&response={$SecretKey}");
        $Return = json_decode($Response);
        return $Return;
    }
    
}

?>