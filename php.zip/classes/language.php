<?php

class language {
    
    function languages($lang = null){
        $list = [];
        $list["ru"] = "Русский";
        $list["en"] = "English";
        return (!empty($lang)) ? $list[$lang] : $list;
    }
    
    function lang(){
        if(!empty($_SESSION["user"])){
            return $_SESSION["user"]["language"];
        }elseif(!empty($_SESSION["language"])){
            return $_SESSION["language"];
        }else{
            return "ru";
        }
    }
    
    function change(){
        $lang = trim(strip_tags($_GET["lang"]));
        $chek_lang = self::languages($lang);
        if(!empty($lang) && !empty($chek_lang)){
            if(!empty($_SESSION["user"])){
                //Меняем язык пользователя
                DB::update("UPDATE `users` SET ?set WHERE `id`='{$_SESSION["user"]["id"]}' ", ["language"=>$lang]);
                $_SESSION["user"]["language"] = $lang;
            }else{
                $_SESSION["language"] = $lang;
            }
       }
    }

//[:ru]Природа[:en]Nature[:]
    static function lang_text($text, $lang = null) {
        if (empty($lang)) {
            $lang = self::lang();
        }
        return preg_replace_callback('|\[:.*\[:\]|isuU', function ($find) use ($lang) {
            if (preg_match('|\[\:' . $lang . '\](.*)\[\:|isuU', $find[0], $matches)) {
                return $matches[1];
            }
        }, $text);
    }
    
    function text($lang, $text) {
        $this_lang = self::lang();
        if ($this_lang == $lang) {
            return $text;
        }
    }

}
