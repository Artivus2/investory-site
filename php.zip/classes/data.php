<?php

class data {

    function currency($el = "") {
        if (language::lang() == "en") {
            $list["RUB"] = "Ruble";
            $list["USD"] = "Dollars";
            $list["BTC"] = "Bitcoins";
        } else {
            $list["RUB"] = "Рубли";
            $list["USD"] = "Доллары";
            $list["BTC"] = "Биткоины";
        }
        return (!empty($el)) ? $list[$el] : $list;
    }

    function currency_rod($el = "") {
        if (language::lang() == "en") {
            $list["RUB"] = "Ruble";
            $list["USD"] = "Dollars";
            $list["BTC"] = "Bitcoins";
        } else {
            $list["RUB"] = "Рублей";
            $list["USD"] = "Долларов";
            $list["BTC"] = "Биткоинов";
        }
        return (!empty($el)) ? $list[$el] : $list;
    }

    function currency_d($el = "") {
        if (language::lang() == "en") {
            $list["RUB"] = "rub";
            $list["USD"] = "$";
            $list["BTC"] = "Btc";
        } else {
            $list["RUB"] = "руб";
            $list["USD"] = "$";
            $list["BTC"] = "Btc";
        }
        return (!empty($el)) ? $list[$el] : $list;
    }

    function currency_icon($el = "") {
        $list["RUB"] = "<i class='fal fa-ruble-sign'></i>";
        $list["USD"] = "<i class='fal fa-dollar-sign'></i>";
        $list["BTC"] = "<i class='fab fa-btc'></i>";
        return (!empty($el)) ? $list[$el] : $list;
    }

    function currency_rounding($value, $currency, $currency_text = false, $currency_type = "text", $decimal = true) {
        if ($currency == "RUB" || $currency == "USD") {
            if ($decimal) {
                $mask_sprintf = "%01.2f";
            } else {
                $mask_sprintf = "%01.0f";
            }
        } elseif ($currency == "BTC") {
            if ($value == 0) {
                $count_decimals = 6;
            } else {
                $value = rtrim($value, '0');
                $count_decimals = strlen((string) explode('.', (string) $value)[1]);
            }
            $mask_sprintf = "%01.{$count_decimals}f";
        } else {
            return "";
        }
        $value = sprintf($mask_sprintf, str_replace(',', '.', $value));

        if ($currency_text && $currency_type == "text") {
            $value = $value . " " . self::currency_d($currency);
        } elseif ($currency_text && $currency_type == "icon") {
            $value .= self::currency_icon($currency);
        }
        return $value;
    }

    function paysystems_plus_form($el = "") {
        if (language::lang() == "en") {
            $list["qiwi"]       = ["currency" => "RUB|USD", "name" => "QIWI Wallet"];
            $list["yandex"]     = ["currency" => "RUB", "name" => "Yandex money"];
            $list["bank"]       = ["currency" => "RUB", "name" => "Bank Transfer"];

            $list["bitcoin"]    = ["currency" => "BTC", "name" => "BITCOIN"];
        } else {
            $list["qiwi"]       = ["currency" => "RUB|USD", "name" => "QIWI Кошелек"];
            $list["yandex"]     = ["currency" => "RUB", "name" => "Яндекс Деньги"];
            $list["bank"]       = ["currency" => "RUB", "name" => "Банковский перевод"];

            $list["bitcoin"]    = ["currency" => "BTC", "name" => "БИТКОИН"];
        }

        $list["advcash"]        = ["currency" => "RUB|USD", "name" => "AdvCash"];
        $list["payeer"]         = ["currency" => "RUB|USD", "name" => "Payeer"];
        $list["pm"]             = ["currency" => "USD", "name" => "Perfect Money"];
        return (!empty($el)) ? $list[$el] : $list;
    }

    function paysystems_plus_list($el = "") {
        if (language::lang() == "en") {
            $list["advcash"]    = "AdvCash";
            $list["alfa_bank"]  = "Alfa Bank";
            $list["bank"]       = "Bank";
            $list["bitcoin"]    = "BITCOIN";
            $list["payeer"]     = "Payeer";
            $list["pm"]         = "Perfect Money";
            $list["qiwi"]       = "QIWI";
            $list["sberbank"]   = "Sberbank";
            $list["tinkoff"]    = "Tinkoff";
            $list["yandex"]     = "Yandex money";
        } else {
            $list["advcash"]    = "AdvCash";
            $list["alfa_bank"]  = "Альфа-Банк";
            $list["bank"]       = "Банк";
            $list["bitcoin"]    = "БИТКОИН";
            $list["payeer"]     = "Payeer";
            $list["pm"]         = "Perfect Money";
            $list["qiwi"]       = "QIWI";
            $list["sberbank"]   = "Сбербанк";
            $list["tinkoff"]    = "Тинькофф";
            $list["yandex"]     = "Яндекс Деньги";
        }
        return (!empty($el)) ? $list[$el] : $list;
    }

    function paysystems_minus_form($el = "") {
        if (language::lang() == "en") {
            $list["qiwi"]       = ["currency" => "RUB|USD", "name" => "QIWI Wallet"];
            $list["yandex"]     = ["currency" => "RUB", "name" => "Yandex money"];
            $list["alfa_bank"]  = ["currency" => "RUB", "name" => "Alfa Bank"];
            $list["sberbank"]   = ["currency" => "RUB", "name" => "Sberbank"];
            $list["tinkoff"]    = ["currency" => "RUB", "name" => "Tinkoff"];

            $list["bitcoin"]    = ["currency" => "BTC", "name" => "BITCOIN"];
        }else{
            $list["qiwi"]       = ["currency" => "RUB|USD", "name" => "QIWI Кошелек"];
            $list["yandex"]     = ["currency" => "RUB", "name" => "Яндекс Деньги"];
            $list["alfa_bank"]  = ["currency" => "RUB", "name" => "Альфа-Банк"];
            $list["sberbank"]   = ["currency" => "RUB", "name" => "Сбербанк"];
            $list["tinkoff"]    = ["currency" => "RUB", "name" => "Тинькофф"];

            $list["bitcoin"]    = ["currency" => "BTC", "name" => "БИТКОИН"];
        }
        $list["advcash"]        = ["currency" => "RUB|USD", "name" => "AdvCash"];
        $list["payeer"]         = ["currency" => "RUB|USD", "name" => "Payeer"];
        $list["pm"]             = ["currency" => "USD", "name" => "Perfect Money"];
        return (!empty($el)) ? $list[$el] : $list;
    }

    function paysystems_minus_list($el = "") {
        if (language::lang() == "en") {
            $list["sber"]       = "Sberbank";
            $list["yandex"]     = "Yandex money";
            $list["tinkoff"]    = "Tinkoff";
            $list["alfa_bank"]  = "Alfa Bank";
            $list["qiwi"]       = "QIWI Wallet";
            $list["bitcoin"]    = "BITCOIN";
            $list["advcash"]    = "AdvCash Purse";
            $list["payeer"]     = "Payeer Purse";
            $list["pm"]         = "Perfect Money";
        }else{
            $list["sber"]       = "Сбербанк";
            $list["yandex"]     = "Яндекс Деньги";
            $list["tinkoff"]    = "Тинькофф";
            $list["alfa_bank"]  = "Альфа-Банк";
            $list["qiwi"]       = "QIWI Кошелек";
            $list["bitcoin"]    = "БИТКОИН";
            $list["advcash"]    = "AdvCash Кошелек";
            $list["payeer"]     = "Payeer Кошелек";
            $list["pm"]         = "Perfect Money";
        }
        return (!empty($el)) ? $list[$el] : $list;
    }

    function payment_details($el = "") {
        if (language::lang() == "en") {
            $list["sberbank"]   = "Sberbank";
            $list["tinkoff"]    = "Tinkoff";
            $list["alfa_bank"]  = "Alfa Bank";
            $list["yandex"]     = "Yandex money";
            $list["qiwi"]       = "QIWI Wallet";
            $list["advcash"]    = "AdvCash Purse";
            $list["payeer"]     = "Payeer Purse";
            $list["pm"]         = "Perfect Money";
            $list["bitcoin"]    = "Bitcoin wallet ID";
        }else{
            $list["sberbank"]   = "Сбербанк";
            $list["tinkoff"]    = "Тинькофф";
            $list["alfa_bank"]  = "Альфа-Банк";
            $list["yandex"]     = "Яндекс Деньги";
            $list["qiwi"]       = "QIWI Кошелек";
            $list["advcash"]    = "AdvCash Кошелек";
            $list["payeer"]     = "Payeer Кошелек";
            $list["pm"]         = "Perfect Money";
            $list["bitcoin"]    = "ID биткоин кошелька";
        }
        return (!empty($el)) ? $list[$el] : $list;
    }

}
