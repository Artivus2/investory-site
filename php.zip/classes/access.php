<?php

class access {

    static function check_session() {
        $check_session = false;
        //Если имеется куки пользователя то проверяем достоверность
        //var_dump($_COOKIE['user_d'], $_COOKIE['session_hash'], $_COOKIE['session_id']);

        if (!empty($_COOKIE['session_hash']) && !empty($_COOKIE['session_id'])) {
            $session = DB::select("SELECT * FROM `users_session` WHERE `hash` = '" . $_COOKIE['session_hash'] . "' AND `id` = '" . $_COOKIE['session_id'] . "' LIMIT 1", "row");

            if (!empty($session)) {
                //   $_SESSION["session_id"] = $session["id"];
                //    $_SESSION["session_hash"] = $session["hash"];
                setcookie("session_id", $session["id"], time() + 604800, "/");
                setcookie("session_hash", $session["hash"], time() + 604800, "/");
                $check_session = true;
            } else {
                unset($_SESSION["user"]);
            }
        } else {
            unset($_SESSION["user"]);
            //   unset($_SESSION["session_id"]);
            //  unset($_SESSION["session_hash"]);
        }

        if ($check_session) {
            $return = access::check_access($session);
        } else {
            $return = 0;
        }

        return $return;
    }

    function check_access($session) {
        require_once (COM_PATH . "/user/user/model.php" );
        unset($_SESSION["user"]);
        $user = DB::select("SELECT * FROM `users` WHERE `id`='{$session['user']}' LIMIT 1", 'row');
        if (empty($user)) {
            return 0;
        }
        unset($user['password']);
        
        if(!empty($user["avatar"])){
            $user["avatar_dir"] = "/images/avatars/".$user["avatar"];
        }
       
        if(empty($user["avatar_dir"]) || !file_exists(__DIR__."/..".$user["avatar_dir"])){
            $user["avatar_dir"] = "/images/no_avatar.png";
        }
        $_SESSION['user'] = $user;
        
        DB::update("UPDATE `users` SET ?set WHERE `id`='{$session['user']}' LIMIT 1", array("online" => 1, "date_active" => date("Y-m-d H:i:s")));
        return 1;
    }

}

?>
