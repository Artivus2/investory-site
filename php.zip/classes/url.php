<?php
class url {
    public $alias = "";
    public $template = "default";
    public $url= "";
    public $data= "";
    public $url_type = "page";
    public $access = false;
    
    
     function urlcheck() {
        global $DB;
        $result = $_SERVER["REDIRECT_URL"];
        
if(!empty($_POST["PAYMENT_ID"])){
    $fileopen=fopen("pm.txt", "a+");
    fwrite($fileopen, "----".serialize($_SERVER["REDIRECT_URL"])."\r\n");
    fwrite($fileopen, "10----".serialize($_POST)."\r\n");
    fclose($fileopen);
}

        $array_url = preg_split("/(\/|\..*$)/", $result, -1, PREG_SPLIT_NO_EMPTY);


//        if ($array_url[0] == "news" && !empty($array_url[1])) {
//            $is_company_blog = DB::select("SELECT * FROM `company` WHERE `id` = '" . (int) $array_url[1] . "' AND `news` = '1' AND `publication`='1'  LIMIT 1", 'row');
//            $url_type = "news";
//            if (!empty($array_url[2]) && !empty($is_company_blog)) {
//                $is_new = DB::select("SELECT * FROM `blog_post` WHERE `company` = '" . (int) $array_url[1] . "' AND `sysname` = '" . $array_url[2] . "' AND `publication`='1'  LIMIT 1", 'row');
//                $url_type = "new";
//            }
//            $this->alias = $array_url[2];
//        }
//        var_dump($url_type, $is_company_blog, $is_new);exit;
//        if($url_type == "new" && !empty($is_new) ){
//            $urlData["url"] = "com=blogs&view=item&company={$array_url[1]}&sysname={$array_url[2]}"; 
        
        if (!empty($array_url)) {
            $urlData = DB::select("SELECT * FROM `pages` WHERE `alias` = '" . implode('/', $array_url) . "' AND `publication`='1'  LIMIT 1", 'row');
            $url_type = "page";
        } else {
            $urlData = DB::select("SELECT * FROM `pages` WHERE `index` = '1' AND `publication`='1' LIMIT 1", 'row');
            $url_type = "page";
        }
        if (empty($urlData)) {
            $urlData = DB::select("SELECT * FROM `url` WHERE `alias` = '" . implode('/', $array_url) . "' AND `publication`='1'  LIMIT 1", 'row');
            $url_type = "link";
        }
        if (empty($urlData)) {
            $blog_category = DB::select("SELECT * FROM `blog_category` bc WHERE bc.`alias` = '$array_url[0]' AND bc.`publication` = 1 LIMIT 1", 'row');
           
            if(!empty($blog_category)){
                if(!empty($array_url[1])){
                    $blog_post = DB::select("SELECT * FROM `blog_post` bp WHERE bp.`category` = '{$blog_category["id"]}' AND bp.`alias` = '{$array_url[1]}' AND bp.`publication` = 1  LIMIT 1", 'row');
                    if(!empty($blog_post)){
                        $url_type = "blog_item";
                        $urlData["url"] = "com=blogs&view=item&item={$blog_post["id"]}"; 
                        $urlData["alias"] = $array_url[1]; 
                        $urlData["template"] = "default"; 
                    }
                }else{
                    $url_type = "blog";
                    $urlData["url"] = "com=blogs&view=lit&category={$blog_category["id"]}"; 
                    $urlData["alias"] = $array_url[0]; 
                    $urlData["template"] = "default"; 
                }
            }
        }
        
if(!empty($_POST["PAYMENT_ID"])){
    $fileopen=fopen("pm.txt", "a+");
    fwrite($fileopen, "----".serialize($_SERVER["REDIRECT_URL"])."\r\n");
    fwrite($fileopen, "12----".serialize($urlData)."\r\n");
    fclose($fileopen);
}


        if (!empty($urlData)) {
            $this->alias    = $urlData["alias"];
            $this->template = $urlData["template"];
            $this->data     = unserialize($urlData['data']);
            $this->url      = $urlData["url"];
            $this->url_type = $url_type;
            $this->access   = (bool)$urlData["access"];
            $this->title   = $urlData["title"];
            $this->keywords   = $urlData["keywords"];
            $this->description   = $urlData["description"];
        } else {
            header("HTTP/1.0 404 Not Found");
            $this->alias    = "page_404";
            $this->template = "404";
            $this->url      = "com=pages&view=404";
            $this->url_type = 404;
        }
    }
    

    private function url_type($data = array()) {
        $where = "";
        $alias = implode('/', $data["url"]);
        if (!empty($data["access"]))
            $where .= " AND `access` = '" . $data["access"] . "' ";
        if (!empty($data["type"]))
            $where .= " AND `type` = '" . $data["access"] . "' ";


        $page = DB::select("SELECT * FROM `pages` WHERE `alias` = '$alias' AND `publication`='1'  LIMIT 1", 'row');
        $url = DB::select("SELECT * FROM `url` WHERE `alias` = '$alias' AND `publication`='1'  LIMIT 1", 'row');

        if (!empty($page)) {
            $page['url_type'] = "page";
            return $page;
        }

        if (!empty($url)) {
            $url['url_type'] = "url";
            return $url;
        }
        return false;
    }

    public function get_to_component($get) {

        if ($get["com"] != '') {
            $file_component = COM_PATH . "/" . $get["com"] . "/com_" . $get["com"] . ".php";

            if (file_exists($file_component)) {
                include_once ($file_component);
                $componentClass = "com" . $get["com"];

                return new $componentClass($get);
            } else {
                return "Файл компонента '" . $get["com"] . "' не найден :(";
            }
        }
    }

    function get_domain_and_subdomains() {
        $http_host_arr = explode('.', $_SERVER['HTTP_HOST']);
        $http_host_arr = array_reverse($http_host_arr);

        return $http_host_arr[$count_key_domen];
    }

}

?>
