<?php

class comMoney_controlTransfers {

    function display() {
        $return = "";
        
          $limit = 10;
        
        require_once ( COM_PATH . "/money/transfers/model.php" );
        $list = comMoney_modelTransfers::transfers(["limit"=>$limit]);
       
        require_once (COM_PATH . "/pagination/pagination.php" );
        $pagination = Pagination::view($list["count"], $limit);
  
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();
        
        require_once ( COM_PATH . "/invest/purses/model.php" );
        $purses = comInvest_modelPurses::purses();
        
        $form_data = $_SESSION["form_data"];
        unset($_SESSION["form_data"]);
        


        $this_language_key = language::lang();

        $languages_text["form_title"]["ru"] = "Внутренний перевод";
        $languages_text["form_title"]["en"] = "Internal translation";

        $languages_text["form_purse"]["ru"] = "Кошелек";
        $languages_text["form_purse"]["en"] = "Purse";

        $languages_text["form_amount"]["ru"] = "Сумма перевода";
        $languages_text["form_amount"]["en"] = "Transfer amount";

        $languages_text["form_login"]["ru"] = "Логин или E-mail получателя";
        $languages_text["form_login"]["en"] = "PRecipient login or email";

        $languages_text["form_balance"]["ru"] = "Баланс";
        $languages_text["form_balance"]["en"] = "Balance";

        $languages_text["form_button"]["ru"] = "Перевод";
        $languages_text["form_button"]["en"] = "Transfer";


        $languages_text["paymentsystems_title"]["ru"] = "Платежные системы";
        $languages_text["paymentsystems_title"]["en"] = "Payment systems";

        $languages_text["paymentsystems_min"]["ru"] = "мин.";
        $languages_text["paymentsystems_min"]["en"] = "min.";

        $languages_text["paymentsystems_commission"]["ru"] = "комиссия 2.5% от суммы ";
        $languages_text["paymentsystems_commission"]["en"] = "commission 2.5% of the amount";


        $languages_text["table_title"]["ru"] = "История внутренних переводов";
        $languages_text["table_title"]["en"] = "History of internal transfers";


        $languages_text["table_col_1"]["ru"] = "№";
        $languages_text["table_col_1"]["en"] = "No.";

        $languages_text["table_col_2"]["ru"] = "Дата";
        $languages_text["table_col_2"]["en"] = "Date";

        $languages_text["table_col_3"]["ru"] = "Сумма";
        $languages_text["table_col_3"]["en"] = "Amount";

        $languages_text["table_col_4"]["ru"] = "Отправитель";
        $languages_text["table_col_4"]["en"] = "Sender";

        $languages_text["table_col_5"]["ru"] = "Получатель";
        $languages_text["table_col_5"]["en"] = "Recipient";

        $languages_text["table_col_6"]["ru"] = "Статус";
        $languages_text["table_col_6"]["en"] = "Status";

        $languages_text["label_received"]["ru"] = "Полученный перевод";
        $languages_text["label_received"]["en"] = "Received translation";

        $languages_text["label_sent"]["ru"] = "Отправленный перевод";
        $languages_text["label_sent"]["en"] = "Sent translation";

        $languages_text["empty_table"]["ru"] = "История переводов пуста";
        $languages_text["empty_table"]["en"] = "Translation History is empty";
        
        
        ob_start();
        require_once ( COM_PATH . "/money/transfers/view.php" );
        $return .= ob_get_clean();


        return $return;
    }

}
