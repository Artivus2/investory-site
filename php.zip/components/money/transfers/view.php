<?= $greeting_block ?>
<?= $purses_block ?>


<div class="row" = id="form">
    <div class="col-sm-12">
        <div class="form_block">
            <h3><?=$languages_text["form_title"][$this_language_key]?></h3>

            <form method="POST" action="/transfer/add">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?=$languages_text["form_login"][$this_language_key]?></label>
                            <input type="text" name="user" value="<?=(string)$form_data["user"]?>">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?=$languages_text["form_purse"][$this_language_key]?></label>
                            <div class="select">
                                <select name="purse">
                                    <? foreach ($purses as $purse): ?>
                                        <option value="<?= $purse["currency"] ?>" <?if((string)$form_data["purse"] == $purse["currency"]) echo "selected"?>>
                                            <?= data::currency($purse["currency"]) ?>, (<?=$languages_text["form_balance"][$this_language_key]?> <?= $purse["value_rounding"] ?>)
                                        </option>
                                    <? endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?=$languages_text["form_amount"][$this_language_key]?></label>
                            <input type="text" name="summa" value="<?=(string)$form_data["summa"]?>">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-sm-6 col-xs-12 form_help">
                        <?= message::msg("new_transfer"); ?>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 text-right">
                        <button type="submit" class="btn__green"><?=$languages_text["form_button"][$this_language_key]?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>



<div class="row">
    <div class="col-sm-12">
        <div class="table_block">
            <? if (!empty($list["transfers"])): ?>
                <h3><?=$languages_text["table_title"][$this_language_key]?></h3>
                <table class="table">
                    <thead>
                        <tr>
                            <th><?=$languages_text["table_col_1"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_2"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_3"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_4"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_5"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_6"][$this_language_key]?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <? foreach ($list["transfers"] as $transfer): ?>
                            <tr>
                                <td data-label="<?=$languages_text["table_col_1"][$this_language_key]?>">
                                    <?= $transfer["id"] ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_2"][$this_language_key]?>">
                                    <?= date::dateFormatView(["datetime" => $transfer["date_created"]]); ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_3"][$this_language_key]?>">
                                    <?= data::currency_rounding($transfer["summa"], $transfer["currency"], true, "text", false) ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_4"][$this_language_key]?>">
                                    <?= $transfer["user_login"] ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_5"][$this_language_key]?>">
                                    <?= $transfer["user_receiver_login"] ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_6"][$this_language_key]?>">
                                    <? if ($transfer['user_receiver'] == $_SESSION["user"]["id"]): ?>
                                        <i class="fa fa-chevron-up"></i> 
                                        <span><?=$languages_text["label_received"][$this_language_key]?></span>
                                    <? else: ?>
                                        <i class="fa fa-chevron-down"></i> 
                                        <span><?=$languages_text["label_sent"][$this_language_key]?></span>
                                    <? endif; ?>
                                </td>
                            </tr>

                        <? endforeach; ?>
                    </tbody>
                </table>
                <?= $pagination ?>
            <? else: ?>
                <div class="alert alert-warning">
                    <?=$languages_text["empty_table"][$this_language_key]?>
                </div>
            <? endif; ?>
        </div>
    </div>
</div>

