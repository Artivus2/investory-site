<?php

class comMoney_modelTransfers {

    function transfers($data = array()) {

        if (isset($data["limit"])) {
            $page = (int) isset($data['page']) ? $data['page'] : $_GET['page'];
            $start = (!empty($page)) ? ($page - 1) * $data["limit"] : 0;
            $limit = " LIMIT $start, " . $data["limit"];
        }

        if (empty($data["user"])) {
            $data["user"] = $_SESSION["user"]["id"];
        }
        $return["transfers"] = DB::select("SELECT SQL_CALC_FOUND_ROWS t.*, u1.`login` AS `user_login`, u2.`login` AS `user_receiver_login` 
                            FROM `transfers` t 
                            LEFT JOIN `users` u1 ON u1.`id` = t.`user`
                            LEFT JOIN `users` u2 ON u2.`id` = t.`user_receiver`
                            WHERE t.`user` = '{$data["user"]}' OR t.`user_receiver` = '{$data["user"]}' ORDER BY t.id DESC $limit", 'all');

        $return["count"] = DB::select("SELECT FOUND_ROWS() cnt", "row")["cnt"];
        return $return;
    }

    function add_transfer() {

        $user = trim(strip_tags($_POST["user"]));

        $_SESSION["form_data"] = $_POST;
        
        $user_receiver_data = DB::select("SELECT * FROM `users` u WHERE u.`lock` = 0 AND (u.`login` = '$user' OR u.`email` = '$user')", "row");
//        var_dump($user_receiver_data);exit;
        if (empty($user)) {
            message::new_msg("new_transfer", "danger", "[:ru]Укажите логин или e-mail получателя платежа[:en]Enter the login or e-mail of the payee[:]");
            return false;
        } elseif (empty($user_receiver_data)) {
            message::new_msg("new_transfer", "danger", "[:ru]Получатель не найден[:en]Recipient not found[:]");
            return false;
        } elseif ($user == $_SESSION["user"]["id"]) {
            message::new_msg("new_transfer", "danger", "[:ru]Не нужно отправлять перевод себе[:en]No need to send a translation to yourself[:]");
            return false;
        }

        $currency = $_POST["purse"];

        require_once ( COM_PATH . "/invest/purses/model.php" );
        $purse = comInvest_modelPurses::purse($currency);
        if (empty($purse)) {
            message::new_msg("new_transfer", "danger", "[:ru]Не найден кошелек[:en]Wallet not found[:]");
            return false;
        }

        $summa = data::currency_rounding($_POST["summa"], $currency);

        $min_transfer = 0;
        if ($currency == "RUB") {
            $min_transfer = 10;
        } elseif ($currency == "USD") {
            $min_transfer = 0.5;
        } elseif ($currency == "BTC") {
            $min_transfer = 0.00001;
        }


        if (empty($summa)) {
            message::new_msg("new_transfer", "danger", "[:ru]Укажите сумму перевода[:en]Enter the amount of transfer[:]");
            return false;
        } elseif ($summa < $min_transfer) {
            message::new_msg("new_transfer", "danger", sprintf(language::lang_text("[:ru]Сумма перевода должна быть больше %s сумму перевода[:en]The transfer amount must be greater than %s transfer amount[:]"), data::currency_rounding($min_transfer, $currency)));
            return false;
        } elseif ($summa > $purse["value"]) {
            message::new_msg("new_transfer", "danger", "[:ru]У вас недостаточно средств на счету[:en]You do not have enough funds in your account[:]");
            return false;
        }

        //Проверяем наличие кошельков
        require_once ( COM_PATH . "/invest/purses/model.php" );
        comInvest_modelPurses::check_purses($user_receiver_data["id"]);

        $purse_user_receiver = comInvest_modelPurses::purse($currency, $user_receiver_data["id"]);
        DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}'", array("date_update" => date("Y-m-d H:i:s"), 'value' => $purse["value"] - $summa));
        DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse_user_receiver["id"]}'", array("date_update" => date("Y-m-d H:i:s"), 'value' => $purse_user_receiver["value"] + $summa));

        DB::insert("INSERT INTO `transfers` ?set", [
            "user" => $_SESSION["user"]["id"],
            "user_receiver" => $user_receiver_data["id"],
            "summa" => $summa,
            "date_created" => date("Y-m-d H:i:s"),
            "currency" => $currency
        ]);

        $mail_message = "";
        if(language::lang() == "en"){
            $mail_title  = "Internal translation";
            $mail_message .= "<h3>Internal translation</h3>";
            $mail_message .= sprintf("<p>User <strong>%s</strong> received money from <strong>%s</strong> in the amount of %s</p>", $user_receiver_data["login"], $_SESSION["user"]["login"], data::currency_rounding($summa, $currency, true));
            $mail_message .= "<p>Date of transfer " . date::dateFormatView(["datetime" => date("Y-m-d H:i:s")]) . "</p>";
        }else{
            $mail_title  = "Внутренний перевод";
            $mail_message .= "<h3>Внутренний перевод</h3>";
            $mail_message .= sprintf("<p>На пользователя <strong>%s</strong> поступили деньги от <strong>%s</strong> в размере %s</p>", $user_receiver_data["login"], $_SESSION["user"]["login"], data::currency_rounding($summa, $currency, true));
            $mail_message .= "<p>Дата перевода " . date::dateFormatView(["datetime" => date("Y-m-d H:i:s")]) . "</p>";
        }
        Controller::send_mail(["email" => $user_receiver_data["email"], "title" => $mail_title, "text" => $mail_message]);
        
        
        //telegram($msg);
        Controller::telegram("Внутренний перевод. {$_SESSION["user"]["login"]} -> {{$user_receiver_data["login"]}} в размере " . data::currency_rounding($summa, $currency, true));
        message::new_msg("new_transfer", "success", "[:ru]Перевод успешно выполнен[:en]Translation completed successfully[:]");
    }

}
