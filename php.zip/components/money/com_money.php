<?php

class comMoney {

    public $act = null;
    public $view = null;
    public $id = null;
    public $model = null;
    public $content = null;
    public $content_head = null;
    public $title = null;

    function __construct($get) {
        $this->act = $get['act'];
        $this->view = $get['view'];
        $this->id = $get['id'];
        global $url_data;
        if (isset($this->act)) {
            switch ($this->act) {
                case "plus":
                    require_once ( COM_PATH . "/money/plus/model.php" );
                    $result = comMoney_modelPlus::new_money();
                    
                    if(!$result){
                        Controller::redirect("/refill#form");
                    }else{
                        Controller::redirect("/refill/confirm", ["hash"=>$result["hash"]]);
                    }
                    break;
                case "minus":
                    require_once ( COM_PATH . "/money/minus/model.php" );
                    $money_id = comMoney_modelMinus::new_money();
                    Controller::redirect("/withdraw#form");
                  
                    break;
                case "success":
                    require_once ( COM_PATH . "/money/plus/model.php" );
                    comMoney_modelPlus::success();
                    Controller::redirect("/refill");
                    break;
                case "add_transfer":
                    require_once ( COM_PATH . "/money/transfers/model.php" );
                    comMoney_modelTransfers::add_transfer();
                    Controller::redirect("/transfers#form");
                    break;
                case "pm_status":
                    file_put_contents("pm_00.txt", serialize($_POST));
                    require_once ( COM_PATH . "/money/plus/model.php" );
                    comMoney_modelPlus::pm_status();
                    exit;
                    break;
                case "payeer_status":
                    require_once ( COM_PATH . "/money/plus/model.php" );
                    comMoney_modelPlus::payeer_status();
                    exit;
                    break;
                case "advcash_status":
                    require_once ( COM_PATH . "/money/plus/model.php" );
                    comMoney_modelPlus::advcash_status();
                    exit;
                    break;
                case "qiwi_status":
                    require_once ( COM_PATH . "/money/plus/model.php" );
                    comMoney_modelPlus::qiwi_status();
                    exit;
                    break;
            }
        }
        if (isset($this->view)) {
            switch ($this->view) {
                case "plus":
                    require_once ( COM_PATH . "/money/plus/control.php" );
                    $this->content = comMoney_controlPlus::display();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "plus_success":
                    require_once ( COM_PATH . "/money/plus/control.php" );
                    $this->content = comMoney_controlPlus::display_success();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "plus_fail":
                    require_once ( COM_PATH . "/money/plus/control.php" );
                    $this->content = comMoney_controlPlus::display_fail();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;

                case "minus":
                    require_once ( COM_PATH . "/money/minus/control.php" );
                    $this->content = comMoney_controlMinus::display();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "confirm":
                    $hash = trim(strip_tags($_GET["hash"]));
                    require_once ( COM_PATH . "/money/plus/control.php" );
                    $this->content = comMoney_controlPlus::display_confirm($hash);

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "transfers":
                    require_once ( COM_PATH . "/money/transfers/control.php" );
                    $this->content = comMoney_controlTransfers::display();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
            }
        }
    }

}
