<div class="row">
    <div class="col-sm-12">
        <div class="form_block text-center">
            <h3><?=$languages_text["title"][$this_language_key]?></h3>
            <form method="POST" action="/refill/success">
               
                    <p><?=sprintf(
                            $languages_text["text_default_1"][$this_language_key], 
                            data::currency_rounding($money["summa"], $money["currency"], true), 
                            $paysystem['purse']);?>
                    </p>
                    <p><?=sprintf(
                            $languages_text["text_default_2"][$this_language_key], 
                            data::currency_rounding($money["summa"] * $paysystem['percent'], $money["currency"], true));?>
                    </p>
                <input type="hidden" value="<?= $money["id"] ?>" name="id"/>
                <input class="btn__green" type="submit" value="<?=$languages_text["button"][$this_language_key]?>" />
            </form>
        </div>
    </div>
</div>