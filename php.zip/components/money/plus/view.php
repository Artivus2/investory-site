<?= $greeting_block ?>
<?= $purses_block ?>
<?if(false):?>
<div class="row" id="form">
    <div class="col-sm-12">
        <div class="form_block">
            <h3><?=$languages_text["form_title"][$this_language_key]?></h3>

            <form action="/refill/go" method="POST">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?=$languages_text["form_currency"][$this_language_key]?></label>
                            <div class="select">
                                <select name="currency">
                                    <option value="RUB" <?if((string)$form_data["currency"] == "RUB") echo "selected"?>>RUB</option>
                                    <option value="USD" <?if((string)$form_data["currency"] == "USD") echo "selected"?>>USD</option>
                                    <option value="BTC" <?if((string)$form_data["currency"] == "BTC") echo "selected"?>>BTC</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?=$languages_text["form_amount"][$this_language_key]?></label>
                            <input type="text" name="summa" value="<?=(string)$form_data["summa"]?>">  
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?=$languages_text["form_paymentsystem"][$this_language_key]?></label>
                            <div class="select">
                                <select name="paysystem">
                                    <?foreach(data::paysystems_plus_form() AS $key => $paysystem):?>
                                        <option value="<?=$key?>" data-currency="<?=$paysystem["currency"]?>" <?if((string)$form_data["paysystem"] == $key) echo "selected"?>><?=$paysystem["name"]?></option>
                                    <?endforeach?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-sm-6 col-xs-12 form_help">
                        <?= message::msg("money_plus"); ?>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 text-right">
                        <button type="submit" class="btn__green"><?=$languages_text["form_button"][$this_language_key]?></button>
                    </div>
                </div>
            </form>

            <div class="pay_systems">
                <h3><?=$languages_text["paymentsystems_title"][$this_language_key]?></h3>
                <ul>
                    <li data-currency="RUB" data-summa="1000"  data-paysystem="bank">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_sberbank.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 1000 
                                <i class="fal fa-ruble-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="RUB" data-summa="1000"  data-paysystem="yandex">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_yandex.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 1000
                                <i class="fal fa-ruble-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="RUB" data-summa="1000"  data-paysystem="bank">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_tinkoff.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 1000 
                                <i class="fal fa-ruble-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="RUB" data-summa="1000"  data-paysystem="bank">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_alpha-bank.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 1000 
                                <i class="fal fa-ruble-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="BTC" data-summa="0.01" data-paysystem="bitcoin">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_bitcoin.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 0.01
                                <i class="fal fa-btc"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="USD" data-summa="15" data-paysystem="advcash">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_advcash.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 15
                                <i class="fal fa-dollar-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="RUB" data-summa="1000" data-paysystem="qiwi">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_qiwi.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 1000
                                <i class="fal fa-dollar-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="USD" data-summa="15" data-paysystem="payeer">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_payeer.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 15
                                <i class="fal fa-dollar-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>

                    <li data-currency="USD" data-summa="15" data-paysystem="pm">
                        <div class="pay_system">
                            <img src="/templates/images/paysystem_pm.png" />
                            <h4>
                                <?=$languages_text["paymentsystems_min"][$this_language_key]?> 15
                                <i class="fal fa-dollar-sign"></i>
                            </h4>
                            <p>
                                <?=$languages_text["paymentsystems_commission"][$this_language_key]?>
                            </p>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?endif;?>

<div class="row">
    <div class="col-sm-12">
        <div class="table_block">
            <h3><?=$languages_text["table_title"][$this_language_key]?></h3>
            <? if (!empty($list["moneys"])): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th><?=$languages_text["table_col_1"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_2"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_3"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_4"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_5"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_6"][$this_language_key]?></th>
                        </tr>
                    </thead>
                    <tbody>

                        <? foreach ($list["moneys"] as $money): ?>
                            <tr>
                                <td data-label="<?=$languages_text["table_col_1"][$this_language_key]?>">
                            <?= $money["id"] ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_2"][$this_language_key]?>">
                                <?= date::dateFormatView(["datetime" => $money["date_created"]]); ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_3"][$this_language_key]?>">
                        <?= data::currency_rounding($money["summa"], $money["currency"], true) ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_4"][$this_language_key]?>">
                                        <?= $money["currency"] ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_5"][$this_language_key]?>">
                                    <?= data::paysystems_plus_list($money["paysystem"]) ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_6"][$this_language_key]?>">
                                    <? if ($money["status"] == 0): ?>
                                        <span class="label label-default">
                                            <?=$languages_text["label_none"][$this_language_key]?>
                                        </span>
                                    <? elseif ($money["status"] == 1): ?>
                                        <span class="label label-warning">
                                            <?=$languages_text["label_success_user"][$this_language_key]?>
                                        </span>
                                    <? elseif ($money["status"] == 2): ?>
                                        <span class="label label-success">
                                            <?=$languages_text["label_success"][$this_language_key]?>
                                        </span>
                                    <? elseif ($money["status"] == 3): ?>
                                        <span class="label label-success">
                                            <?=$languages_text["label_success"][$this_language_key]?>
                                        </span>
                                    <? elseif ($money["status"] == 5): ?>
                                        <span class="label label-danger">
                                            <?=$languages_text["label_danger"][$this_language_key]?>
                                        </span>
                                    <? endif; ?>
                                </td>
                            </tr>
                        <? endforeach; ?> 
                    </tbody>
                </table>
                <?= $pagination ?>
            <? else : ?>
                <div class="alert alert-warning">
                    <?=$languages_text["empty_table"][$this_language_key]?>
                </div>
            <? endif; ?>
        </div>
    </div>
</div>