<?php

class comMoney_controlPlus {

    function display() {
        $return = "";
        
        $limit = 20;
        
        require_once ( COM_PATH . "/money/plus/model.php" );
        $list = comMoney_modelPlus::moneys(["limit"=>$limit]);
       
        require_once (COM_PATH . "/pagination/pagination.php" );
        $pagination = Pagination::view($list["count"], $limit);
        
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();
        
        $form_data = $_SESSION["form_data"];
        unset($_SESSION["form_data"]);
        
        
        $this_language_key = language::lang();
        
        $languages_text["form_title"]["ru"] = "Пополнение средств";
        $languages_text["form_title"]["en"] = "Replenishment of funds";
        
        $languages_text["form_currency"]["ru"] = "Валюта";
        $languages_text["form_currency"]["en"] = "Currency";
        
        $languages_text["form_amount"]["ru"] = "Сумма ввода";
        $languages_text["form_amount"]["en"] = "Input amount";
        
        $languages_text["form_paymentsystem"]["ru"] = "Платежная система";
        $languages_text["form_paymentsystem"]["en"] = "Payment system";
        
        $languages_text["form_button"]["ru"] = "Пополнить";
        $languages_text["form_button"]["en"] = "Replenish";
        
        
        $languages_text["paymentsystems_title"]["ru"] = "Платежные системы";
        $languages_text["paymentsystems_title"]["en"] = "Payment systems";
        
        $languages_text["paymentsystems_min"]["ru"] = "мин.";
        $languages_text["paymentsystems_min"]["en"] = "min.";
        
        $languages_text["paymentsystems_commission"]["ru"] = "комиссия 2.5% от суммы ";
        $languages_text["paymentsystems_commission"]["en"] = "commission 2.5% of the amount";
        
        
        $languages_text["table_title"]["ru"] = "История начислений";
            $languages_text["table_title"]["en"] = "Accrual history";
            
            
            $languages_text["table_col_1"]["ru"] = "№";
            $languages_text["table_col_1"]["en"] = "No.";
            
            $languages_text["table_col_2"]["ru"] = "Дата";
            $languages_text["table_col_2"]["en"] = "Date";
            
            $languages_text["table_col_3"]["ru"] = "Сумма";
            $languages_text["table_col_3"]["en"] = "Amount";
            
            $languages_text["table_col_4"]["ru"] = "Счет";
            $languages_text["table_col_4"]["en"] = "Score";
            
            $languages_text["table_col_5"]["ru"] = "Система";
            $languages_text["table_col_5"]["en"] = "System";
            
            $languages_text["table_col_6"]["ru"] = "Статус";
            $languages_text["table_col_6"]["en"] = "Status";
            
            $languages_text["label_none"]["ru"] = "Не подтвержвен";
            $languages_text["label_none"]["en"] = "Not confirmed";
            
            $languages_text["label_success_user"]["ru"] = "Подтвержден пользователем";
            $languages_text["label_success_user"]["en"] = "User Confirmed";
            
            $languages_text["label_success"]["ru"] = "Подтвержден";
            $languages_text["label_success"]["en"] = "Confirmed";
            
            $languages_text["label_danger"]["ru"] = "Отклонен";
            $languages_text["label_danger"]["en"] = "Rejected";
            
        
            
            
            $languages_text["empty_table"]["ru"] = "История пополнений пуста";
            $languages_text["empty_table"]["en"] = "Recharge History is empty";
        
        ob_start();
        require_once ( COM_PATH . "/money/plus/view.php" );
        $return .= ob_get_clean();


        return $return;
    }

    function display_confirm($hash) {
        require_once ( COM_PATH . "/money/plus/model.php" );

        
        $money = comMoney_modelPlus::money_hash($hash);
       
        if($money["user"] != $_SESSION["user"]["id"]){
            Controller::redirect();
        }
        
        $paysystem = comMoney_modelPlus::paysystem($money["paysystem"]);


        $this_language_key = language::lang();
        
        $languages_text["title"]["ru"] = "Подтверждение пополнения";
        $languages_text["title"]["en"] = "Replenishment Confirmation";
        
        if($money["paysystem"] == "bitcoin"){
            $languages_text["text_default_1"]["ru"] = "Вам необходимо перевести <b>%s</b> на кошелек <b>%s</b>";
            $languages_text["text_default_1"]["en"] = "You need to transfer <b>%s </b> to wallet <b>%s</b>";
            
            $languages_text["text_default_2"]["ru"] = "В течении 24 часов после нескольких подтверждений сети Биткоин на баланс будет зачислено: <b>%s</b>";
            $languages_text["text_default_2"]["en"] = "Within 24 hours after several confirmations of the Bitcoin network, the balance will be credited to:%s";
        }elseif($money["paysystem"] == "yandex"){
            $languages_text["text_default_1"]["ru"] = "Вам необходимо перевести <b>%s</b> на номер счета <b>%s</b>";
            $languages_text["text_default_1"]["en"] = "You need to transfer <b>%s</b> to the account number <b>%s</b>";
            
            $languages_text["text_default_2"]["ru"] = "В течении 24 часов на баланс будет зачислено:<b>%s</b>";
            $languages_text["text_default_2"]["en"] = "Within 24 hours, the balance will be credited: <b>%s</b>";
        }elseif($money["paysystem"] == "qiwi"){
            $languages_text["text_default_1"]["ru"] = "Вам необходимо перевести <b>%s</b> на номер телефона в системе QIWI <b>%s</b>";
            $languages_text["text_default_1"]["en"] = "You need to transfer <b>%s</b> to a phone number in QIWI system <b>%s</b>";
            
            $languages_text["text_default_2"]["ru"] = "В течении 24 часов на баланс будет зачислено:<b>%s</b>";
            $languages_text["text_default_2"]["en"] = "Within 24 hours, the balance will be credited: <b>%s</b>";
        }elseif($money["paysystem"] == "bank"){  
            $languages_text["text_default_1"]["ru"] = "Для осуществления банковского перевода обратитесь к онлайн - консультанту для получения реквизитов перевод";
            $languages_text["text_default_1"]["en"] = "To make a bank transfer, contact an online consultant to get the details of the transfer";
            
            $languages_text["text_default_2"]["ru"] = "В течении 24 часов после получения перевода баланс личного кабинета будет пополнен на сумму: <b>%s</b>";
            $languages_text["text_default_2"]["en"] = "Within 24 hours after receiving the transfer, the balance of your personal account will be replenished by the amount: <b>% s </b>";
        }elseif($money["paysystem"] == "advcash" || $money["paysystem"] == "payeer" || $money["paysystem"] == "pm"){  
            $languages_text["text_default_1"]["ru"] = "Вам необходимо перевести <b>%s</b> на номер счета <b>%s</b>";
            $languages_text["text_default_1"]["en"] = "You need to transfer <b>% s</b> to the account number <b>%s</b>";
            
            $languages_text["text_default_2"]["ru"] = "В течении 24 часов на баланс будет зачислено:<b>%s</b>";
            $languages_text["text_default_2"]["en"] = "Within 24 hours, the balance will be credited: <b>%s</b>";
        }
        
        $languages_text["button"]["ru"] = "Подтверждаю!";
        $languages_text["button"]["en"] = "I confirm!";
        
        $languages_text["transition_button"]["ru"] = "Переход на оплату";
        $languages_text["transition_button"]["en"] = "Transition to payment";
        
        $languages_text["text_success"]["ru"] = "Платеж успешно оплачен. Баланс пополнится в течении пары минут.";
        $languages_text["text_success"]["en"] = "Payment successfully paid. The balance will be replenished within a couple of minutes.";
        
        $languages_text["text_fail"]["ru"] = "Не удалось произвести оплату";
        $languages_text["text_fail"]["en"] = "Payment failed";
        
        ob_start();
        if($money["paysystem"] == "qiwi" && $money["currency"] != "RUB"){
            require_once ( COM_PATH . "/money/plus/confirm_default.php" );
        }elseif (file_exists(COM_PATH . "/money/plus/confirm_{$money["paysystem"]}.php")) {
            require_once ( COM_PATH . "/money/plus/confirm_{$money["paysystem"]}.php" );
        }else{
            require_once ( COM_PATH . "/money/plus/confirm_default.php" );
        }
        
        $return = ob_get_clean();

        return $return;
    }
    
    
    function display_success() {
        ob_start();
        require_once ( COM_PATH . "/money/plus/view_success.php" );
        $return = ob_get_clean();

        return $return;
    }
    
    function display_fail() {
        ob_start();
        require_once ( COM_PATH . "/money/plus/view_fail.php" );
        $return = ob_get_clean();

        return $return;
    }

    
    
}
