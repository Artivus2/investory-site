<div class="row">
    <div class="col-sm-12">
        <div class="form_block text-center">
            <div class="alert alert-success">
                <h1><?=$languages_text["text_success"][$this_language_key]?></h1>
            </div>
        </div>
    </div>
</div>