<?php
$m_amount = number_format($money["summa"], 2, '.', '');
$m_desc = base64_encode("Платеж для сайта fxartinvest.com на сумму " . data::currency_rounding($money["summa"], $money["currency"], true));

$arHash = array(
    PAYEER_SHOP,
    $money["id"],
    $m_amount,
    $money["currency"],
    $m_desc,
    PAYEER_KEY
);

$sign = strtoupper(hash('sha256', implode(':', $arHash)));
?>

<div class="row">
    <div class="col-sm-12">
        <div class="form_block text-center">
            <h3><?=$languages_text["title"][$this_language_key]?></h3>

            <form method="post" action="https://payeer.com/merchant/">
                <input type="hidden" name="m_shop" value="<?= PAYEER_SHOP ?>">
                <input type="hidden" name="m_orderid" value="<?= $money["id"] ?>">
                <input type="hidden" name="m_amount" value="<?= $m_amount ?>">
                <input type="hidden" name="m_curr" value="<?= $money["currency"] ?>">
                <input type="hidden" name="m_desc" value="<?= $m_desc ?>">
                <input type="hidden" name="m_sign" value="<?= $sign ?>">
                <input class="btn__green" type="submit" value="<?=$languages_text["transition_button"][$this_language_key]?>" name="m_process" />
            </form>
        </div>
    </div>
</div>
