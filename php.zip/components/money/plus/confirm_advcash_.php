<?php
$ac_account_email = ADVCASH_EMAIL;
$ac_sci_name = "Fxartinvest";
$ac_comments = "Платеж для сайта fxartinvest.com на сумму " . data::currency_rounding($money["summa"], $money["currency"], true);
$secret = ADVCASH_KEY;
$ac_order_id = $money["id"];
$ac_currency = $money["currency"];
$ac_amount = number_format($money["summa"], 2, '.', '');
$ac_sign = hash("sha256", "$ac_account_email:$ac_sci_name:$ac_amount:$ac_currency:$secret:$ac_order_id");
?>
<div class="row">
    <div class="col-sm-12">
        <div class="form_block text-center">
            <h3>Подтверждение пополнения</h3>

            <form method="POST" action="https://wallet.advcash.com/sci/">
                <input type="hidden" name="ac_account_email" value="<?= $ac_account_email ?>">
                <input type="hidden" name="ac_sci_name" value="<?= $ac_sci_name ?>">
                <input type="hidden" name="ac_amount" value="<?= $ac_amount ?>">
                <input type="hidden" name="ac_currency" value="<?= $ac_currency ?>">
                <input type="hidden" name="ac_order_id" value="<?= $ac_order_id ?>">
                <input type="hidden" name="ac_sign" value="<?= $ac_sign ?>">
                <input type="hidden" name="ac_comments" value="<?= $ac_comments ?>">
                <input class="btn__green" type="submit" value="Переход на оплату" />
            </form>
        </div>
    </div>
</div>