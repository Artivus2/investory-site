<?php
$pm_account = QIWI_PUBLIC;
$pm_id = $money["id"];
$amount = number_format($money["summa"], 2, '.', '');
?>

<div class="row">
    <div class="col-sm-12">
        <div class="form_block text-center">
            <h3><?=$languages_text["title"][$this_language_key]?></h3>
            <form action="https://oplata.qiwi.com/create" method="GET">
                <input type="hidden" name="publicKey" value="<?= QIWI_PUBLIC ?>">
                <input type="hidden" name="amount" value="<?= $amount ?>">
                <input type="hidden" name="successUrl" value="http://fxartinvest.ainix-site.ru/refill/success">
                <input type="hidden" name="billId" value="<?= $pm_id ?>">
                <input type="hidden" name="customFields[themeCode]" value="Ylia-ACJa7WpETS">
                <input class="btn__green" type="submit" value="<?=$languages_text["transition_button"][$this_language_key]?>" />
            </form>
        </div>
    </div>
</div>

