<?php
$pm_account = PM_ACCOUNT;
$pm_name = "Fxartinvest.com";
$pm_id = $money["id"];
$pm_amount = number_format($money["summa"], 2, '.', '');
?>

<div class="row">
    <div class="col-sm-12">
        <div class="form_block text-center">
            <h3><?=$languages_text["title"][$this_language_key]?></h3>
            <form action="https://perfectmoney.is/api/step1.asp" method="POST">
                <input type="hidden" name="PAYEE_ACCOUNT" value="<?= $pm_account ?>">
                <input type="hidden" name="PAYEE_NAME" value="<?= $pm_name ?>">
                <input type="hidden" name="PAYMENT_ID" value="<?= $pm_id ?>">
                <input type="hidden" name="PAYMENT_AMOUNT" value="<?= $pm_amount ?>">
                <input type="hidden" name="PAYMENT_UNITS" value="<?= $money["currency"] ?>">
                <input type="hidden" name="STATUS_URL" value="http://fxartinvest.ainix-site.ru/refill/pm/status">
                <input type="hidden" name="PAYMENT_URL" value="http://fxartinvest.ainix-site.ru/refill/success">
                <input type="hidden" name="PAYMENT_URL_METHOD" value="Get">
                <input type="hidden" name="NOPAYMENT_URL" value="http://fxartinvest.ainix-site.ru/refill/fail">
                <input type="hidden" name="NOPAYMENT_URL_METHOD" value="Get">
                <input class="btn__green" type="submit" value="<?=$languages_text["transition_button"][$this_language_key]?>" name="PAYMENT_METHOD" />
            </form>
        </div>
    </div>
</div>

