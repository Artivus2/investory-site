<?php

class comMoney_modelPlus {

    function money($id) {
        return DB::select("SELECT * FROM `money_in` WHERE id = '$id' LIMIT 1", "row");
    }

    function money_hash($hash) {
        return DB::select("SELECT * FROM `money_in` WHERE `hash` = '$hash' LIMIT 1", "row");
    }

    function moneys($data = array()) {
        if (isset($data["limit"])) {
            $page = (int) isset($data['page']) ? $data['page'] : $_GET['page'];
            $start = (!empty($page)) ? ($page - 1) * $data["limit"] : 0;
            $limit = " LIMIT $start, " . $data["limit"];
        }


        $return["moneys"] = DB::select("SELECT SQL_CALC_FOUND_ROWS m.*, ps.`name` AS paysystem_name
                                FROM `money_in` m 
                                LEFT JOIN `paysystems` ps ON ps.`key` = m.`paysystem` 
                                WHERE m.`user`='{$_SESSION["user"]["id"]}' ORDER BY m.`id` DESC $limit", "all");

        $return["count"] = DB::select("SELECT FOUND_ROWS() cnt", "row")["cnt"];

        return $return;
    }

    function paysystem($key) {
        return DB::select("SELECT * FROM `paysystems` WHERE `key` = '$key' LIMIT 1", "row");
    }

    function new_money() {
        $currency = $_POST["currency"];
        $summa = data::currency_rounding($_POST["summa"], $currency);
        $paysystem = $_POST["paysystem"];

        if ($currency == "RUB") {
            $min = 1000;
            $max = 100000;
        } elseif ($currency == "USD") {
//            $min = 0.05;
            $min = 15;
            $max = 1000;
        } elseif ($currency == "BTC") {
            $min = 0.001;
            $max = 4;
        } else {
            Controller::redirect();
        }

        $_SESSION["form_data"] = $_POST;

        if (empty($currency)) {
            Controller::redirect();
        } elseif (empty($summa)) {
            message::new_msg("money_plus", "danger", sprintf(language::lang_text("[:ru]Введите корректную сумму (от %s до %s)![:en]Enter the correct amount (from %s to %s)![:]"), data::currency_rounding($min, $currency, true) , data::currency_rounding($max, $currency, true)));
            return false;
        } elseif ($summa < $min) {
            message::new_msg("money_plus", "danger", sprintf(language::lang_text("[:ru]Минимальная сумма разового пополнения %s[:en]Minimum amount of one-time replenishment %s[:]"), data::currency_rounding($min, $currency, true)));
            return false;
        } elseif ($summa > $max) {
            message::new_msg("money_plus", "danger", sprintf(language::lang_text("[:ru]Максимальная сумма разового пополнения %s[:en]Maximum amount of one-time replenishment %s[:]"), data::currency_rounding($max, $currency, true)));
            return false;
        } elseif (empty($paysystem)) {
            message::new_msg("money_plus", "danger", "[:ru]Выберите способ пополнения[:en]Choose a replenishment method[:]");
            return false;
        }

        $new_money_data = [];
        $new_money_data["user"] = $_SESSION["user"]["id"];
        $new_money_data["summa"] = $summa;
        $new_money_data["paysystem"] = $paysystem;
        $new_money_data["date_created"] = date("Y-m-d H:i:s");
        $new_money_data["date_update"] = date("Y-m-d H:i:s");
        $new_money_data["currency"] = $currency;
        $new_money_data["hash"] = md5("refill+" . implode("-", $new_money_data));

        $new_money = DB::insert("INSERT INTO `money_in` ?set", $new_money_data);

        Controller::telegram("Пополнение (запрос): {$_SESSION["user"]["login"]} , Сумма: " . data::currency_rounding($summa, $currency, true));
        return ["id" => $new_money["id"], "hash" => $new_money_data["hash"]];
    }

    function success() {
        $id = (int) $_POST["id"];
        $money_data = self::money($id);
        if ($money_data["user"] != $_SESSION["user"]["id"]) {
            message::new_msg("money_plus", "danger", "[:ru]Вы не можете подтвердить чужой счет[:en]You cannot verify someone else’s account[:]");
        }
        DB::update("UPDATE `money_in` SET ?set WHERE `id`='$id'", array("date_update" => date("Y-m-d H:i:s"), 'status' => 1));
        Controller::telegram("Пополнение (подтверждение пользователем): {$_SESSION["user"]["login"]}, Сумма: " . data::currency_rounding($money_data["summa"], $money_data["currency"], true));
    }

    function pm_status() {
        file_put_contents("pm_1.txt", serialize($_POST));
        $hash_arr = [];
        $hash_arr[] = $_POST["PAYMENT_ID"];
        $hash_arr[] = $_POST["PAYEE_ACCOUNT"];
        $hash_arr[] = $_POST["PAYMENT_AMOUNT"];
        $hash_arr[] = $_POST["PAYMENT_UNITS"];
        $hash_arr[] = $_POST["PAYMENT_BATCH_NUM"];
        $hash_arr[] = $_POST["PAYER_ACCOUNT"];
        $hash_arr[] = strtoupper(md5(PM_KEY));
        $hash_arr[] = $_POST["TIMESTAMPGMT"];
        $hash = strtoupper(md5(implode(":", $hash_arr)));

        $order_id = (int) $_POST['PAYMENT_ID'];

        if ($hash == $_POST['V2_HASH']) {
            file_put_contents("pm_2.txt", serialize($_POST));
            $update_sum = sprintf("%01.6f", $_POST["PAYMENT_AMOUNT"]);

            $money_in = DB::select("SELECT * FROM `money_in` WHERE `id` = '$order_id' AND `status` = 0 LIMIT 1", "row");
            if (empty($money_in)) {
                exit;
            }

            $purse = DB::select("SELECT * FROM `user_purse` WHERE `user` = '{$money_in["user"]}' AND `currency` = '{$money_in["currency"]}' LIMIT 1", 'row');

            DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}'", array("value" => $purse["value"] + $update_sum));
            DB::update("UPDATE `money_in` SET ?set WHERE `id`='$order_id'", array("status" => 3, 'summa' => $update_sum, "date_update" => date("Y-m-d H:i:s")));

            Controller::telegram("Успешная оплата через PERFECT_MONEY: на сумму " . data::currency_rounding($update_sum, $money_in["currency"], true));
        }
    }

    function payeer_status() {
        if (isset($_POST['m_operation_id']) && isset($_POST['m_sign'])) {
            $order_id = (int) $_POST['m_orderid'];
            // Формируем массив для генерации подписи
            $arHash = array(
                $_POST['m_operation_id'],
                $_POST['m_operation_ps'],
                $_POST['m_operation_date'],
                $_POST['m_operation_pay_date'],
                $_POST['m_shop'],
                $_POST['m_orderid'],
                $_POST['m_amount'],
                $_POST['m_curr'],
                $_POST['m_desc'],
                $_POST['m_status'],
                PAYEER_KEY
            );

            // Формируем подпись
            $sign_hash = strtoupper(hash('sha256', implode(':', $arHash)));
            // Если подписи совпадают и статус платежа “Выполнен”
            if ($_POST['m_sign'] == $sign_hash && $_POST['m_status'] == 'success') {
                $update_sum = sprintf("%01.6f", $_POST["m_amount"]);

                $money_in = DB::select("SELECT * FROM `money_in` WHERE `id` = '$order_id' AND `status` = 0 LIMIT 1", "row");
                if (empty($money_in)) {
                    exit($_POST['m_orderid'] . '|error');
                }

                $purse = DB::select("SELECT * FROM `user_purse` WHERE `user` = '{$money_in["user"]}' AND `currency` = '{$money_in["currency"]}' LIMIT 1", 'row');

                DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}'", array("value" => $purse["value"] + $update_sum));
                DB::update("UPDATE `money_in` SET ?set WHERE `id`='$order_id'", array("status" => 3, 'summa' => $update_sum, "date_update" => date("Y-m-d H:i:s")));

                Controller::telegram("Успешная оплата через PAYEER: на сумму " . data::currency_rounding($update_sum, $money_in["currency"], true));

                exit($_POST['m_orderid'] . '|success');
            }
            // В противном случае возвращаем ошибку
            exit($_POST['m_orderid'] . '|error');
        }
    }

    function advcash_status() {
        if (isset($_POST['ac_order_id']) && isset($_POST['ac_hash'])) {

            $order_id = (int) $_POST["ac_order_id"];
            $arHash = [];
            $arHash[] = $_POST["ac_transfer"];
            $arHash[] = $_POST["ac_start_date"];
            $arHash[] = $_POST["ac_sci_name"];
            $arHash[] = $_POST["ac_src_wallet"];
            $arHash[] = $_POST["ac_dest_wallet"];
            $arHash[] = $_POST["ac_order_id"];
            $arHash[] = $_POST["ac_amount"];
            $arHash[] = $_POST["ac_merchant_currency"];
            $arHash[] = ADVCASH_KEY;

            $hash = strtoupper(hash('sha256', implode(':', $arHash)));

            if ($_POST['ac_hash'] == $hash && $_POST['m_status'] == 'success') {
                if ($_POST["ac_transaction_status"] == "COMPLETED") {
                    $update_sum = sprintf("%01.6f", $_POST["ac_amount"]);

                    $money_in = DB::select("SELECT * FROM `money_in` WHERE `id` = '$order_id' AND `status` = 0 LIMIT 1", "row");
                    if (empty($money_in)) {
                        exit;
                    }

                    $purse = DB::select("SELECT * FROM `user_purse` WHERE `user` = '{$money_in["user"]}' AND `currency` = '{$money_in["currency"]}' LIMIT 1", 'row');

                    DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}'", array("value" => $purse["value"] + $update_sum));
                    DB::update("UPDATE `money_in` SET ?set WHERE `id`='$order_id'", array("status" => 3, 'summa' => $update_sum, "date_update" => date("Y-m-d H:i:s")));

                    Controller::telegram("Успешная оплата через ADVCASH: на сумму " . data::currency_rounding($update_sum, $money_in["currency"], true));
                }
            }
        }
    }

    function qiwi_status() {
        $sign = array_key_exists('HTTP_X_API_SIGNATURE_SHA256', $_SERVER) ? stripslashes($_SERVER['HTTP_X_API_SIGNATURE_SHA256']) : '';
        $body = file_get_contents('php://input');
        $result = json_decode($body, true);

        $p = [];
        $p[] = $result["bill"]["amount"]["currency"];
        $p[] = $result["bill"]["amount"]["value"];
        $p[] = $result["bill"]["billId"];
        $p[] = $result["bill"]["siteId"];
        $p[] = $result["bill"]["status"]["value"];

        $hash = hash_hmac('sha256', implode("|", $p), QIWI_PRIVAT);
        $headers = getallheaders();
        $head_signature_sha256 = $headers["X-Api-Signature-SHA256"];

        if (!empty($result)) {
            $order_id = (int) $result["bill"]["billId"];
            if ($hash == $head_signature_sha256) {
                if ($result["bill"]["status"]["value"] == "PAID") {
                    $update_sum = sprintf("%01.6f", $result["bill"]["amount"]);

                    $money_in = DB::select("SELECT * FROM `money_in` WHERE `id` = '$order_id' AND `status` = 0 LIMIT 1", "row");
                    if (empty($money_in)) {
                        exit;
                    }

                    $purse = DB::select("SELECT * FROM `user_purse` WHERE `user` = '{$money_in["user"]}' AND `currency` = '{$money_in["currency"]}' LIMIT 1", 'row');

                    DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}'", array("value" => $purse["value"] + $update_sum));
                    DB::update("UPDATE `money_in` SET ?set WHERE `id`='$order_id'", array("status" => 3, 'summa' => $update_sum, "date_update" => date("Y-m-d H:i:s")));

                    Controller::telegram("Успешная оплата через QIWI: на сумму " . data::currency_rounding($update_sum, $money_in["currency"], true));
                }
            }
        }
    }

}
