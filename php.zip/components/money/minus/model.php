<?php

class comMoney_modelMinus {

    function money($id) {
        return DB::select("SELECT * FROM `money_out` WHERE id = '$id' LIMIT 1", "row");
    }

 function moneys($data = array()){  
        if (isset($data["limit"])) {
            $page = (int) isset($data['page']) ? $data['page'] : $_GET['page'];
            $start = (!empty($page)) ? ($page - 1) * $data["limit"] : 0;
            $limit = " LIMIT $start, " . $data["limit"];
        }
        
        $return["moneys"] = DB::select("SELECT SQL_CALC_FOUND_ROWS m.*, ps.`name` AS paysystem_name
                                FROM `money_out` m 
                                LEFT JOIN `paysystems` ps ON ps.`key` = m.`paysystem` 
                                WHERE m.`user`='{$_SESSION["user"]["id"]}' ORDER BY m.`id` DESC $limit", "all");
                                
        $return["count"] = DB::select("SELECT FOUND_ROWS() cnt", "row")["cnt"];                   
                          
       return $return;
    }


    function new_money() {
        $currency   = $_POST["currency"];
        $summa      = data::currency_rounding($_POST["summa"], $currency);
        $paysystem  = $_POST["paysystem"];

        if ($currency == "RUB") {
            $min = 1000;
            $max = 100000;
        } elseif ($currency == "USD") {
            $min = 10;
            $max = 100;
        } elseif ($currency == "BTC") {
            $min = 0.01;
            $max = 4;
        }else{
            Controller::redirect();
        }
        
        $_SESSION["form_data"] = $_POST;
        
        if (empty($currency)) {
            Controller::redirect();
        } elseif (empty($summa)) {
            message::new_msg("money_minus", "danger", sprintf(language::lang_text("[:ru]Введите корректную сумму (от %s до %s)![:en]Enter the correct amount (from %s to %s)![:]"),  data::currency_rounding($min, $currency, true), data::currency_rounding($max, $currency, true)));
            return false;
        } elseif ($summa < $min) {
            message::new_msg("money_minus", "danger", sprintf(language::lang_text("[:ru]Минимальная сумма разового вывода %s[:en]Minimum amount of one-time withdrawal %s[:]"), data::currency_rounding($min, $currency, true)));
            return false;
        } elseif ($summa > $max) {
            message::new_msg("money_minus", "danger", sprintf(language::lang_text("[:ru]Максимальная сумма разового вывода %s[:en]Maximum amount of one-time withdrawal %s[:]"), data::currency_rounding($max, $currency, true)));
            return false;
        } elseif (empty($paysystem)) {
            message::new_msg("money_minus", "danger", "[:ru]Выберите способ вывода[:en]Choose an output method[:]");
            return false;
        }



        $payment_detail_data = DB::select("SELECT * FROM `user_payment_details` WHERE `user`='{$_SESSION["user"]["id"]}' AND `type` = '$paysystem'", 'row');
        if (empty($payment_detail_data["value"])) {
            message::new_msg("money_minus", "danger", "[:ru]Укажите номер счета в ваших настройках.[:en]Enter the account number in your settings.[:]");
            return false;
        }

        $check_waiting_withdraw = DB::select("SELECT * FROM `money_out` m WHERE m.`status` IN (0,2) AND m.`user` = '{$_SESSION["user"]["id"]}' AND m.`date_created` > '" . date("Y-m-d H:i:s", strtotime("-1 day")) . "' LIMIT 1", "row");
        if (!empty($check_waiting_withdraw)) {
            message::new_msg("money_minus", "danger", "[:ru]Вы на сегодня исчерпали свой лимит заявок на вывод средств. Попробуйте пожалуйста завтра.[:en]You have exhausted your limit of withdrawal applications today. Please try tomorrow.[:]");
            return false;
        } elseif (date("w") == 6 || date("w") == 0) {
            message::new_msg("money_minus", "danger", "[:ru]Регламент вывода средств составляет 24 часа с момента подачи заявки в личном кабинете, с понедельника по пятницу, в рабочее время (с 09-00 по 21-00 МСК)(либо круглосуточно при наличии онлайн-консультантов).[:en]The withdrawal procedure is 24 hours from the moment of filing the application in your personal account, from Monday to Friday, during business hours (from 09-00 to 21-00 Moscow time) (or around the clock with online consultants).[:]");
            return false;
        }


        $purse = DB::select("SELECT * FROM `user_purse` WHERE `user` = '{$_SESSION["user"]["id"]}' AND `currency`='$currency' LIMIT 1", "row");

        if ($purse["value"] < $summa) {
            message::new_msg("money_minus", "danger", "[:ru]На балансе недостаточно средств[:en]Not enough funds on balance[:]");
            return false;
        }

        $new_money_data = [];
        $new_money_data["user"] = $_SESSION["user"]["id"];
        $new_money_data["summa"] = $summa;
        $new_money_data["payment_detail"] = $payment_detail_data["value"];
        $new_money_data["paysystem"] = $paysystem;
        $new_money_data["date_created"] = date("Y-m-d H:i:s");
        $new_money_data["date_update"] = date("Y-m-d H:i:s");
        $new_money_data["currency"] = $currency;

        $new_money = DB::insert("INSERT INTO `money_out` ?set", $new_money_data);


        Controller::telegram("Вывод средств (запрос): {$_SESSION["user"]["login"]} , Сумма: " . data::currency_rounding($summa, $currency, true) . ", Платежная система:" . data::payment_details($paysystem) . ", Счет: {$payment_detail_data["value"]}");
        message::new_msg("money_minus", "success", "[:ru]Ваша заявка отправлена в обработку![:en]Your application has been sent for processing![:]");
        return true;
    }

}
