<?php

class comMoney_controlMinus {

    function display() {
        $return = "";

        $limit = 20;

        require_once ( COM_PATH . "/money/minus/model.php" );
        $list = comMoney_modelMinus::moneys(["limit" => $limit]);

        require_once (COM_PATH . "/pagination/pagination.php" );
        $pagination = Pagination::view($list["count"], $limit);

        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();

        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();

        $form_data = $_SESSION["form_data"];
        unset($_SESSION["form_data"]);




        $this_language_key = language::lang();

        $languages_text["form_title"]["ru"] = "Вывод средств";
        $languages_text["form_title"]["en"] = "Withdraw funds";

        $languages_text["form_purse"]["ru"] = "Кошелек";
        $languages_text["form_purse"]["en"] = "Purse";

        $languages_text["form_amount"]["ru"] = "Сумма вывода";
        $languages_text["form_amount"]["en"] = "Withdrawal amount";

        $languages_text["form_paymentsystem"]["ru"] = "Платежная система";
        $languages_text["form_paymentsystem"]["en"] = "Payment system";

        $languages_text["form_button"]["ru"] = "Выплатить";
        $languages_text["form_button"]["en"] = "Withdraw";


        $languages_text["paymentsystems_title"]["ru"] = "Платежные системы";
        $languages_text["paymentsystems_title"]["en"] = "Payment systems";

        $languages_text["paymentsystems_min"]["ru"] = "мин.";
        $languages_text["paymentsystems_min"]["en"] = "min.";

        $languages_text["paymentsystems_commission"]["ru"] = "комиссия 2.5% от суммы ";
        $languages_text["paymentsystems_commission"]["en"] = "commission 2.5% of the amount";


        $languages_text["table_title"]["ru"] = "История вывода средств";
        $languages_text["table_title"]["en"] = "Withdrawal History";


        $languages_text["table_col_1"]["ru"] = "№";
        $languages_text["table_col_1"]["en"] = "No.";

        $languages_text["table_col_2"]["ru"] = "Дата";
        $languages_text["table_col_2"]["en"] = "Date";

        $languages_text["table_col_3"]["ru"] = "Сумма";
        $languages_text["table_col_3"]["en"] = "Amount";

        $languages_text["table_col_4"]["ru"] = "Система";
        $languages_text["table_col_4"]["en"] = "System";

        $languages_text["table_col_5"]["ru"] = "Счет";
        $languages_text["table_col_5"]["en"] = "Score";

        $languages_text["table_col_6"]["ru"] = "Статус";
        $languages_text["table_col_6"]["en"] = "Status";

        $languages_text["label_none"]["ru"] = "Ожидание";
        $languages_text["label_none"]["en"] = "Expectation";

        $languages_text["label_success"]["ru"] = "Выплачено";
        $languages_text["label_success"]["en"] = "Paid";

        $languages_text["label_danger"]["ru"] = "Отказано";
        $languages_text["label_danger"]["en"] = "Denied";


        $languages_text["empty_table"]["ru"] = "История вывода пуста";
        $languages_text["empty_table"]["en"] = "The output history is empty.";


        ob_start();
        require_once ( COM_PATH . "/money/minus/view.php" );
        $return .= ob_get_clean();


        return $return;
    }

    function display_confirm($money_id) {
        require_once ( COM_PATH . "/money/minus/model.php" );


        $money = comMoney_modelMinus::money($money_id);
        $paysystem = comMoney_modelMinus::paysystem($money["paysystem"]);

        ob_start();
        if (file_exists(COM_PATH . "/money/minus/confirm_{$money["paysystem"]}.php")) {
            require_once ( COM_PATH . "/money/minus/confirm_{$money["paysystem"]}.php" );
        } else {
            require_once ( COM_PATH . "/money/minus/confirm_default.php" );
        }

        $return = ob_get_clean();

        return $return;
    }

}
