<div class="investing">
    <div class="container">
        <div class="section__content  wow slideInUp">
            <h2><?=$languages_text["title"][$this_language_key]?></h2>
            <p><?=$languages_text["title"][$this_language_key]?></p>
            <a class="btn__green" href="/registration"><?=$languages_text["title"][$this_language_key]?></a>
        </div>
    </div>
</div>
