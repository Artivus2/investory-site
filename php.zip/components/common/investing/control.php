<?php

class comCommon_controlInvesting {

    function display() {
        global $url_data;

        $this_language_key = language::lang();

        $languages_text = [];
        $languages_text["title"]["ru"] = "Инвестируйте в свое будущее";
        $languages_text["title"]["en"] = "Invest in your future";

        $languages_text["text"]["ru"] = "FXArtinvest дает вам возможность приумножить ваш доход, став лидером в социальной торговой сети";
        $languages_text["text"]["en"] = "FX Artinvest gives you the opportunity to increase your income by becoming a leader in the social trading network";

        $languages_text["button"]["ru"] = "Инвестировать сейчас";
        $languages_text["button"]["en"] = "Invest now";

        ob_start();
        require_once ( COM_PATH . "/common/investing/view.php" );
        return ob_get_clean();
    }

}
