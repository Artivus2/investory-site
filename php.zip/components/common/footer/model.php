<?php

class comCommon_modelFooter {
    

}
