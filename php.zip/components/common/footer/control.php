<?php

class comCommon_controlFooter {

    function display() {
        global $url_data;
        
        $this_language_key = language::lang();
     
        $languages_text = [];
        
        $languages_text["menu_title_1"]["ru"] = "Меню";
        $languages_text["menu_title_1"]["en"] = "Menu";
        
        $languages_text["menu_title_2"]["ru"] = "Личный кабинет";
        $languages_text["menu_title_2"]["en"] = "Personal Area";
        
        $languages_text["menu_title_3"]["ru"] = "Мы в соц сетях";
        $languages_text["menu_title_3"]["en"] = "We are in social networks";
        
        $languages_text["home"]["ru"] = "Главная";
        $languages_text["home"]["en"] = "Home";
        
        $languages_text["about"]["ru"] = "О компании";
        $languages_text["about"]["en"] = "About company";
        
        $languages_text["news"]["ru"] = "Новости";
        $languages_text["news"]["en"] = "News";
        
        $languages_text["faq"]["ru"] = "FAQ";
        $languages_text["faq"]["en"] = "FAQ";
        
        $languages_text["conditions"]["ru"] = "Условия";
        $languages_text["conditions"]["en"] = "Conditions";
        
        $languages_text["contacts"]["ru"] = "Контакты";
        $languages_text["contacts"]["en"] = "Contacts";
        
        $languages_text["lk"]["ru"] = "Личный кабинет";
        $languages_text["lk"]["en"] = "Personal Area";
        
           
        $languages_text["investment"]["ru"] = "Инвестору";
        $languages_text["investment"]["en"] = "Investor";
        
        $languages_text["partner"]["ru"] = "Партнеру";
        $languages_text["partner"]["en"] = "To a partner";        
        
        $languages_text["webinars"]["ru"] = "Вебинары";
        $languages_text["webinars"]["en"] = "Webinars";   
        
        $languages_text["deposits"]["ru"] = "Мои депозиты";
        $languages_text["deposits"]["en"] = "My deposits";   
        
        $languages_text["deposits_history"]["ru"] = "История начислений";
        $languages_text["deposits_history"]["en"] = "Accrual history";   
        
        $languages_text["trade"]["ru"] = "Торговля";
        $languages_text["trade"]["en"] = "Trade";   
        
        $languages_text["analytics"]["ru"] = "Аналитика";
        $languages_text["analytics"]["en"] = "Analytics";   
                
        $languages_text["oferta"]["ru"] = "Публичная оферта";
        $languages_text["oferta"]["en"] = "Public offer";        
        
        $languages_text["politic"]["ru"] = "Политика конфиденциальности";
        $languages_text["politic"]["en"] = "Privacy policy";        
        
        $languages_text["usloviya"]["ru"] = "Условия Использования";
        $languages_text["usloviya"]["en"] = "Terms of Use";        
        
        $languages_text["footer_text"]["ru"] = "Компания FX ArtInvest имеет все необходимые документы. Деятельность по приему инвестиций, а также оказанию услуг доверительного управления осуществляется на законных основаниях. Используя сайт платформы, вы автоматически принимаете условия соглашения и обязуетесь выполнять правила системы.";
        $languages_text["footer_text"]["en"] = "FX ArtInvest company has all the necessary documents. Activities for the acceptance of investments, as well as the provision of trust management services, are carried out legally. Using the platform’s website, you automatically accept the terms of the agreement and agree to comply with the system’s rules.";        
        
        ob_start();
        require_once ( COM_PATH . "/common/footer/view.php" );
        $this->content = ob_get_clean();
    }

}
