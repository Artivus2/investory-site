<footer>
    <div class="container">
        <div class="footer__content">
            <div class="row">
                <div class="col-lg-3 col-md-4">
                    <a class="footer__logo" href="/">
                        <?if($this_language_key == "en"):?>
                            <img src="/templates/images/logo_en.png" alt="">
                        <?else:?>
                            <img src="/templates/images/logo.png" alt="">
                        <?endif;?>
                    </a>
                </div>
                <div class="col-lg-2 col-md-2 col-sm-4 col-6">              
                    <ul>
                        <li><h4><?=$languages_text["menu_title_1"][$this_language_key]?></h4></li>
                        <li>
                            <a href="/"><?=$languages_text["home"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/about"><?=$languages_text["about"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/investment"><?=$languages_text["investment"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/partnership"><?=$languages_text["partner"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/channel/UCMYNzC29rzpg_YL9jM01cRg" target="blank"><?=$languages_text["webinars"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/contacts"><?=$languages_text["contacts"][$this_language_key]?></a>
                        </li>
                    </ul>
                </div>
                <div class="offset-lg-1 col-lg-2 col-md-3 col-sm-4 col-6">
                    <ul>
                        <li><h4><?=$languages_text["menu_title_2"][$this_language_key]?></h4></li>
                        <li>
                           <a href="/lk"><?=$languages_text["lk"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/deposits"><?=$languages_text["new_deposit"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/deposits_history"><?=$languages_text["deposits_history"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/partnership"><?=$languages_text["partner"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/trade"><?=$languages_text["trade"][$this_language_key]?></a>
                        </li>
                        <li>
                            <a href="/analytics"><?=$languages_text["analytics"][$this_language_key]?></a>
                        </li>
                    </ul>
                </div>
                <div class="offset-lg-1 col-lg-2 col-md-3 col-sm-4">
                    <ul class="footer__social">
                        <li><h4><?=$languages_text["menu_title_3"][$this_language_key]?></h4></li>
                        <li>
                            <a href="http://vk.com/fx_artinvest" target="blank">
                                <img src="/templates/images/header-icon-social-vk.png" alt="">
                                <span>Vkontakte</span>
                            </a>
                        </li>
                        <li>
                            <a href="http://t.me/fxartinvest" target="blank">
                                <img src="/templates/images/header-icon-social-tg.png" alt="">
                                <span>Telegram</span>  
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/invites/contact/?i=37ox9vnld7md&utm_content=5184smj" target="blank">
                                <img src="/templates/images/header-icon-social-inst.png" alt="">
                                <span>Instagram</span>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.youtube.com/channel/UCMYNzC29rzpg_YL9jM01cRg" target="blank">
                                <img src="/templates/images/header-icon-social-youtube.png" alt="">     
                                <span>YouTube</span>                            
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer__text">
            <p class="offset-md-1 col-md-10">
                <?=$languages_text["footer_text"][$this_language_key]?>
            </p>
            <div class="confidentialit__agreements">
                <div class="confidentialit_list">
                    <a href="/uploads/oferta.pdf" target="blank"><?=$languages_text["oferta"][$this_language_key]?></a>
                    | 
                    <a href="/uploads/politic.pdf" target="blank"><?=$languages_text["politic"][$this_language_key]?></a>
                    | 
                    <a href="/uploads/usloviya.pdf" target="blank"><?=$languages_text["usloviya"][$this_language_key]?></a>
                </div>
            </div>
        </div>
    </div>
    <div class="footer__underline"> </div>
</footer>