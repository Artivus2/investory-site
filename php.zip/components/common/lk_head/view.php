<header>
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="top__header-left col-lg-8">
                    <ul class="top__header-left-list">
                        
                       
                        
                        <li class="top__header-left-item">
                            <a href="/" class="<? if ($URL->alias == "index") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["home"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/about" class="<? if ($URL->alias == "about") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["about"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/news" class="<? if ($URL->alias == "news") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["news"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/faq" class="<? if ($URL->alias == "faq") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["faq"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/investment" class="<? if ($URL->alias == "investment") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["investment"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/partnership" class="<? if ($URL->alias == "partnership") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["partner"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="https://www.youtube.com/channel/UCMYNzC29rzpg_YL9jM01cRg" target="_blank" class="<? if ($URL->alias == "webinars") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["webinars"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/terms" class="<? if ($URL->alias == "terms") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["conditions"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/contacts" class="<? if ($URL->alias == "contacts") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["contacts"][$this_language_key]?>
                            </a>
                        </li>
                    </ul>
                </div>
                
                <div class="top__header-right col-lg-4">
                    <div class="nav-toogle">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="top__header-right-board">
                        <div class="top__header-right-language dropdown" data-dropdown="dropdown">
                            <a href="#" class="dropdown-toggle"> <?=$this_language?> </a>
                            <ul class="dropdown-menu">
                                <? foreach ($languages as $key_language => $language):?>
                                    <li><a href="<?=controller::add_get_url(["lang"=>$key_language])?>"><?=$language?></a></li>
                                <? endforeach;?>
                            </ul>
                        </div>

                        <div class="top__header-right-lk dropdown dropdown-right" data-dropdown="dropdown">

                            <a href="#" class="dropdown-toggle"> <img class="user_avatar" src="<?=$_SESSION["user"]["avatar_dir"]?>"></a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a href="/setting">
                                        <?=$languages_text["setting"][$this_language_key]?>
                                    </a>
                                </li>
                                <li>
                                    <a href="/logout/do">
                                         <?=$languages_text["logout"][$this_language_key]?>
                                    </a>
                                </li>
                            </ul>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <div class="head_alert">
        <h3>Инвестирование временно приостановленно по техническим причинам</h3>
    </div>
</header>