<?php

class comCommon_controlPurses {

    function display() {
        global $url_data;
        if (!empty($_SESSION["user"]["id"])) {
            require_once ( COM_PATH . "/invest/purses/model.php" );
            $purses = comInvest_modelPurses::purses();

            $this_language_key = language::lang();

            $languages_text = [];
            $languages_text["title"]["ru"] = "Ваш баланс";
            $languages_text["title"]["en"] = "Your balance";
           
            ob_start();
            require_once ( COM_PATH . "/common/purses/view.php" );
            return ob_get_clean();
        }
    }

}
