<div class="row purses">
    <h3 class="col-md-12"><?=$languages_text["title"][$this_language_key]?></h3>
    <? foreach ($purses as $purse):?>
        <div class="col-md-4">
            <div class="purse">
                <span class="summa"><?=$purse["value_rounding"];?></span>
                <span class="currency"><?=data::currency_rod($purse["currency"]);?></span>
                <span class="wallet" data-currency="<?=$purse["currency"]?>">
                    <i class="fal fa-wallet"></i>
                </span>
            </div>
        </div>
    <? endforeach;?>
</div>