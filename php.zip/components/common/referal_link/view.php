<div class="referal_link">
    <h3><?=$languages_text["title"][$this_language_key]?></h3>
    <div class="referal_link_flex">
        <div class="link" id="referal_link"><?=URL?>/?ref=<?=$_SESSION["user"]["login"]?></div>
        <button class="copy" data-clipboard-action="copy" data-clipboard-target="#referal_link">
            <?=$languages_text["button"][$this_language_key]?>
        </button>
    </div>
    <?if(!empty($curator)):?>
        <br />
        <div class="curator">
            <?=$languages_text["curator"][$this_language_key]?>: <strong><?=$curator["login"]?></strong>
        </div>
    <?endif;?>
</div>