<?php

class comCommon_controlReferallink {

    function display() {
        if (!empty($_SESSION["user"])) {
            
            if(!empty($_SESSION["user"]["referrer"])){
                require_once (COM_PATH . "/user/user/model.php" );
                $curator = comUser_modelUser::user_data($_SESSION["user"]["referrer"]);
            }
            
            $this_language_key = language::lang();

            $languages_text = [];
            $languages_text["title"]["ru"] = "Ваша реферальная ссылка";
            $languages_text["title"]["en"] = "Your referral link";
            
            $languages_text["button"]["ru"] = "Скопировать";
            $languages_text["button"]["en"] = "Copy";
            
            $languages_text["curator"]["ru"] = "Ваш куратор";
            $languages_text["curator"]["en"] = "Your curator";
            
            ob_start();
            require_once ( COM_PATH . "/common/referal_link/view.php" );
            return ob_get_clean();
        } else {
            return "";
        }
    }

}
