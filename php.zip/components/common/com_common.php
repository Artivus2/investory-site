<?php

class comCommon {

    public $act = null;
    public $view = null;
    public $id = null;
    public $model = null;
    public $content = null;
    public $content_head = null;

    function __construct($get) {
        $this->act = $get['act'];
        $this->view = $get['view'];
        $this->id = $get['id'];
     

        if (isset($this->act)) {
            switch ($this->act) {


            }
        }

        if (isset($this->view)) {
            switch ($this->view) {
                case "footer":
                    require_once ( COM_PATH . "/common/footer/control.php" );
                    return comCommon_controlFooter::display();
                    break;
                case "head":
                    require_once ( COM_PATH . "/common/head/control.php" );
                    return comCommon_controlHead::display();
                    break;
                case "lk_head":
                    require_once ( COM_PATH . "/common/lk_head/control.php" );
                    return comCommon_controlLKhead::display();
                    break;
            }
        }
    }

}
