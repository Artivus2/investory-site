<div class="greeting">
    <h5>
        <?=$languages_text["title"][$this_language_key]?>, 
        <strong><?=$_SESSION["user"]["login"]?></strong>
    </h5>
    <div class="timer">
        <?=$languages_text["time"][$this_language_key]?>
        <span class="hours"></span><span class="minutes"></span><span class="seconds"></span>
    </div>
</div>