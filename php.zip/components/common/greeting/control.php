<?php

class comCommon_controlGreeting {

    function display() {
        global $url_data;
        
        $this_language_key = language::lang();

        $languages_text = [];
        $languages_text["title"]["ru"] = "Добро пожаловать в личный кабинет";
        $languages_text["title"]["en"] = "Welcome to your personal account";
        
        $languages_text["time"]["ru"] = "Время сервера";
        $languages_text["time"]["en"] = "Server time";
        
        ob_start();
        require_once ( COM_PATH . "/common/greeting/view.php" );
        return ob_get_clean();
        
    }

}
