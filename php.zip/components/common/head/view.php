<header>
    <div class="top-header">
        <div class="container">
            <div class="row">
                <div class="top__header-left col-lg-6">
                    <ul class="top__header-left-list">
                        <li class="top__header-left-item">                            
                            <a href="/" class="<? if ($URL->alias == "index") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["home"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/about" class="<? if ($URL->alias == "about") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["about"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/news" class="<? if ($URL->alias == "news") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["news"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/faq" class="<? if ($URL->alias == "faq") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["faq"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/terms" class="<? if ($URL->alias == "terms") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["conditions"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="top__header-left-item">
                            <a href="/contacts" class="<? if ($URL->alias == "contacts") echo "top__header-left-item-active"; ?>">
                                <?=$languages_text["contacts"][$this_language_key]?>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="top__header-right offset-lg-2 col-lg-4">
                    <div class="nav-toogle">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                    <div class="top__header-right-board">
                        <div class="top__header-right-language dropdown" data-dropdown="dropdown">
                            <a href="#" class="dropdown-toggle"> <?=$this_language?> </a>
                            <ul class="dropdown-menu">
                                <? foreach ($languages as $key_language => $language):?>
                                    <li><a href="<?=controller::add_get_url(["lang"=>$key_language])?>"><?=$language?></a></li>
                                <? endforeach;?>
                            </ul>
                        </div>
                        <div class="top__header-right-lk">
                            <a href="<?=$link_lk?>" class="cabinet">
                                <img src="/templates/images/header-icon-unclock.png" alt=""/>
                                <?=$languages_text["lk"][$this_language_key]?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <nav>
        <div class="container">
            <div class="row">
                <div class="nav__logo col-lg-3 col-6">
                    <a href="/">
                        <?if($this_language_key == "en"):?>
                            <img src="<?=URL?>/templates/images/logo_en.png" alt="FXartinvest" title="FXartinvest">
                        <?else:?>
                            <img src="<?=URL?>/templates/images/logo.png" alt="FXartinvest" title="FXartinvest">
                        <?endif;?>
                    </a>
                </div>
                
                
                <div class="header__menu col-lg-7">
                    <button class="close-menu"></button>
                    <ul class="header__menu-nav-list">
                        <ul class="header__menu-mobile">
                            <li class="top__header-left-item">
                                <a href="/" class="<? if ($URL->alias == "index") echo "top__header-left-item-active"; ?>">
                                    <?=$languages_text["home"][$this_language_key]?>
                                </a>
                            </li>
                            <li class="top__header-left-item">
                                <a href="/about" class="<? if ($URL->alias == "about") echo "top__header-left-item-active"; ?>">
                                    <?=$languages_text["about"][$this_language_key]?>
                                </a>
                            </li>
                            <li class="top__header-left-item">
                                <a href="/investment"  class="<? if ($URL->alias == "investment") echo "top__header-left-item-active"; ?>">
                                    <?=$languages_text["investment"][$this_language_key]?>
                                </a>
                            </li>
                            <li class="top__header-left-item">
                                <a href="/partnership" class="<? if ($URL->alias == "partnership") echo "top__header-left-item-active"; ?>">
                                    <?=$languages_text["partner"][$this_language_key]?>
                                </a>
                            </li>
                            <li class="top__header-left-item">
                                <a href="https://www.youtube.com/channel/UCMYNzC29rzpg_YL9jM01cRg" target="_blank">
                                    <?=$languages_text["webinars"][$this_language_key]?>
                                </a>
                            </li>
                            <li class="top__header-left-item">
                                <a href="/news" class="<? if ($URL->alias == "news") echo "top__header-left-item-active"; ?>">
                                    <?=$languages_text["news"][$this_language_key]?>
                                </a>
                            </li>
                            <li class="top__header-left-item">
                                <a href="/contacts" class="<? if ($URL->alias == "contacts") echo "top__header-left-item-active"; ?>">
                                    <?=$languages_text["contacts"][$this_language_key]?>
                                </a>
                            </li>
                        </ul>
                        <li class="nav__item">                            
                            <a href="/investment" class="<? if ($URL->alias == "investment") echo "nav__item-active"; ?>">
                                <?=$languages_text["investment"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="nav__item">
                            <a href="/partnership" class="<? if ($URL->alias == "partnership") echo "nav__item-active"; ?>">
                                <?=$languages_text["partner"][$this_language_key]?>
                            </a>
                        </li>
                        <li class="nav__item">
                            <a href="https://www.youtube.com/channel/UCMYNzC29rzpg_YL9jM01cRg" target="_blank">
                                <?=$languages_text["webinars"][$this_language_key]?>
                            </a>
                        </li>
                    </ul> 
                </div>
                <div class="header__social col-lg-2 col-6">
                    <ul class="social__list">
                        <li><a href="http://vk.com/fx_artinvest" target="blank"><i class="fab fa-vk"></i></a></li>
                        <li><a href="http://t.me/fxartinvest" target="blank"><i class="fab fa-telegram-plane"></i></a></li>
                        <li><a href="https://www.instagram.com/invites/contact/?i=37ox9vnld7md&utm_content=5184smj" target="blank"><i class="fab fa-instagram"></i></a></li>
                        <li><a href="https://www.youtube.com/channel/UCMYNzC29rzpg_YL9jM01cRg" target="blank"><i class="fab fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="head_alert">
        <h3>Инвестирование временно приостановленно по техническим причинам</h3>
    </div>
</header>