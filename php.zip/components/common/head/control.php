<?php

class comCommon_controlHead {

    function display() {
        global $URL;
        
        $link_lk = "/login";
//        if (!empty($_COOKIE['referal'])) {
//            $link_lk = "/registration";
//        }
        if(!empty($_SESSION["user"])){
            $link_lk = "/lk";
        }
        
        $languages = language::languages();
        $this_language_key = language::lang();
        $this_language = $languages[$this_language_key];
        unset($languages[$this_language_key]);
        
        $languages_text = [];
        $languages_text["home"]["ru"] = "Главная";
        $languages_text["home"]["en"] = "Home";
        
        $languages_text["about"]["ru"] = "О компании";
        $languages_text["about"]["en"] = "About company";
        
        $languages_text["news"]["ru"] = "Новости";
        $languages_text["news"]["en"] = "News";
        
        $languages_text["faq"]["ru"] = "FAQ";
        $languages_text["faq"]["en"] = "FAQ";
        
        $languages_text["conditions"]["ru"] = "Условия";
        $languages_text["conditions"]["en"] = "Conditions";
        
        $languages_text["contacts"]["ru"] = "Контакты";
        $languages_text["contacts"]["en"] = "Contacts";
        
        $languages_text["lk"]["ru"] = "Личный кабинет";
        $languages_text["lk"]["en"] = "Personal Area";        
           
        $languages_text["investment"]["ru"] = "Инвестору";
        $languages_text["investment"]["en"] = "Investments";

        $languages_text["partner"]["ru"] = "Партнеру";
        $languages_text["partner"]["en"] = "For partners";          
        
        $languages_text["webinars"]["ru"] = "Вебинары";
        $languages_text["webinars"]["en"] = "Webinars";
        
        
        ob_start();
        require_once ( COM_PATH . "/common/head/view.php" );
        $this->content = ob_get_clean();
       
    }

}
