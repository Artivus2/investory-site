<div class="paysystem">
    <h2><?=$languages_text["title"][language::lang()]?></h2>
    <div class="container">
        <div class="row">
            <div class="offset-lg-1 col-lg-11 credit__system">
                <div class="credit__system-item wow zoomIn" data-wow-delay="0.2s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_sberbank.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="0.4s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_yandex.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="0.6s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_tinkoff.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="0.8s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_alpha-bank.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="1s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_bitcoin.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="1.2s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_advcash.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="1.4s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_qiwi.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="1.6s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_payeer.png" alt=""></a>
                </div>
                <div class="credit__system-item wow zoomIn" data-wow-delay="1.8s" data-wow-duration="0.4s">
                    <a href=""><img src="/templates/images/paysystem_pm.png" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</div>