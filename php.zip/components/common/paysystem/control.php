<?php

class comCommon_controlPaysystem {

    function display() {
        global $url_data;

$languages_text = [];
            $languages_text["title"]["ru"] = "Платежные системы";
            $languages_text["title"]["en"] = "Payment systems";
        
        ob_start();
        require_once ( COM_PATH . "/common/paysystem/view.php" );
        return ob_get_clean();
    }

}
