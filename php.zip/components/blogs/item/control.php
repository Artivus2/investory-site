<?php

class comBlogs_controlItem {

    function display($data) {

        $return = [];
        require_once ( COM_PATH . "/blogs/item/model.php" );

        $item_data = comBlogs_modelItems::blog_post(["id" => $data["id"]]);

        
//        $sidebar = comBlogs_controlSidebar::display();

        ob_start();
        require_once ( COM_PATH . "/blogs/item/view.php" );
        $return["view"] = ob_get_clean();
        $return["title"] = $item_data["title"];
        $return["description"] = $item_data["demo_text"];
        $return["keywords"] = "";


        return $return;
    }

}
