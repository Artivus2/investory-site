<div class="breadcrumb article">
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 class="breadcrumb__title"><?= $item_data["title"] ?></h2>
                <p class="breadcrumb__text"><?= date::dateformat(["date" => $item_data["date_created"], "year" => true]) ?></p>
            </div>
        </div>
    </div>
</div>

<div class="section__article">
    <? if (!empty($item_data["image"]) && file_exists("images/news/thumb/{$item_data["image"]}")): ?>
        <div class="container">
            <div class="owl-carousel owl-theme">
                <div class="item" style="background-image: url(/images/news/<?= $item_data["image"] ?>);"></div>
            </div>
            <? if (false): ?>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="owl-navigation">
                                <button type="button" role="presentation" class="owl-prev"><i class="fal fa-long-arrow-left"></i></button>
                                <button type="button" role="presentation" class="owl-next"><i class="fal fa-long-arrow-right"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            <? endif; ?>
        </div>
    <? endif; ?>
    
    <div class="container">
        <div class="row">
            <div class="section__article-text">
                <?= $item_data["text"] ?>
                <div class="share__social col-lg-12">
                    <div class="social__list">
                        <p>Поделиться:</p>
                        <script type="text/javascript">(function (w, doc) {
                                if (!w.__utlWdgt) {
                                    w.__utlWdgt = true;
                                    var d = doc, s = d.createElement('script'), g = 'getElementsByTagName';
                                    s.type = 'text/javascript';
                                    s.charset = 'UTF-8';
                                    s.async = true;
                                    s.src = ('https:' == w.location.protocol ? 'https' : 'http') + '://w.uptolike.com/widgets/v1/uptolike.js';
                                    var h = d[g]('body')[0];
                                    h.appendChild(s);
                                }
                            })(window, document);
                        </script>
                        <div data-mobile-view="true" data-share-size="30" data-like-text-enable="false" data-background-alpha="0.0" data-pid="1854446" data-mode="share" data-background-color="#ffffff" data-share-shape="rectangle" data-share-counter-size="12" data-icon-color="#ffffff" data-mobile-sn-ids="fb.tw.ps.ok.vk." data-text-color="#000000" data-buttons-color="#ffffff" data-counter-background-color="#ffffff" data-share-counter-type="disable" data-orientation="horizontal" data-following-enable="false" data-sn-ids="fb.tw.ps.ok.vk." data-preview-mobile="false" data-selection-enable="true" data-exclude-show-more="false" data-share-style="1" data-counter-background-alpha="1.0" data-top-button="false" class="uptolike-buttons" ></div>
                    </div>
                    <a href="/news" class="btn__green"> <i class="fal fa-long-arrow-left"></i> К списку новостей</a>
                </div>
            </div>
        </div>
    </div>
</div>