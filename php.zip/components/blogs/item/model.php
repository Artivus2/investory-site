<?php

class comBlogs_modelItems {

    function blog_post($data) {
        $blog_post = DB::select("SELECT * FROM `blog_post` WHERE `id` = '{$data["id"]}' LIMIT 1 ", "row");

        return $blog_post;
    }


}
