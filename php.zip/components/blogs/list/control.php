<?php

class comBlogs_controlList {

    function display($data) {
        $return = "";
        require_once ( COM_PATH . "/blogs/list/model.php" );
        require_once ( COM_PATH . "/blogs/sidebar/control.php" );
        $limit = 20;
//        $data["limit"] = $limit;
        $category = comBlogs_modelList::category((int)$data["category"]);
        
        $items = comBlogs_modelList::items_list($data);
       
        if((int) $_GET['page'] > ceil($items["count"]/$limit)){
            return "404";
        }
        
        
//        $sidebar = comBlogs_controlSidebar::display();
//        
//       
//        require_once (COM_PATH . "/pagination/pagination.php" );
//        $pagination = Pagination::view($items["count"], $limit);
        
        ob_start();
        require_once ( COM_PATH . "/blogs/list/view.php" );
        $return .= ob_get_clean();

     
        return $return;
    }

    function filter($default_filter = array()) {
        $get_filter = $_GET["filter"];
        
        foreach ((array) $default_filter as $key => $default_filter_el) {
            if (!empty($get_filter[$key])) {
                $value_arr = explode(";", $_GET["filter"][$key]);
                $filter[$key] = [];
                $filter[$key]["start"] = (string) $value_arr[0];
                $filter[$key]["end"] = (string) $value_arr[1];
                if (empty($filter[$key]["start"])) {
                    $filter[$key]["start"] = $default_filter_el["min"];
                }
                if (empty($filter[$key]["end"])) {
                    $filter[$key]["end"] = $default_filter_el["max"];
                }
            } else {
                $filter[$key]["start"] = $default_filter_el["min"];
                $filter[$key]["end"] = $default_filter_el["max"];
            }
            $filter[$key]["min"] = $default_filter_el["min"];
            $filter[$key]["max"] = $default_filter_el["max"];
            unset($get_filter[$key]);
        }
        foreach ((array)$get_filter as $key=> $filter_el) {
             $filter[$key] = $filter_el;
        }
        
        return $filter;
    }

}
