<?php

class comBlogs_modelList {

    function category($id){
       return DB::select("SELECT * FROM `blog_category` bc WHERE bc.`id` = '$id'");
    }
    


    function items_list($data = array()) {
        $where = "";
        if(!empty($data["category"])){
//            $where .= " AND bp.`category` = '{$data["category"]}' ";
        }
      
         if (isset($data["limit"])) {
            $thisPage = (int) $_GET['page'];
            $start = (empty($thisPage)) ? 0 : ($thisPage - 1) * $data["limit"];
            $limit = " LIMIT $start, " . $data["limit"];
        }
        
        $sql = "SELECT SQL_CALC_FOUND_ROWS bp.* 
                FROM `blog_post` bp 
                WHERE bp.`publication` = 1 $where
                ORDER BY bp.`date_created` DESC $limit";
               $return["list"] = DB::select($sql, "all");

        $return["count"] = DB::select("SELECT FOUND_ROWS() AS `count`", 'row')["count"];
        return $return;
    }


}
