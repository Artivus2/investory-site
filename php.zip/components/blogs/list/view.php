<div class="breadcrumb news">
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 class="breadcrumb__title"><?= $category["title"] ?></h2>
            </div>
        </div>
    </div>
</div>

<div class="news__list">
    <div class="container">
        <div class="row">
            <? foreach ($items["list"] as $key => $item): ?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="news__item">
                        <? if ($item["image"] && file_exists("images/news/thumb/{$item["image"]}")): ?>
                            <div class="item__img">
                                <img alt="<?= $item["title"] ?>" src="/images/news/thumb/<?= $item["image"] ?>">
                            </div>
                        <? endif; ?>

                        <div class="news__item-info">
                            <div>
                                <time><i class="far fa-clock"></i> <?= date::dateformat(["date" => $item["date_created"], "year" => true]) ?></time>
                                <h5><?= $item["title"] ?></h5>
                                <p><?= $item["demo_text"] ?></p>
                            </div>
                            <a href="/news?item=<?= $item["id"] ?>" class="btn">Подробнее</a>
                        </div>
                    </div>
                </div>
            <? endforeach; ?>
        </div>
    </div>
</div>
