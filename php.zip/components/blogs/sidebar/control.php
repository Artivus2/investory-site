<?php

class comBlogs_controlSidebar {

    function display() {
        $return = "";
        require_once ( COM_PATH . "/blogs/sidebar/model.php" );

        $company_list = comBlogs_modelSidebar::company_list($data);
        
        ob_start();
        require_once ( COM_PATH . "/blogs/sidebar/view.php" );
        $return .= ob_get_clean();


        return $return;
    }

}
