<div class="range sidebar">
    <div class="col-md-6 col-lg-12 order-lg-1">
        <h6>Компании</h6>
        <div class="divider-lg offset-top-10"></div>
        <ul class="list-marked offset-top-22">
            <? foreach ($company_list as $company):?>
                <li><a href="/news/<?=$company["id"]?>"><?=$company["name"]?> (<?=$company["count_posts"]?>)</a></li>
            <? endforeach;?>
        </ul>
    </div>
</div>
