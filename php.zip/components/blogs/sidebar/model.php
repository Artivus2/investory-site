<?php
class comBlogs_modelSidebar {
    function company_list($data = array()) {
        $sql = "SELECT COUNT(bp.`id`) AS `count_posts`, c.* FROM `blog_post` bp 
                LEFT JOIN `company` c ON c.`id` = bp.`company`
                WHERE bp.`publication` = 1
                GROUP BY bp.`company`";
        return DB::select($sql, "all");
    }
}
