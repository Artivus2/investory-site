<?php

class comBlogs {

    public $act = null;
    public $view = null;
    public $id = null;
    public $model = null;
    public $content = null;
    public $content_head = null;
    public $title = null;

    function __construct($get) {
        $this->act = $get['act'];
        $this->view = $get['view'];
        $this->id = $get['id'];
        global $url_data;
        if (isset($this->act)) {
            switch ($this->act) {

            }
        }

        if (isset($this->view)) {
            switch ($this->view) {
                case "list":
                    $item   = (int) $_GET["item"];
                    
                    if(!empty($item)){
                        require_once ( COM_PATH . "/blogs/item/control.php" );
                        $item = comBlogs_controlItem::display(["id" => $item]);

                        $this->content = $item["view"];
                        $this->title = $item["title"];
                        $this->keywords = $item["keywords"];
                        $this->description = $item["description"];
                    }else{
                        require_once ( COM_PATH . "/blogs/list/control.php" );
                        $this->content = comBlogs_controlList::display(["category" => (int) $get["category"], "company" => (int) $get["company"]]);

                        if($this->content == "404"){
                            require_once ( COM_PATH . "/pages/404/control.php" );
                            $this->content = comPages_control404::display();
                        }
                        $this->keywords = $url_data["keywords"];
                        $this->description = $url_data["description"];
                    }
                    break;
            }
        }
    }

}
