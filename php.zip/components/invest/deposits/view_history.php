<?= $greeting_block ?>
<?= $purses_block ?>


<div class="row" id="list">
    <div class="col-sm-12">
        <div class="table_block">
            <h3><?= $languages_text["table_title"][$this_language_key] ?></h3>
            <? if (!empty($list["list"])): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th><?= $languages_text["table_col_1"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_2"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_3"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_4"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_5"][$this_language_key] ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <? foreach ($list["list"] as $statistic): ?>
                            <tr>
                                <td data-label="<?= $languages_text["table_col_1"][$this_language_key] ?>">
                                    <?= $statistic["deposit"] ?>
                                </td>
                                <td data-label="<?= $languages_text["table_col_2"][$this_language_key] ?>">
                                    <?= date::dateFormatView(["datetime" => $statistic["date_created"]]); ?>
                                </td>
                                <td data-label="<?= $languages_text["table_col_3"][$this_language_key] ?>">
                                    <?= data::currency_rounding($statistic["summa"], $statistic["currency"], true) ?>
                                </td>
                                <td data-label="<?= $languages_text["table_col_4"][$this_language_key] ?>">
                                    <?= language::lang_text($statistic["plan_name"]) ?>
                                </td>
                                <td data-label="<?= $languages_text["table_col_5"][$this_language_key] ?>">
                                    <span class="label label-success"><?=$languages_text["table_label"][$this_language_key]?></span>
                                </td>
                            </tr>
                        <? endforeach; ?>
                    </tbody>
                </table>
                <?= $pagination ?>
            <? else: ?>
                <div class="alert alert-warning">
                    <?=$languages_text["empty_table"][$this_language_key]?>
                </div>
            <? endif; ?>
        </div>
    </div>
</div>