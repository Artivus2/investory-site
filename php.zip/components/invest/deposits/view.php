<?= $greeting_block ?>
<?= $purses_block ?>
<?if(false):?>
<div class="row" id="new">
    <div class="col-sm-12">
        <div class="form_block">
            <h3><?= $languages_text["form_title"][$this_language_key] ?></h3>
            <form method="POST" action="/deposit/add" id="new" class="new_deposit">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["form_score"][$this_language_key] ?></label>
                            <div class="select">
                                <select name="currency">
                                    <option value="RUB">RUB</option>
                                    <option value="USD">USD</option>
                                    <option value="BTC">BTC</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["form_plan"][$this_language_key] ?></label>
                            <div class="select">
                                <select name="plan">
                                    <? foreach ($plans as $plan): ?>
                                        <option data-currency="<?= $plan["currency"] ?>" value="<?= $plan["id"] ?>" <? if ((string) $form_data["plan"] == $plan["id"]) echo "selected" ?>>
                                            <?= language::lang_text($plan["name"]) ?>
                                        </option>
                                    <? endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["form_amount"][$this_language_key] ?></label>
                            <input type="text" value="" name="summa">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-sm-6 col-xs-12 form_help">
                        <?= message::msg("new_deposit"); ?>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 text-right">
                        <button type="submit" class="btn__green"><?= $languages_text["form_button"][$this_language_key] ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?endif;?>

<div class="row">
    <div class="col-sm-12">
        <div class="investions_plans">
            <h3><?= $languages_text["plans_title"][$this_language_key] ?></h3>
            <ul>
                <? foreach ($plans as $plan) : ?>
                    <li data-currency="<?= $plan["currency"] ?>" data-min="<?= $plan["min"] ?>" data-max="<?= $plan["max"] ?>">
                        <div class="plan_name">
                            <img src="/templates/images/daposit_plan_<?= $plan["type"] ?>.png" />
                            <?= language::lang_text($plan["name"]) ?>
                        </div>
                        <div class="plan_data">
                            <span class="procent_in_day">
                                <?= $plan["percent"] ?>%
                                <label><?= $languages_text["plans_percent"][$this_language_key] ?></label>
                            </span>
                            <span class="count_days">
                                <?= $plan["days"] ?>
                                <label><?= $languages_text["plans_days"][$this_language_key] ?></label>
                            </span>
                            <span class="min_summa">
                                <span class="currency">
                                    <?= data::currency_rounding($plan["min"], $plan["currency"], true, "icon", false) ?>
                                </span>
                                <label><?= $languages_text["plans_min"][$this_language_key] ?></label>
                            </span>
                            <span class="max_summa">
                                <span class="currency">
                                    <?= data::currency_rounding($plan["max"], $plan["currency"], true, "icon", false) ?>
                                </span>
                                <label><?= $languages_text["plans_max"][$this_language_key] ?></label>
                            </span>
                        </div>
                        <div class="plan_text">
                            <?= language::lang_text($plan["text"]) ?>
                        </div>
                    </li>
                <? endforeach; ?>
            </ul>
        </div>
    </div>
</div>

<div class="row" id="list">
    <div class="col-sm-12">
        <div class="table_block">
            <h3><?= $languages_text["table_title"][$this_language_key] ?></h3>
            <? if (!empty($list["deposits"])): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th><?= $languages_text["table_col_1"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_2"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_3"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_4"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_5"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_6"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_7"][$this_language_key] ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <? foreach ($list["deposits"] as $deposit): ?>
                            <tr>
                                <td data-label="<?=$languages_text["table_col_1"][$this_language_key]?>">
                                    <?= $deposit["id"] ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_2"][$this_language_key]?>">
                                    <?= data::currency_rounding($deposit["summa"], $deposit["currency"], true) ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_3"][$this_language_key]?>">
                                    <?= $deposit["percent"] ?>% в <?=$languages_text["table_col_3_dop"][$this_language_key]?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_4"][$this_language_key]?>">
                                    <?= date::dateFormatView(["datetime" => $deposit["date_created"]]); ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_5"][$this_language_key]?>">
                                    <div class="deposit_progress">
                                        <span class="result">
                                            <? if ($deposit["percent_complete"] >= 100): ?>
                                                <?=$languages_text["table_col_5_dop"][$this_language_key]?>
                                            <? else: ?>
                                                <?= $deposit["percent_complete"] ?>%
                                            <? endif; ?>                                            
                                        </span>
                                        <div class="scale" style="width:<?= $deposit["percent_complete"] ?>%"></div>
                                    </div>
                                </td>
                                <td data-label="<?=$languages_text["table_col_6"][$this_language_key]?>">
                                    <?= date::dateFormatView(["datetime" => $deposit["date_next"]]); ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_7"][$this_language_key]?>">
                                    <? if ($deposit["status"] == 0): ?>
                                        <span class="label label-success"><?=$languages_text["label_active"][$this_language_key]?></span>
                                    <? else: ?>
                                        <span class="label label-warning"><?=$languages_text["label_completed"][$this_language_key]?></span>
                                    <? endif; ?>
                                </td>
                            </tr>
                        <? endforeach; ?>
                    </tbody>
                </table>
                <?= $pagination ?>
            <? else: ?>
                <div class="alert alert-warning">
                    <?=$languages_text["empty_table"][$this_language_key]?>
                </div>
            <? endif; ?>
        </div>
    </div>
</div>