<?php

class comInvest_controlDeposits {

    function display() {
        $return = "";
        require_once ( COM_PATH . "/invest/deposits/model.php" );
        $limit = 10;
        $plans = comInvest_modelDeposits::plans();
        
        $list = comInvest_modelDeposits::deposits(["limit"=>$limit]);
        foreach ($list["deposits"] as $key => $deposit){
            $list["deposits"][$key]["percent_complete"] = round(($deposit['count'] / $deposit['dayworks'] * 100), 1);
        }
        
        require_once (COM_PATH . "/pagination/pagination.php" );
        $pagination = Pagination::view($list["count"], $limit);
       
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();
                 
        $form_data = $_SESSION["form_data"];
        unset($_SESSION["form_data"]);
        
        

        $this_language_key = language::lang();

        $languages_text["form_title"]["ru"] = "Создать депозит";
        $languages_text["form_title"]["en"] = "Create deposit";

        $languages_text["form_score"]["ru"] = "Счет";
        $languages_text["form_score"]["en"] = "Score";

        $languages_text["form_amount"]["ru"] = "Сумма";
        $languages_text["form_amount"]["en"] = "Amount";

        $languages_text["form_plan"]["ru"] = "План";
        $languages_text["form_plan"]["en"] = "Plan";
        
        $languages_text["form_button"]["ru"] = "Создать";
        $languages_text["form_button"]["en"] = "Create";
        
        
        
        $languages_text["plans_title"]["ru"] = "Инвестиционные планы";
        $languages_text["plans_title"]["en"] = "Investment plans";
        
        $languages_text["plans_percent"]["ru"] = "В день";
        $languages_text["plans_percent"]["en"] = "In a day";
        
        $languages_text["plans_days"]["ru"] = "Дней";
        $languages_text["plans_days"]["en"] = "Days";
        
        $languages_text["plans_min"]["ru"] = "Минимум";
        $languages_text["plans_min"]["en"] = "Minimum";
        
        $languages_text["plans_max"]["ru"] = "Максимум";
        $languages_text["plans_max"]["en"] = "Maximum";
        
        

        $languages_text["table_title"]["ru"] = "Созданные депозиты";
        $languages_text["table_title"]["en"] = "Created deposits";


        $languages_text["table_col_1"]["ru"] = "№";
        $languages_text["table_col_1"]["en"] = "No.";
        
        $languages_text["table_col_2"]["ru"] = "Сумма";
        $languages_text["table_col_2"]["en"] = "Amount";

        $languages_text["table_col_3"]["ru"] = "Процент";
        $languages_text["table_col_3"]["en"] = "Percent";
        
        $languages_text["table_col_4"]["ru"] = "Дата";
        $languages_text["table_col_4"]["en"] = "Date";

        $languages_text["table_col_5"]["ru"] = "Процент завершения";
        $languages_text["table_col_5"]["en"] = "Completion percentage";

        $languages_text["table_col_6"]["ru"] = "Следующее начисление";
        $languages_text["table_col_6"]["en"] = "Next charge";

        $languages_text["table_col_7"]["ru"] = "Статус";
        $languages_text["table_col_7"]["en"] = "Status";

        $languages_text["label_active"]["ru"] = "Активный";
        $languages_text["label_active"]["en"] = "Active";
        
        $languages_text["label_completed"]["ru"] = "Завершен";
        $languages_text["label_completed"]["en"] = "Completed";
        
        $languages_text["table_col_3_dop"]["ru"] = "р. в день";
        $languages_text["table_col_3_dop"]["en"] = "rub per day";
        
        $languages_text["table_col_5_dop"]["ru"] = "Завершено";
        $languages_text["table_col_5_dop"]["en"] = "Completed";

        $languages_text["empty_table"]["ru"] = "Депозиты не созданы";
        $languages_text["empty_table"]["en"] = "No deposits created";
        
        
        ob_start();
        require_once ( COM_PATH . "/invest/deposits/view.php" );
        $return .= ob_get_clean();

        return $return;
    }

    
    function display_history(){
        $limit = 10;
     require_once ( COM_PATH . "/invest/deposits/model.php" );
        $list = comInvest_modelDeposits::deposits_history(["limit"=>$limit]);
        
        require_once (COM_PATH . "/pagination/pagination.php" );
        $pagination = Pagination::view($list["count"], $limit);
        
       require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();
        
          
        
        $this_language_key = language::lang();

        $languages_text["table_title"]["ru"] = "История начислений";
        $languages_text["table_title"]["en"] = "Accrual history";


        $languages_text["table_col_1"]["ru"] = "Депозит №";
        $languages_text["table_col_1"]["en"] = "Deposit No.";
        
        $languages_text["table_col_2"]["ru"] = "Дата начисления";
        $languages_text["table_col_2"]["en"] = "Accrual date";

        $languages_text["table_col_3"]["ru"] = "Сумма";
        $languages_text["table_col_3"]["en"] = "Amount";
        
        $languages_text["table_col_4"]["ru"] = "Тариф";
        $languages_text["table_col_4"]["en"] = "Rate";

        $languages_text["table_col_5"]["ru"] = "Статус";
        $languages_text["table_col_5"]["en"] = "Status";


        $languages_text["table_label"]["ru"] = "Начислено";
        $languages_text["table_label"]["en"] = "Active";
        

        $languages_text["empty_table"]["ru"] = "Начисления отсутствуют";
        $languages_text["empty_table"]["en"] = "No accruals";
        
        
        ob_start();
        require_once ( COM_PATH . "/invest/deposits/view_history.php" );
        $return .= ob_get_clean();
         return $return;
    }
}
