<?php

class comInvest_modelDeposits {


    function plans() {
        return DB::select("SELECT * FROM `plans` ORDER BY `order` ASC", 'all');
    }

    function plan($id) {
        return DB::select("SELECT * FROM `plans` WHERE `id` = '$id' LIMIT 1 ", 'row');
    }

    function deposits($data = array()) {
        if (isset($data["limit"])) {
            $page = (int) isset($data['page']) ? $data['page'] : $_GET['page'];
            $start = (!empty($page)) ? ($page - 1) * $data["limit"] : 0;
            $limit = " LIMIT $start, " . $data["limit"];
        }
        
        $return["deposits"] = DB::select("SELECT SQL_CALC_FOUND_ROWS d.*, p.`percent`, p.`dayworks` FROM `deposits` d
                                            LEFT JOIN `plans` p ON p.`id` = d.`plan`
                                            WHERE d.`user`='{$_SESSION["user"]['id']}' ORDER BY d.`id` DESC $limit", 'all');
                                            
        $return["count"] = DB::select("SELECT FOUND_ROWS() cnt", "row")["cnt"];                   
                          
       return $return;                    
    }
    
    function deposits_history($data = array()) {
        if (isset($data["limit"])) {
            $page = (int) isset($data['page']) ? $data['page'] : $_GET['page'];
            $start = (!empty($page)) ? ($page - 1) * $data["limit"] : 0;
            $limit = " LIMIT $start, " . $data["limit"];
        }

        
        $return["list"] = DB::select("SELECT SQL_CALC_FOUND_ROWS s.*, d.`currency`, p.`name` AS `plan_name` 
                                            FROM `statistics` s 
                                            INNER JOIN `deposits` d ON d.`id` = s.`deposit`
                                            LEFT JOIN `plans` p ON p.`id` = s.`plan`
                                            WHERE d.`user` = '{$_SESSION["user"]['id']}' ORDER BY s.id DESC $limit", 'all');
       
        $return["count"] = DB::select("SELECT FOUND_ROWS() cnt", "row")["cnt"];                   
                          
       return $return;                    
    }


    function add_deposit() {
        $currency   = trim(strip_tags($_POST["currency"]));
        $plan = (int) $_POST["plan"];
        $summa   = trim(strip_tags($_POST["summa"]));
        
        if ($plan == 0) {
            message::new_msg("new_deposit", "danger", "[:ru]Выберите план[:en]Choose a plan[:]");
            return false;
        }
        $plan_data = self::plan($plan);
        if ($plan_data == 0) {
            message::new_msg("new_deposit", "danger", "[:ru]План не найден[:en]Plan not found[:]");
            return false;
        }

        require_once ( COM_PATH . "/invest/purses/model.php" );
        $purse = comInvest_modelPurses::purse($plan_data["currency"]);

        $summa = data::currency_rounding($summa, $plan_data["currency"]);
        if ($summa == 0) {
            message::new_msg("new_deposit", "danger", "[:ru]Укажите сумму[:en]Enter amount[:]");
            return false;
        } elseif ($summa < $plan_data["min"]) {
            message::new_msg("new_deposit", "danger", sprintf(language::lang_text("[:ru]Минимальная сумма этого плана[:en]The minimum amount of this plan[:]"), data::currency_rounding($plan_data["min"], $plan_data["currency"], true)));
            return false;
        } elseif ($summa > $plan_data["max"]) {
            message::new_msg("new_deposit", "danger", sprintf(language::lang_text("[:ru]Максимальная сумма этого плана[:en]The maximum amount of this plan[:]"), data::currency_rounding($plan_data["max"], $plan_data["currency"], true)));
            return false;
        } elseif ($summa > $purse["value_rounding"]) {
            message::new_msg("new_deposit", "danger", "[:ru]У Вас недостаточно средств для создания депозита[:en]You do not have enough funds to create a deposit[:]");
            return false;
        }

        DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}'", array("date_update" => date("Y-m-d H:i:s"), 'value' => $purse["value"] - $summa));

        $last_date = date("Y-m-d H:i:s");
        $next_date = date("Y-m-d H:i:s", strtotime("+1 day"));


        //Переносим на рабочий день
        if ($plan_data["weekend"] == 1) {
            if (date("w", strtotime($next_date)) == 6) {
                $next_date = date("Y-m-d H:i:s", strtotime("+2 day", strtotime($next_date)));
            } elseif (date("w", strtotime($next_date)) == 0) {
                $next_date = date("Y-m-d H:i:s", strtotime("+1 day", strtotime($next_date)));
            }
        }

        $max_number = (int) DB::select("SELECT MAX(d.`number`) AS `max_number` FROM `deposits` d WHERE d.`user` = 1", "row")["max_number"];

        $new_deposit_data = [];
        $new_deposit_data["number"] = $max_number + 1;
        $new_deposit_data["user"] = $_SESSION["user"]["id"];
        $new_deposit_data["date_created"] = date("Y-m-d H:i:s");
        $new_deposit_data["plan"] = $plan_data["id"];
        $new_deposit_data["summa"] = $summa;
        $new_deposit_data["date_last"] = $last_date;
        $new_deposit_data["date_next"] = $next_date;
        $new_deposit_data["currency"] = $plan_data["currency"];


        $new_deposit = DB::insert("INSERT INTO `deposits` ?set", $new_deposit_data);

        require_once (COM_PATH . "/user/user/model.php" );

        $user_referrer = $_SESSION["user"]["referrer"];
        $referal_levels = DB::select("SELECT * FROM `referal_levels` ", 'all');
        foreach ($referal_levels as $referal_level) {
            if ($user_referrer == 0) {
                break;
            }
            $user = comUser_modelUser::user_data($user_referrer);
            $referal_purse = comInvest_modelPurses::purse($plan_data["currency"], $user_referrer);
            $procent_summa = sprintf("%16.6f", $summa / 100 * $referal_level["procent"]); // Сумма рефских

            DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$referal_purse["id"]}' ", [
                "date_update" => date("Y-m-d H:i:s"),
                'value' => $referal_purse["value"] + $procent_summa,
                'referal_value' => $referal_purse["referal_value"] + $procent_summa]);

            DB::insert("INSERT INTO `referal_money` ?set", [
                "user_id" => $_SESSION["user"]["id"],
                "referal_id" => $user["id"],
                "referal_summa" => $procent_summa,
                "deposit_summa" => $summa,
                "status" => 1,
                "date_created" => date("Y-m-d H:i:s"),
                "currency" => $plan_data["currency"]
            ]);
            $user_referrer = $user["referrer"];
        }
        message::new_msg("new_deposit", "success", "[:ru]Депозит успешно создан[:en]Deposit successfully created[:]");
        Controller::telegram("Создание депозита: {$_SESSION["user"]["login"]}, план {$plan_data["name"]} ".data::currency($plan_data["currency"]).", на сумму ".data::currency_rounding($summa, $plan_data["currency"], true));

        
    }

    function accrual() {
        if (config::get(["name" => "autopercent"], "row")["value"] != "on") {
            return false;
        }
        require_once ( COM_PATH . "/invest/purses/model.php" );

        $deposits = DB::select("SELECT d.*, p.`percent`, p.`dayworks`, p.`back`, p.`weekend` 
                                    FROM `deposits` d 
                                    LEFT JOIN `plans` p ON p.`id` = d.`plan`
                                    WHERE d.`date_next` <= NOW()", "all");
        foreach ($deposits as $deposit) {

            $purse = comInvest_modelPurses::purse($deposit["currency"], $deposit["user"]);

            if ($deposit["status"] == 0) {
                $procent_summa = $deposit["summa"] / 100 * $deposit["percent"];
                $purse["value"] = $purse["value"] + $procent_summa;
                DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}' ", [
                    "date_update" => date("Y-m-d H:i:s"),
                    'value' => $purse["value"]]);

                DB::insert("INSERT INTO `statistics` ?set", [
                    "deposit" => $deposit["id"],
                    "date_created" => date("Y-m-d H:i:s"),
                    "plan" => $deposit["plan"],
                    "summa" => $procent_summa
                ]);
            }

            if (intval($deposit["count"] + 1) >= $deposit["dayworks"]) {
                if ($deposit["back"] == 1) {
                    DB::update("UPDATE `user_purse` SET ?set WHERE `id`='{$purse["id"]}' ", [
                        "date_update" => date("Y-m-d H:i:s"),
                        'value' => $purse["value"] + $deposit["summa"]]);
                }
                DB::update("UPDATE `deposits` SET ?set WHERE `id`='{$deposit["id"]}' ", ["status" => 1]);
            } else {
                $last_date = $deposit["date_next"];
                $next_date = date("Y-m-d H:i:s", strtotime("+1 day", strtotime($deposit["date_next"])));

                //Переносим на рабочий день
                if ($deposit["weekend"] == 1) {
                    if (date("w", strtotime($next_date)) == 6) {
                        $next_date = date("Y-m-d H:i:s", strtotime("+2 day", strtotime($next_date)));
                    } elseif (date("w", strtotime($next_date)) == 0) {
                        $next_date = date("Y-m-d H:i:s", strtotime("+1 day", strtotime($next_date)));
                    }
                }

                DB::update("UPDATE `deposits` SET ?set WHERE `id`='{$deposit["id"]}' ", ["count" => $deposit["count"]+1, "date_last" => $last_date, "date_next" => $next_date]);
            }
        }
    }

}
