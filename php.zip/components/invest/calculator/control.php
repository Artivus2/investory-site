<?php

class comInvest_controlCalculator {

    function display() {
        global $url_data;

        
        
    
        $this_language_key = language::lang();

        $languages_text = [];
        $languages_text["title"]["ru"] = "Калькулятор доходности";
        $languages_text["title"]["en"] = "Profitability calculator";
        
        $languages_text["summa"]["ru"] = "Сумма инвестиции";
        $languages_text["summa"]["en"] = "Investment Amount";
        
        $languages_text["daily_charge"]["ru"] = "Ежедневное начисление ";
        $languages_text["daily_charge"]["en"] = "Daily charge";
        
        $languages_text["on_working_days"]["ru"] = "по рабочим дням Форекс";
        $languages_text["on_working_days"]["en"] = "on working days Forex";
        
        $languages_text["total_profit"]["ru"] = "Общая прибыль за расчетный период ";
        $languages_text["total_profit"]["en"] = "Total profit for the billing period";
        
        $languages_text["working_days"]["ru"] = "рабочих дней";
        $languages_text["working_days"]["en"] = "working days";
        
        $languages_text["charge_amount"]["ru"] = "Сумма к начислению";
        $languages_text["charge_amount"]["en"] = "Charge amount";
        
        $languages_text["total_amount"]["ru"] = "Итоговая сумма";
        $languages_text["total_amount"]["en"] = "Total amount";
        
        ob_start();
        require_once ( COM_PATH . "/invest/calculator/view.php" );
        return ob_get_clean();
    }

}
