<div class="section__4">
    <h2><?=$languages_text["title"][$this_language_key]?></h2>
    <div class="container">
        <div class="calculator wow fadeIn">
            <div class="row">
                <div class="offset-md-2 col-md-8">
                    <div class="type-wallet">
                        <span><?=$languages_text["summa"][$this_language_key]?></span>
                        <div class="wallets">
                            <button class="active" data-slider="rub">₽</button>
                            <button data-slider="dollar">$</button>
                            <button data-slider="bitcoin">₿</button>
                        </div>
                    </div>
                    <div class="calc rub">
                        <div id="sliderCalcRub" class="theme"></div>
                        <div class="calc-tabs">
                            <div></div>
                            <div><span>200 000</span></div>
                            <div></div>
                            <div><span>400 000</span></div>
                            <div></div>
                            <div><span>600 000</span></div>
                            <div></div>
                            <div><span>800 000</span></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="row info">
                            <div class="col-md-6">
                                <p>
                                    <?=$languages_text["daily_charge"][$this_language_key]?> 
                                    <br>
                                    <span class="gray">(<?=$languages_text["on_working_days"][$this_language_key]?>):</span>
                                </p>
                                <p>
                                    <b>
                                        <?=$languages_text["charge_amount"][$this_language_key]?>: 
                                        <span id="numberRub">1 600</span> руб.
                                    </b>
                                </p>
                            </div>
                            <div class="offset-md-1 col-md-5">
                                <p>
                                    <?=$languages_text["total_profit"][$this_language_key]?> 
                                    <br>
                                    <span class="gray">(~240 <?=$languages_text["working_days"][$this_language_key]?>)</span>
                                </p>
                                <p>
                                    <b>
                                        <?=$languages_text["total_amount"][$this_language_key]?>: 
                                        <span id="totalNumberRub">380 000</span> руб.
                                    </b>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="calc dollar">
                        <div id="sliderCalcDollar" class="theme"></div>
                        <div class="calc-tabs">
                            <div></div>
                            <div><span>4 000</span></div>
                            <div></div>
                            <div><span>8 000</span></div>
                            <div></div>
                            <div><span>12 000</span></div>
                            <div></div>
                            <div><span>16 000</span></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="row info">
                            <div class="col-md-6">
                                <p>
                                    <?=$languages_text["daily_charge"][$this_language_key]?> 
                                    <br>
                                    <span class="gray">(<?=$languages_text["on_working_days"][$this_language_key]?>):</span>
                                </p>
                                <p>
                                    <b>
                                        <?=$languages_text["charge_amount"][$this_language_key]?>: 
                                        <span id="numberDollar">36</span> $
                                    </b>
                                </p>
                            </div>
                            <div class="offset-md-1 col-md-5">
                                <p>
                                    <?=$languages_text["total_profit"][$this_language_key]?> 
                                    <br>
                                    <span class="gray">(~240 <?=$languages_text["working_days"][$this_language_key]?>)</span>
                                </p>
                                <p>
                                    <b>
                                        <?=$languages_text["total_amount"][$this_language_key]?>: 
                                        <span id="totalNumberDollar">8 650</span> $
                                    </b>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="calc bitcoin">
                        <div id="sliderCalcBitcoin" class="theme"></div>
                        <div class="calc-tabs">
                            <div></div>
                            <div><span>0.400</span></div>
                            <div></div>
                            <div><span>0.780</span></div>
                            <div></div>
                            <div><span>1.170</span></div>
                            <div></div>
                            <div><span>1.550</span></div>
                            <div></div>
                            <div></div>
                        </div>
                        <div class="row info">
                            <div class="col-md-6">
                                <p>
                                    <?=$languages_text["daily_charge"][$this_language_key]?> 
                                    <br>
                                    <span class="gray">(<?=$languages_text["on_working_days"][$this_language_key]?>):</span>
                                </p>
                                <p>
                                    <b>
                                        <?=$languages_text["charge_amount"][$this_language_key]?>: 
                                        <span id="numberBitcoin">0.002765</span> ₿
                                    </b>
                                </p>
                            </div>
                            <div class="offset-md-1 col-md-5">
                                <p>
                                    <?=$languages_text["total_profit"][$this_language_key]?> 
                                    <br>
                                    <span class="gray">(~240 <?=$languages_text["working_days"][$this_language_key]?>)</span>
                                </p>
                                <p>
                                    <b>
                                        <?=$languages_text["total_amount"][$this_language_key]?>:  
                                        <span id="totalNumberBitcoin">0.663600</span> ₿
                                    </b>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>