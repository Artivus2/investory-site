<?php

class comInvest {

    public $act = null;
    public $view = null;
    public $id = null;
    public $model = null;
    public $content = null;
    public $content_head = null;
    public $title = null;

    function __construct($get) {
        $this->act = $get['act'];
        $this->view = $get['view'];
        $this->id = $get['id'];
        global $url_data;
        if (isset($this->act)) {
            switch ($this->act) {
                case "add_deposit":
                    require_once ( COM_PATH . "/invest/deposits/model.php" );
                    comInvest_modelDeposits::add_deposit();
                    Controller::redirect("/deposits#form");
                    break;
                case "accrual":
                    require_once ( COM_PATH . "/invest/deposits/model.php" );
                    comInvest_modelDeposits::accrual();
                    break;
            }
        }
        if (isset($this->view)) {
            switch ($this->view) {
                case "plans":

                    require_once ( COM_PATH . "/invest/plans/control.php" );
                    $this->content = comInvest_controlPlans::display();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "deposits":

                    require_once ( COM_PATH . "/invest/deposits/control.php" );
                    $this->content = comInvest_controlDeposits::display();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "deposits_history":

                    require_once ( COM_PATH . "/invest/deposits/control.php" );
                    $this->content = comInvest_controlDeposits::display_history();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "referals":

                    require_once ( COM_PATH . "/invest/referals/control.php" );
                    $this->content = comInvest_controlReferals::display();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
                case "referals_history":

                    require_once ( COM_PATH . "/invest/referals/control.php" );
                    $this->content = comInvest_controlReferals::display_history();

                    $this->keywords = $url_data["keywords"];
                    $this->description = $url_data["description"];

                    break;
            }
        }
    }

}
