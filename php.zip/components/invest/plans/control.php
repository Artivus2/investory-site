<?php

class comInvest_controlPlans {

    function display() {
        $return = "";
        require_once ( COM_PATH . "/invest/plans/model.php" );

        $plans = comInvest_modelPlans::plans_list($data);
       
        ob_start();
        require_once ( COM_PATH . "/invest/plans/view.php" );
        $return .= ob_get_clean();

     
        return $return;
    }

}
