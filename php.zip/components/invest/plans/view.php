<? foreach ($plans as $plan) :?>
<div>
    <h4> <?=$plan["name"]?> (<?=$plan["currency"]?>)</h4>
    <p>
        <strong>Минимум</strong>
        <?=$plan["min"]?>
    </p>
    <p>
        <strong>Максимум</strong>
        <?=$plan["max"]?>
    </p>
    <p>
        <strong>Процнт начислений</strong>
        <?=$plan["percent"]?>
    </p>
</div>
<a href="">Выбрать</a>
<hr />
<? endforeach; ?>
