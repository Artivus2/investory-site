<?php

class comInvest_modelPlans {

    function plan($id){
       return DB::select("SELECT * FROM `plans` WHERE `id` = '$id' LIMIT 1");
    }
    
    function plans_list($data = array()) {
        return DB::select("SELECT * FROM `plans` ", "all");
    }

}
