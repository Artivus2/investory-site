<?= $greeting_block ?>
<?= $purses_block ?>
<div class="row">
    <div class="col-sm-12">
        <div class="table_block">
            <h3><?= $languages_text["table_title"][$this_language_key] ?></h3>
            <? if (!empty($list["moneys"])): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th><?= $languages_text["table_col_1"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_2"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_3"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_4"][$this_language_key] ?></th>
                            <th><?= $languages_text["table_col_5"][$this_language_key] ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <? foreach ($list["moneys"] as $money): ?>
                            <tr>
                                <td data-label="<?= $languages_text["table_col_1"][$this_language_key] ?>"><?= $money["id"] ?></td>
                                <td data-label="<?= $languages_text["table_col_2"][$this_language_key] ?>">
                                    <?= date::dateFormatView(["datetime" => $money["date_created"]]); ?>
                                </td>
                                <td data-label="<?= $languages_text["table_col_3"][$this_language_key] ?>">
                                    <?= data::currency_rounding($money["referal_summa"], $money["currency"], true) ?>
                                </td>
                                <td data-label="<?= $languages_text["table_col_4"][$this_language_key] ?>">
                                    <?= $money["referal_login"] ?>
                                </td>
                                <td data-label="<?= $languages_text["table_col_5"][$this_language_key] ?>">
                                    <?= data::currency_rounding($money["deposit_summa"], $money["currency"], true) ?>
                                </td>
                            </tr>
                        <? endforeach; ?>
                    </tbody>
                </table>
                <?= $pagination ?>
            <? else: ?>
                <div class="alert alert-warning">
                    История пополнений пуста
                </div>
            <? endif; ?>
        </div>
    </div>
</div>
