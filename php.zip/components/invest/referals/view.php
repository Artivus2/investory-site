<?= $greeting_block ?>
<?= $purses_block ?>
<?= $referal_link ?>

<div class="row">
    <div class="col-sm-12 referal_statistics">
        <h3><?= $languages_text["referals_title"][$this_language_key] ?></h3>

        <ul>
            <li>
                <h4><?= $languages_text["referals_click"][$this_language_key] ?></h4>
                <span class="count"> <?= (int)$_SESSION["user"]["referal_follow_link"] ?> </span>
            </li>
            <li>
                <h4><?= $languages_text["referals_total"][$this_language_key] ?></h4>
                <span class="count"> <?= (int) $referals["count"] ?> (<?= (int) $referals["count_deposit"] ?>) </span>
            </li>
            <li>
                <h4><?= sprintf($languages_text["referals_count"][$this_language_key], 1) ?></h4>
                <span class="count"> <?= count($referals["list"]["level_1"]) ?> </span>
            </li>
            <li>
                <h4><?= sprintf($languages_text["referals_count"][$this_language_key], 2) ?></h4>
                <span class="count"> <?= count($referals["list"]["level_2"]) ?> </span>
            </li>
            <li>
                <h4><?= sprintf($languages_text["referals_count"][$this_language_key], 3) ?></h4>
                <span class="count"> <?= count($referals["list"]["level_3"]) ?> </span>
            </li>
            <li>
                <h4><?= sprintf($languages_text["referals_count"][$this_language_key], 4) ?></h4>
                <span class="count"> <?= count($referals["list"]["level_4"]) ?> </span>
            </li>
            <li>
                <h4><?= sprintf($languages_text["referals_count"][$this_language_key], 5) ?></h4>
                <span class="count"> <?= count($referals["list"]["level_5"]) ?> </span>
            </li>
        </ul>
    </div>
</div>


<div class="row">
    <div class="col-sm-12">
        <div class="table_block table_scroll">
            <table class="table">
                <thead>
                    <tr>
                        <th>
                            <i class="fa fa-user-friends"></i>
                        </th>
                        <th><?= $languages_text["table_col_1"][$this_language_key] ?></th>
                        <th><?= $languages_text["table_col_2"][$this_language_key] ?></th>
                        <th><?= $languages_text["table_col_3"][$this_language_key] ?></th>
                        <th><?= $languages_text["table_col_4"][$this_language_key] ?></th>
                    </tr>
                </thead>
                <tbody>
                    <? foreach ($referals["users"] as $referal): ?>
                        <tr>
                            <td data-level="<?= $referal["level"] ?>">
                                Ур.<?= $referal["level"] ?>
                            </td>
                            <td data-label="<?= $languages_text["table_col_1"][$this_language_key] ?>">
                                <?= $referal["id"] ?>
                            </td>
                            <td data-label="<?= $languages_text["table_col_2"][$this_language_key] ?>">
                                <?= $referal["login"] ?>
                            </td>
                            <td data-label="<?= $languages_text["table_col_3"][$this_language_key] ?>">
                                <?= date::dateFormatView(["datetime" => $referal["date_registration"]]); ?>
                            </td>
                            <td data-label="<?= $languages_text["table_col_4"][$this_language_key] ?>">
                                <span class="font-success">
                                    <?=data::currency_rounding($referal["deposits_rub"], "RUB", true);?>
                                    /
                                    <?=data::currency_rounding($referal["deposits_usd"], "USD", true);?>
                                    /
                                    <?=data::currency_rounding($referal["deposits_btc"], "BTC", true);?>
                                </span>
                            </td>
                        </tr> 
                    <? endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>
</div>