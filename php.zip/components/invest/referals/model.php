<?php

class comInvest_modelReferals {

    function views() {
        $result = DB::select("SELECT COUNT(rw.`id`) AS `count` FROM `referal_views` rw WHERE rw.`user` = '{$_SESSION["user"]["id"]}'", 'row');
        return $result["count"];
    }

    function referals() {
        $return[] = ["levels" => [], "list" => [], "deposits" => [], "all" => [], "tree" => []];
        $referals_users = [];
        $users_id[] = $_SESSION["user"]["id"];
        $referal_levels = DB::select("SELECT * FROM `referal_levels` ", 'all');
        $return["levels"] = $referal_levels;
        for ($n = 0; $n <= (count($referal_levels) + 1); $n++) {
            $lvl = $n + 1;
            $users_referal = DB::select("SELECT u.*,
                    IF( (SELECT COUNT(d.`id`) FROM`deposits` d WHERE d.`user` = u.id) > 0, 1, 0) AS `is_deposit`, 
                    (SELECT SUM(d.`summa`) FROM`deposits` d WHERE d.`user` = u.id AND d.currency = 'RUB') AS `deposits_rub` , 
                    (SELECT SUM(d.`summa`) FROM`deposits` d WHERE d.`user` = u.id AND d.currency = 'USD') AS `deposits_dol` , 
                    (SELECT SUM(d.`summa`) FROM`deposits` d WHERE d.`user` = u.id AND d.currency = 'BTC') AS `deposits_btc` 
                    FROM `users` u WHERE u.`referrer` IN (" . implode(",", $users_id) . ")", "all");
            if (empty($users_referal)) {
                break;
            }

            $users_id = [];
            foreach ((array) $users_referal as $user_referal) {
                $user_referal["level"] = $lvl;
                $return["list"]["level_" . $lvl][] = $user_referal;
                if ($user_referal["is_deposit"] == 1) {
                    $return["deposits"]["level_" . $lvl][] = $user_referal;
                }
                $return["all"][$user_referal["id"]] = $user_referal;

                $return["tree"][$user_referal["referrer"]][$user_referal["id"]] = $user_referal;
                $referals_users[] = $user_referal["id"];
                $users_id[] = $user_referal["id"];
            }
        }

        $tree = [];
        foreach ((array)$return["tree"][$_SESSION["user"]["id"]] as $referer_1 => $user_1) {
            $tree[] = $user_1;
            $return["count"]++;
            if($user_1["is_deposit"]){
                $return["count_deposit"]++;
            }
            foreach ((array) $return["tree"][$referer_1] as $referer_2 => $user_2) {
                $tree[] = $user_2;
                $return["count"]++;
                if($user_2["is_deposit"]){
                    $return["count_deposit"]++;
                }
                foreach ((array) $return["tree"][$referer_2] as $referer_3 => $user_3) {
                    $tree[] = $user_3;
                    $return["count"]++;
                    if($user_3["is_deposit"]){
                        $return["count_deposit"]++;
                    }
                    foreach ((array) $return["tree"][$referer_3] as $referer_4 => $user_4) {
                        $tree[] = $user_4;
                        $return["count"]++;
                        if($user_4["is_deposit"]){
                            $return["count_deposit"]++;
                        }
                        foreach ((array) $return["tree"][$referer_4] as $referer_5 => $user_5) {
                            $tree[] = $user_5;
                            $return["count"]++;
                            if($user_5["is_deposit"]){
                                $return["count_deposit"]++;
                            }
                        }
                    }
                }
            }
        }

        $return["users"] = $tree;
        return $return;
    }

    function mapTree($dataset) {
        $tree = array(); // Создаем новый массив
        /*
          Проходим в цикле по массиву $dataset, который был передан в качестве аргумента.
          в $id будет попадать уникальный id комментария,
          &$node -  работаем со значением по ссылке!
         */
        foreach ($dataset as $id => &$node) {
            if (!$node['referrer']) { // не имеет родителя
                $tree[$id] = &$node;
            } else {
                /*
                  Иначе это чей-то потомок
                  этого потомка переносим в родительский элемент,
                  при этом у родителя внутри элемента создастся массив childs, в котором и будут вложены его потомки
                 */
                $dataset[$node['referrer']]['childs'][$id] = &$node; //
            }
        }

        return $tree;
    }
    
    
    function referals_money($data = array()){  
        if (isset($data["limit"])) {
            $page = (int) isset($data['page']) ? $data['page'] : $_GET['page'];
            $start = (!empty($page)) ? ($page - 1) * $data["limit"] : 0;
            $limit = " LIMIT $start, " . $data["limit"];
        }
        
        $return["moneys"] = DB::select("SELECT SQL_CALC_FOUND_ROWS rm.*, u.`login` AS `referal_login`
                               FROM `referal_money` rm 
                               LEFT JOIN `users` u ON u.`id` = rm.`user_id`
                               WHERE rm.`referal_id` = '{$_SESSION["user"]["id"]}' ORDER BY rm.id DESC $limit", "all");
        $return["count"] = DB::select("SELECT FOUND_ROWS() cnt", "row")["cnt"];                   
                          
       return $return;
    }

}
