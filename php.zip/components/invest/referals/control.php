<?php

class comInvest_controlReferals {

    function display() {
        $return = "";
        require_once ( COM_PATH . "/invest/referals/model.php" );
        
        $views = comInvest_modelReferals::views();
        
        $referals = comInvest_modelReferals::referals();
        
  
        
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();
        
        require_once ( COM_PATH . "/common/referal_link/control.php" );
        $referal_link = comCommon_controlReferallink::display();
        

        $this_language_key = language::lang();

        $languages_text["referals_title"]["ru"] = "Таблица рефельной активности";
        $languages_text["referals_title"]["en"] = "Refel Activity Table";

        $languages_text["referals_click"]["ru"] = "Количество переходов по партнерской ссылке";
        $languages_text["referals_click"]["en"] = "Number of clicks on affiliate link";

        $languages_text["referals_total"]["ru"] = "Общее количество партнеров (с инвестициями)";
        $languages_text["referals_total"]["en"] = "Total number of partners (with investments)";

        $languages_text["referals_count"]["ru"] = "Количество партнеров %s линии";
        $languages_text["referals_count"]["en"] = "Number of partners %s line";
        
        
        $languages_text["table_col_1"]["ru"] = "ID";
        $languages_text["table_col_1"]["en"] = "ID";
        
        $languages_text["table_col_2"]["ru"] = "Логин";
        $languages_text["table_col_2"]["en"] = "Login";

        $languages_text["table_col_3"]["ru"] = "Дата регистрации";
        $languages_text["table_col_3"]["en"] = "Registration date";
        
        $languages_text["table_col_4"]["ru"] = "Сумма инвестиций";
        $languages_text["table_col_4"]["en"] = "Amount of investment";
        
        
        ob_start();
        require_once ( COM_PATH . "/invest/referals/view.php" );
        $return .= ob_get_clean();

     
        return $return;
    }
    
    
    function display_history() {
        $return = "";
        require_once ( COM_PATH . "/invest/referals/model.php" );
        
        $limit = 10;
        $list = comInvest_modelReferals::referals_money(["limit"=>$limit]);
        
        require_once (COM_PATH . "/pagination/pagination.php" );
        $pagination = Pagination::view($list["count"], $limit);
        
  
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();
  


        $this_language_key = language::lang();

        $languages_text["table_title"]["ru"] = "История реферальных начислений";
        $languages_text["table_title"]["en"] = "History of referral charges";

        
        $languages_text["table_col_1"]["ru"] = "ID";
        $languages_text["table_col_1"]["en"] = "ID";
        
        $languages_text["table_col_2"]["ru"] = "Дата";
        $languages_text["table_col_2"]["en"] = "Date";

        $languages_text["table_col_3"]["ru"] = "Сумма";
        $languages_text["table_col_3"]["en"] = "Amount";
        
        $languages_text["table_col_4"]["ru"] = "Логин";
        $languages_text["table_col_4"]["en"] = "Login";
        
        $languages_text["table_col_5"]["ru"] = "Сумма депозита";
        $languages_text["table_col_5"]["en"] = "Deposit amount";
        
        
        
        ob_start();
        require_once ( COM_PATH . "/invest/referals/view_history.php" );
        $return .= ob_get_clean();

     
        return $return;
    }
    

}
