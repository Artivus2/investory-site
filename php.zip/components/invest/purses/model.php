<?php

class comInvest_modelPurses {
    
    function check_purses($user_id = 0) {
        if(empty($user_id)){
            $user_id = $_SESSION["user"]['id'];
        }
        $all_currency_keys = array_keys(data::currency());
        foreach ($all_currency_keys as $currency) {
            $purse = DB::select("SELECT * FROM `user_purse` WHERE `user`='$user_id' AND `currency` = '$currency'", 'row');
            if(empty($purse)){
                DB::insert("INSERT INTO `user_purse` ?set", ["user"=>$user_id, "currency"=>$currency, "date_update"=>date("Y-m-d H:i:s")]);
            }
        }
    }
    
    function purse($currency, $user = 0) {
        if(empty($user)){
            $user = $_SESSION["user"]['id'];
        }
        $purse = DB::select("SELECT * FROM `user_purse` WHERE `user`='$user' AND `currency`='$currency'", 'row');
        $purse["value_rounding"] = data::currency_rounding($purse["value"], $purse["currency"]);
        return $purse;
    }

    function purses() {
        $purses = DB::select("SELECT * FROM `user_purse` WHERE `user`='{$_SESSION["user"]['id']}'", 'all');
        foreach ($purses as $key => $purse) {
            $purses[$key]["value_rounding"] = data::currency_rounding($purse["value"], $purse["currency"]);
        }
        return $purses;
    }


}
