<? foreach ($purses as $purse) : ?>
    <span>
        <strong><?= $purse["currency"] ?></strong>
        <?= $purse["value_rounding"];?>
    </span>
<? endforeach; ?>
