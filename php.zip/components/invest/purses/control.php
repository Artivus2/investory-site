<?php

class comInvest_controlPurses {

    function display() {
        $return = "";
        require_once ( COM_PATH . "/invest/purses/model.php" );

        $purses = comInvest_modelPurses::purses();
    
        ob_start();
        require_once ( COM_PATH . "/invest/purses/view.php" );
        $return .= ob_get_clean();

     
        return $return;
    }

}
