<?php

class comUser {

    public $act = null;
    public $view = null;
    public $id = null;
    public $model = null;
    public $content = null;

    function __construct($get) {
        $this->act = $get['act'];
        $this->view = $get['view'];
        $this->id = $get['id'];
        $this->type = $get['type'];


        if (isset($this->act)) {
            switch ($this->act) {
                case "login":
                    require_once (COM_PATH . "/user/login/model.php" );
                    return comUser_modelLogin::login();
                    break;
                case "restore_password":
                    require_once (COM_PATH . "/user/login/model.php" );
                    $return = comUser_modelLogin::restore_password();
                    Controller::redirect();
                    break;
                case "login_check":
                    require_once (COM_PATH . "/user/login/model.php" );
                    $return = comUser_modelLogin::login_check($_POST['email'], $_POST['password']);
                    if ($get['ajax'] == 1) {
                        echo json_encode($return);
                        exit;
                    }
                    return $return;
                    break;
                case "registration_check":
                    require_once (COM_PATH . "/user/registration/model.php" );
                    $return = comUser_modelRegistration::registration_check();
                    if ($get['ajax'] == 1) {
                        echo json_encode($return);
                        exit;
                    }
                    return $return;
                    break;
                case "registration_phone_new_kod":
                    require_once ( COM_PATH . "/user/registration/control.php" );
                    require_once (COM_PATH . "/user/registration/model.php" );
                    $return = comUser_modelRegistration::registration_phone_new_kod();
                    echo comUser_controlRegistration::display_modal(["step" => 2, "data" => $return["data"]]);
                    exit;
                    break;
                case "registration":
                    require_once (COM_PATH . "/user/registration/model.php" );
                    return comUser_modelRegistration::registration_save();
                    break;
                case "avatar_save":
                    require_once (COM_PATH . "/user/user/model.php" );
                    comUser_modelUser::avatar_save();
                    Controller::redirect();
                    exit;
                    break;
                case "avatar_delete":
                    require_once (COM_PATH . "/user/user/model.php" );
                    comUser_modelUser::avatar_delete();
                    Controller::redirect();
                    exit;
                    break;
                case "save":
                    require_once (COM_PATH . "/user/user/model.php" );
                    $return = comUser_modelUser::save_user();
                    if ($get['ajax'] == 1) {
                        echo json_encode($return);
                        exit;
                    }
                    return $return;
                    break;
                case "change_password":
                    require_once (COM_PATH . "/user/user/model.php" );
                    $return = comUser_modelUser::change_password();
                    if ($get['ajax'] == 1) {
                        echo json_encode($return);
                        exit;
                    } else {
                        controller::redirect();
                    }
                    break;
                case "change_password_modal":
                    require_once (COM_PATH . "/user/user/model.php" );
                    $return = comUser_modelUser::change_password();
                    if ($return["result"] == 1) {
                        $this->content = "1";
                    } else {
                        require_once ( COM_PATH . "/user/user/control.php" );
                        $this->content = comUser_controlUser::display_change_password_modal();
                    }
                    break;
                case "save_contact":
                    require_once (COM_PATH . "/user/user/model.php" );
                    $return = comUser_modelUser::save_contact();
                    if ($get['ajax'] == 1) {
                        echo json_encode($return);
                        exit;
                    }
                    return $return;
                    break;
                case "logout":
                    require_once (COM_PATH . "/user/login/model.php" );
                    return comUser_modelLogin::logout();
                    break;
                case 'confirm':
                    require_once (COM_PATH . "/user/registration/model.php" );
                    comUser_modelRegistration::confirm();
                    break;
                case "subscribe":
                    require_once (COM_PATH . "/user/subscribe/model.php" );
                    $return = comUser_modelSubscribe::subscribe_save();
                    return json_encode($return);
                    break;
                case "referal_session":
                    require_once (COM_PATH . "/user/user/model.php" );
                    comUser_modelUser::referal_session();
                    break;
                case "save_payment_details":
                    require_once (COM_PATH . "/user/user/model.php" );
                    comUser_modelUser::save_payment_details();
                    controller::redirect();
                    break;
            }
        }

        if (isset($this->view)) {
            switch ($this->view) {
                case "user":
                    require_once ( COM_PATH . "/user/user/control.php" );
                    $this->content = comUser_controlUser::display($get);
//                    $this->footer_script = comUser_controlUser::footer_script();
                    // $this->head_css = comUser_controlUser::head_css();
                    break;

                case "login":
                    require_once ( COM_PATH . "/user/login/control.php" );
                    $this->content = comUser_controlLogin::display();
                    break;
                case "change_password_modal":
                    require_once ( COM_PATH . "/user/user/control.php" );
                    $this->content = comUser_controlUser::display_change_password_modal();
                    break;
                case "restore_password":
                    require_once ( COM_PATH . "/user/login/control.php" );
                    $this->content = comUser_controlLogin::display_password();
                    break;
                case "registration":
                    require_once ( COM_PATH . "/user/registration/control.php" );
                    $this->content = comUser_controlRegistration::display();
                    break;
                case "registration_confirm":
                    require_once ( COM_PATH . "/user/registration/control.php" );
                    $this->content = comUser_controlRegistration::display_confirm();
                    break;
            }
        }
    }

}
