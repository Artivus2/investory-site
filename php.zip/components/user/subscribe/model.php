<?php

class comUser_modelSubscribe {

    function subscribe_check() {
        $email = trim(strip_tags($_POST["email"]));
               $return["result"] = 1;
        if (empty($email)) {
            $return["result"] = 0;
            $return["error"] = "Поле не должно быть пустым";
        } elseif (!preg_match("|^[a-z0-9_\.-]+@[-0-9a-z_^\.]+\.[a-z]{2,8}$|i", $email)) {
            $return["result"] = 0;
            $return["error"] = "E-mail введен не правильно";
        } else {
            $user_email = DB::select("SELECT * FROM `subscriptions` WHERE `email`='$email' LIMIT 1", 'row');
            if (!empty($user_email)) {
                $return["result"] = 0;
                $return["error"] = "Вы уже подписанны на рассылку новостей";
            }
        }
        
        return $return;
    }

    function subscribe_save() {
        $email = trim(strip_tags($_POST["email"]));

        $check = self::subscribe_check();
        if ($check['result'] == 1) {
            $this_date = date('Y-m-d H:i:s');
            $data["email"] = $email;
            $data["date_created"] = $this_date;
            $data["ip"] = Controller::userIP();
            DB::insert("INSERT INTO `subscriptions` ?set", $data);
            $return["result"] = 1;
            $return["error"] = "Спасибо за подписку";
            return $return;
        } else {
            return $check;
        }
    }

}
