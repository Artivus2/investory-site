    <section class="section-63 bg-downriver">
        <div class="shell">
            <div class="range">

                <div class="cell-sm-8 cell-sm-preffix-2 cell-md-6 cell-md-preffix-3">
                    <p class="txt-white">Раздел не доступен. Идет сбор и обработка базы компаний.</p>
                    <p class="txt-white">Оставьте свой E-mail и мы оповестим Вас о запуске этого раздела</p>
                    <form class="rd-mailform offset-top-35 subscribe-form text-center subscribe-form-mod-1" action="/subscribe" method="post" data-form-type="subscribe" data-form-output="form-output-global" novalidate="novalidate">
                        <div class="form-group">
                            <label class="form-label rd-input-label" for="contact-email2">E-mail</label>
                            <input id="contact-email2" class="form-control form-control-has-validation form-control-last-child" type="email" data-constraints="@Required @Email" name="email">
                            <span class="form-validation"></span>
                        </div>
                        <button class="btn btn-sm btn-primary btn-icon btn-icon-left btn-shadow btn-rect offset-top-15 offset-lg-top-0" type="submit">
                            <span class="icon icon-md mdi-email-outline"></span>
                            <span> Подписаться</span>
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </section>