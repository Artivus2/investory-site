<?php
class comUser_controlSubscribe {
    function display() {
        ob_start();
        require_once ( COM_PATH . "/user/subscribe/view.php" );
    }

}
