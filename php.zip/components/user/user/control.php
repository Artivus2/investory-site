<?php

class comUser_controlUser {

    function display($get) {
      
        require_once (COM_PATH . "/user/user/model.php" );

        $user = comUser_modelUser::user_data($_SESSION["user"]["id"]);
        $payment_details = comUser_modelUser::payment_details();
                
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting_block = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses_block = comCommon_controlPurses::display();
        
        
        $this_language_key = language::lang();

        $languages_text["avatar_delete"]["ru"] = "Удалить фотографию";
        $languages_text["avatar_delete"]["en"] = "Delete photo";

        $languages_text["avatar_select"]["ru"] = "Выберите файл";
        $languages_text["avatar_select"]["en"] = "select a file";

        $languages_text["avatar_download"]["ru"] = "Загрузить";
        $languages_text["avatar_download"]["en"] = "Download";

        $languages_text["avatar_none_fail"]["ru"] = "Файл не выбран";
        $languages_text["avatar_none_fail"]["en"] = "No file selected";

        $languages_text["setting_title"]["ru"] = "Настройки";
        $languages_text["setting_title"]["en"] = "Settings";

        $languages_text["setting_name"]["ru"] = "ФИО";
        $languages_text["setting_name"]["en"] = "Full name";

        $languages_text["setting_phone"]["ru"] = "Номер телефона";
        $languages_text["setting_phone"]["en"] = "Phone number";

        $languages_text["setting_email"]["ru"] = "E-mail";
        $languages_text["setting_email"]["en"] = "E-mail";

        $languages_text["setting_save"]["ru"] = "Сохранить";
        $languages_text["setting_save"]["en"] = "Save";

        $languages_text["password_title"]["ru"] = "Пароль";
        $languages_text["password_title"]["en"] = "Password";

        $languages_text["password_password_1"]["ru"] = "Пароль";
        $languages_text["password_password_1"]["en"] = "Password";

        $languages_text["password_password_2"]["ru"] = "Еще раз";
        $languages_text["password_password_2"]["en"] = "Again";

        $languages_text["password_save"]["ru"] = "Сохранить";
        $languages_text["password_save"]["en"] = "Save";

        $languages_text["payment_title"]["ru"] = "Платежные реквизиты";
        $languages_text["payment_title"]["en"] = "Payment Details";

        $languages_text["payment_save"]["ru"] = "Сохранить";
        $languages_text["payment_save"]["en"] = "Save";
        
        
        ob_start();
        require_once ( COM_PATH . "/user/user/view.php" );
        return ob_get_clean();
    }

}
