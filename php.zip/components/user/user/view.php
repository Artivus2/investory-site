<?= $greeting_block ?>
<?= $purses_block ?>

<div class="row">
    <div class="col-sm-12">
        <div class="form_block">
            <form method="post" action="/user/load_avatar"  enctype="multipart/form-data" >
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="user_avatar">
                            <img src="<?=$_SESSION["user"]["avatar_dir"]?>">
                            <?if($_SESSION["user"]["avatar"]):?>
                                <br />
                                <a href="/user/delete_avatar"><?= $languages_text["avatar_delete"][$this_language_key] ?></a>
                            <?endif;?>
                        </div>
                    </div>
                    <div class="col-md-9 col-sm-6 col-xs-12 new_user_avatar">
                        <div class="control-group">
                            <label class="label input_file">
                                <span class="btn__grey"><?= $languages_text["avatar_select"][$this_language_key] ?></span>
                                <span class="file_name"><?= $languages_text["avatar_none_fail"][$this_language_key] ?></span>
                                <input type="file" name="avatar">
                            </label>
                        </div>
                        <div class="control-group">
                        <button type="submit" class="btn__green"><?= $languages_text["avatar_download"][$this_language_key] ?></button>
                    </div>
                    </div>
                </div>
                <?= message::msg("user_avatar") ?>

            </form>
        </div>
    </div>
</div>



<div class="row">
    <div class="col-sm-12">
        <div class="form_block">
            <h3><?= $languages_text["setting_title"][$this_language_key] ?></h3>
            <form method="post" action="/user/save" >
                <div class="row">
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["setting_name"][$this_language_key] ?></label>
                            <input type="text" value="<?= $user["name"] ?>" name="name">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["setting_phone"][$this_language_key] ?></label>
                            <input type="text" value="<?= Controller::phoneFormatBack($user["phone"]) ?>" name="phone">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["setting_email"][$this_language_key] ?></label>
                            <input type="text" value="<?= $user["email"] ?>" name="email" readonly disabled>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-8 col-sm-6 col-xs-12 form_help">
                        <?= message::msg("user") ?>
                    </div>
                    <div class="col-md-4 col-sm-6 col-xs-12 text-right">
                        <button type="submit" class="btn__green"><?= $languages_text["setting_save"][$this_language_key] ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="row">
    <div class="col-sm-12">
        <div class="form_block">
            <h3><?= $languages_text["password_title"][$this_language_key] ?></h3>
            <form method="post" action="/user/change_password" >
                <?= message::msg("password") ?>
                <input type="password" style="display: none;">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["password_password_1"][$this_language_key] ?></label>
                            <input value="" name="password1" type="password">
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="control-group">
                            <label class="control-label"><?= $languages_text["password_password_2"][$this_language_key] ?></label>
                            <input value="" name="password2" type="password">
                        </div>
                    </div>
                    <div class="col-sm-4 text-right">
                        <button type="submit" class="btn__green"><?= $languages_text["password_save"][$this_language_key] ?></button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 form_help">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="form_block">
            <h3><?= $languages_text["payment_title"][$this_language_key] ?></h3>
            <form method="post" action="/user/save_payment_details" >
                <div class="row">
                    <? foreach ($payment_details as $payment_detail): ?>
                        <div class="col-sm-6">
                            <div class="control-group">
                               
                                <label class="control-label"><?= data::payment_details($payment_detail["type"]) ?></label>
                                <input type="text" name="<?= $payment_detail["type"] ?>" value="<?= $payment_detail["value"] ?>">
                            </div>
                        </div>
                    <? endforeach; ?>
                    <div class="col-sm-6 text-right">
                        <button type="submit" class="btn__green"><?= $languages_text["payment_save"][$this_language_key] ?></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>