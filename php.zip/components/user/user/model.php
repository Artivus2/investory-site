<?php

class comUser_modelUser {

    function user_data($user_id = null) {
        if (empty($user_id)) {
            $user_id = $_SESSION['user']['id'];
        }
        $sql = "SELECT * FROM `users` WHERE `id`='$user_id'";
        return DB::select($sql);
    }

    function save_user() {
        $return["result"] = 1;
        $user_id = $_SESSION['user']['id'];
        $data["name"] = trim(strip_tags($_POST["name"]));
        $data["phone"] = controller::phoneformat($_POST["phone"]);

        if (empty($data["name"])) {
            $return["result"] = 0;
            $return["text"] = "[:ru]Введите Ваши Ф.И.О[:en]Enter your full name[:]";
        }
        if ($return["result"] == 1) {
            //  $data["surname"] = trim(strip_tags($_POST["surname"]));
            //$data["time_zone"] = trim(strip_tags($_POST["time_zone"]));
            if ($_SESSION['user']['email'] == "") {
                //  $data["email"] = trim(strip_tags($_POST["email"]));
            }
            DB::update("UPDATE `users` SET ?set WHERE `id`='$user_id'", $data);
            $return["text"] = "[:ru]Изменения сохранены[:en]Changes saved[:]";
        }
        message::new_msg("user", ($return["result"] == 1) ? "success" : "danger", $return["text"]);

        Controller::telegram("Изменены данные пользователя: " . $_SESSION['user']["login"]);
        Controller::redirect();
    }

    function change_password() {
        $return["result"] = 1;
        $user_id = $_SESSION["user"]["id"];

        $password = trim($_POST["password1"]);
        $password2 = trim($_POST["password2"]);

        if (!empty($password)) {
            if (strlen($password) < 6) {
                $return["result"] = 0;
                $return["text"] = "[:ru]Длина пароля должна быть не меньше 6-и символов[:en]Password must be at least 6 characters long[:]";
            } elseif ($password != $password2) {
                $return["result"] = 0;
                $return["text"] = "[:ru]Пароли не совпадают[:en]Passwords do not match[:]";
            } else {
                $insert_passwrd = controller::hashpassword($password);
                $data["password"] = $insert_passwrd;
            }
        } else {
            $return["result"] = 0;
            $return["text"] = "[:ru]Введите желаемый пароль[:en]Enter the desired password[:]";
        }

        if ($return["result"] == 1) {
            $return_update = DB::update("UPDATE `users` SET ?set WHERE `id`='$user_id'", $data);
            if ($return_update == false) {
                $return["result"] = 0;
                $return["text"] = "[:ru]Не удалось сохранить, по техническим причинам[:en]Failed to save due to technical reasons[:]";
            } else {
                $return["text"] = "[:ru]Изменения сохранены[:en]Changes saved[:]";
                DB::update("UPDATE `users` SET ?set WHERE `id`='$user_id'", ["change_password" => 0]);
            }
        }
        message::new_msg("password", ($return["result"] == 1) ? "success" : "danger", $return["text"]);
        return $return;
    }

    function user_contacts($user_id) {
        if (empty($user_id)) {
            $user_id = $_SESSION['user']['id'];
        }
        return DB::select("SELECT * FROM `users_contacts` uc WHERE uc.`user` = '$user_id' AND uc.`status` = '1'", "all");
    }

    function save_contact() {
        $return["result"] = 1;
        $user_id = $_SESSION["user"]["id"];
        $contacts = $_POST["data"]["contact"];
        $list_contacts_no_delete = [];
        foreach ((array) $contacts as $contact) {
            if ($contact["type"] == "phone") {
                $contact["value"] = controller::phoneformat(trim(strip_tags($contact["value"])));
            }
            if (!empty($contact["value"]) && !empty($contact["value"])) {
                $is_contact = DB::select("SELECT * FROM `users_contacts` uc WHERE uc.`user` = '$user_id' AND uc.`type` = '{$contact["type"]}' AND uc.`value` = '{$contact["value"]}' AND uc.`status` = '1' LIMIT 1", "row");
                if (empty($is_contact)) {
                    $new_contact = DB::insert("INSERT INTO `users_contacts` ?set", ["user" => $user_id, "type" => $contact["type"], "value" => $contact["value"], "date_created" => date("Y-m-d H:i:s")]);
                    $list_contacts_no_delete[] = $new_contact["id"];
                } else {
                    $list_contacts_no_delete[] = $is_contact["id"];
                }
            }
        }

        if (!empty($list_contacts_no_delete)) {
            $delete_contacts = DB::select("SELECT * FROM `users_contacts` uc WHERE uc.`user` = '$user_id' AND uc.`status` = '1' AND uc.`id` NOT IN (" . implode(", ", $list_contacts_no_delete) . ")", "all");
        } else {
            $delete_contacts = DB::select("SELECT * FROM `users_contacts` uc WHERE uc.`user` = '$user_id' AND uc.`status` = '1' ", "all");
        }
        foreach ((array) $delete_contacts as $delete_contact) {
            DB::update("UPDATE `users_contacts` SET ?set WHERE `id`='{$delete_contact["id"]}'", ["status" => 0]);
        }

        message::new_msg("contacts", ($return["result"] == 1) ? "success" : "danger", "[:ru]Изменения сохранены[:en]Changes saved[:]");
        controller::redirect();
    }

    function referal_session() {
        if (!empty($_SESSION["user"])) {
            return false;
        }
        $ref = trim(htmlspecialchars(strip_tags($_GET["ref"]), ENT_QUOTES, ""));
        if (empty($ref)) {
            return false;
        }
        $actual_ref = true;
        
        $ip = Controller::userIP();
        $os = Controller::getOS();
        $hash = md5($ip . $os . $ref);
        if (!empty($_COOKIE['referal']) && $_COOKIE['referal'] == $ref) {
            //Проверяtv hash
            if ($hash != $_COOKIE['referal_hash']) {
                $actual_ref = false;
            }
        } else {
            $actual_ref = false;
        }
        
        if (!$actual_ref) {
            //Записываем в историю и создаемм сессию
            $user_referal = DB::select("SELECT u.* FROM `users` u WHERE u.`login` = '$ref' LIMIT 1", "row");
            if (empty($user_referal)) {
                return false;
            }
            setcookie("referal", $ref, time() + 2592000, "/");
            setcookie("referal_hash", $hash, time() + 2592000, "/");
            DB::insert("INSERT INTO `referal_views` ?set", ["referal" => $ref, "user" => $user_referal["id"], "date_created" => date("Y-m-d H:i:s"), "hash" => $hash]);
        }
    }

    function payment_details() {
        return DB::select("SELECT * FROM `user_payment_details` WHERE `user`='{$_SESSION["user"]['id']}'", 'all');
    }

    function save_payment_details() {

        foreach ($_POST as $type => $payment_detail) {
            $type = trim(strip_tags($type));
            $payment_detail = trim(strip_tags($payment_detail));

            $payment_detail_data = DB::select("SELECT * FROM `user_payment_details` WHERE `user`='{$_SESSION["user"]["id"]}' AND `type` = '$type'", 'row');

            if (empty($payment_detail_data)) {
                return false;
            }

            $data_update = [];
            $data_update["value"] = $payment_detail;
            if ($payment_detail_data["value"] != $payment_detail) {
                $data_update["date_update"] = date("Y-m-d H:i:s");
            }
            DB::update("UPDATE `user_payment_details` SET ?set WHERE `user`='{$_SESSION["user"]["id"]}' AND `type` = '$type'", $data_update);
        }
    }

    function avatar_save() {
        
        if (!empty($_FILES['avatar']['tmp_name'])) {
            //Загружаем аватарку
            if (!in_array($_FILES['avatar']['type'], ["image/jpeg", "image/png", "image/gif"])) {
                message::new_msg("user_avatar", "danger", "[:ru]Некорректный формат файла. Разрешается использовать .JPG, .PNG, .GIF[:en]Invalid file format. Allowed to use .JPG, .PNG, .GIF[:]");
                return false;
            }
            if ($_FILES['avatar']['size'] > 10485760) {
                message::new_msg("user_avatar", "danger", "[:ru]Сильно большой размер файла. Используйте файлы до 10мб[:en]Very large file size. Use files up to 10mb[:]");
                return false;
            }

            $upload_dir = "images/avatars/";
            $name_file = md5(time() . $_SESSION["user"]["id"] . controller::translitText($_FILES['avatar']["name"]));
            $name_file .= ".".file::getExtension($_FILES['avatar']["name"]);

            file::resize($_FILES['avatar'], $upload_dir, $name_file, '100', null, 100);

            DB::update("UPDATE `users` SET ?set WHERE `id`='{$_SESSION["user"]["id"]}'", array("avatar" => $name_file));
        } else {
            message::new_msg("user_avatar", "danger", "[:ru]Выберите загружаемый файл[:en]Select download file[:]");
            return false;
        }
    }

    function avatar_delete() {
        if(!empty($_SESSION["user"]["avatar"])){
            DB::update("UPDATE `users` SET ?set WHERE `id`='{$_SESSION["user"]["id"]}'", array("avatar" => ""));
        }
      
    }

}
