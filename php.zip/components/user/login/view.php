<section class="auth-reg auth-bord">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8">
                <div class="wrapper_form">
                    <form method="POST" action="login/do">
                        <h3><?=$languages_text["title"][$this_language_key]?></h3>
                        <div class="form-group">
                            <label for="login" class="label"><?=$languages_text["label_login"][$this_language_key]?></label>
                            <input type="text" class="form-control input" name="login" id="login" required="" autocomplete="off" value="<?= (string) $form_data["login"] ?>">
                        </div>
                        <div class="form-group">
                            <label for="password2" class="label"><?=$languages_text["label_password"][$this_language_key]?></label>
                            <input type="password" class="form-control input" name="password" id="password2" required="" autocomplete="off" >
                        </div>
                        <p class="group group-between">
                            <span><a href="/restore_password"><?=$languages_text["restore_password"][$this_language_key]?></a></span>
                            <span><span><?=$languages_text["no_account"][$this_language_key]?></span> <a href="/registration"><?=$languages_text["sign_up"][$this_language_key]?></a></span>
                        </p>
                        <?= message::msg("login"); ?>
                        <input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response" />
                        <button type="submit" class="btn__green"><?=$languages_text["come_in"][$this_language_key]?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>