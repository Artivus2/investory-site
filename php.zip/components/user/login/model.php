<?php

class comUser_modelLogin {

    function login_check($login, $password) {

//        if(empty($email) && !empty($_POST["phone"])){
//            $email = Controller::phoneformat(trim(strip_tags($_POST["phone"])));
//        }
        $captcha = controller::getCaptcha($_POST['g-recaptcha-response']);
        if($captcha->success == false && $captcha->score < 0.5){
            return array('result' => 0, 'text' => "[:ru]Сайт защищен от роботов через reCaptcha[:en]The site is protected from robots through reCaptcha[:]");
        }

        $password = trim($password);
        if ($login == "") {
            self::insertlogin_log($login, 5);
            return array('result' => 0, 'text' => "[:ru]Введите Логин или E-mail[:en]Enter your username or email[:]", 'data' => 'email');
        } elseif ($password == "") {
            self::insertlogin_log($login, 5);
            return array('result' => 0, 'text' => '[:ru]Поле "Пароль" пустое[:en]Password field is empty[:]', 'data' => 'password');
        }

        $passwordhash = controller::as_md5($password);

        $type = "login";
        if(stristr($login, '@')){
            $type = "email";
        }
        
        if ($type == "email" && !preg_match("|^[-0-9a-z_\.]+@[-0-9a-z_^\.]+\.[a-z]{2,6}$|i", $login)) {
            return array('result' => 0, 'text' => "[:ru]E-mail введен не корректно[:en]Email entered incorrectly[:]", 'data' => 'email');
        }

        $user = DB::select("SELECT * FROM `users` WHERE `login` = '$login' OR `email` = '$login' LIMIT 1", 'row');

        if (empty($_COOKIE['PHPSESSID'])) {
            self::insertlogin_log($login, 9);
            return array('result' => 0, 'text' => '[:ru]Непонятная ошибка[:en]Incomprehensible error[:]');
        }

        if (empty($user)) {
            self::insertlogin_log($login, 4);
            return array('result' => 0, 'text' => '[:ru]Пользователь не зарегистрирован[:en]User not registered[:]', 'data' => 'phone');
        } elseif ($passwordhash != $user["password"]) {
            self::insertlogin_log($login, 4);
            return array('result' => 0, 'text' => "[:ru]Пароль не подходит[:en]The password is incorrect[:]", 'data' => 'password');
//        } elseif ($user['email_confirm'] == 0) {
//            self::insertlogin_log($login, 3);
//            return array('result' => 0, 'text' => 'Эта учетная запись еще не активированна, проверьте свой e-mail', 'data' => 'email');
        } elseif ($user['lock'] == 1) {
            self::insertlogin_log($login, 3);
            return array('result' => 0, 'text' => '[:ru]Эта учетная запись заблокирована[:en]This account is locked[:]', 'data' => 'email');
        } else {
            return array('result' => 1);
        }
    }

    function login() {
        $login = $_POST["login"];
        $password = trim($_POST['password']);
        $check = self::login_check($login, $password);

        if ($check['result'] == 1) {
            $user = DB::select("SELECT * FROM `users` WHERE `login`='$login' OR `email`='$login' LIMIT 1", 'row');
            self::login_end($user["id"]);
            Controller::redirect("/lk");
        } else {
            $_SESSION["form_data"] = $_POST;
            message::new_msg("login", "danger", $check['text']);
            Controller::redirect("/login");
        }
    }

    function login_end($user) {
        if (!is_array($user)) {
            //если $user не массив значть id пользователя
            $user = DB::select("SELECT * FROM `users` WHERE `id`='$user' LIMIT 1", 'row');
        }

        $sess_data = self::new_session_hash($user["id"]);
        DB::update("UPDATE `users` SET ?set WHERE `id`='{$user["id"]}'", array("date_active" => date("Y-m-d H:i:s"), 'hash' => $sess_data["hash"]));
        //Проверяем наличие кошельков
        require_once ( COM_PATH . "/invest/purses/model.php" );
        comInvest_modelPurses::check_purses($user["id"]);
        self::check_payment_details($user["id"]);

        Controller::telegram("Вход: " . $user["login"]);
    }

    function new_session_hash($user_id) {
        if (empty($user_id))
            return false;
        do {
            $hash = md5($user_id . $type . controller::generateNumer(10) . '-' . time());
            $is_hash = DB::select("SELECT * FROM `users_session` WHERE `hash`='$hash' LIMIT 1");
        } while (!empty($is_hash));

        DB::delete("DELETE FROM `users_session` WHERE `user`='$user_id'");
        $session_id_ret = DB::insert("INSERT INTO `users_session` ?set", array('user' => $user_id, "hash" => $hash));
        $session_id = $session_id_ret['id'];

        setcookie("session_id", $session_id, time() + 604800, "/"); //неделя
        setcookie("session_hash", $hash, time() + 604800, "/");   //неделя


        return array("hash" => $hash, "session_id" => $session_id);
    }

    function insertlogin_log($login, $result) {
        global $DB;
        $data["login"] = (string) $login;
        $data["ip"] = controller::userIP();
        $data["browser"] = $_SERVER["HTTP_USER_AGENT"];
        $data["os"] = controller::getOS();
        $data["result"] = $result;
        $data["dateLogin"] = date('Y-m-d H:i:s');
        $sql_date = "INSERT INTO `login_log` ?set";
        DB::insert($sql_date, $data);
    }

    function logout() {
        unset($_SESSION['user']);

        setcookie("session_id", "", time() - 604800, "/");
        setcookie("session_hash", "", time() - 604800, "/");
        Controller::redirect("/");
    }

    function restore_password() {
        $captcha = controller::getCaptcha($_POST['g-recaptcha-response']);
        if($captcha->success == false && $captcha->score < 0.5){
            return array('result' => 0, 'text' => "[:ru]Сайт защищен от роботов через reCaptcha[:en]The site is protected from robots through reCaptcha[:]");
        }
        
        $email = trim(strip_tags($_POST["email"]));        
        
        if (empty($email)) {
            message::new_msg("restore_password", "danger", "[:ru]Введите E-mail[:en]Enter Email[:]");
            return false;
        } elseif (!preg_match("|^[a-z0-9_\.-]+@[-0-9a-z_^\.]+\.[a-z]{2,8}$|i", $email)) {
            message::new_msg("restore_password", "danger", "[:ru]E-mail введен не корректно[:en]Email entered incorrectly[:]");
            return false;
        } 
        
        $user = DB::select("SELECT * FROM `users` WHERE `email`='$email' LIMIT 1", 'row');
        if (empty($user)) {
            message::new_msg("restore_password", "danger", "[:ru]Этот E-mail не найден[:en]This Email Not Found[:]");
            return false;
        }

        
        $password = Controller::generateNumer(10);
        $password_md5 = Controller::as_md5($password);
        if(language::lang() == "en"){
            $title = 'Password recovery at www.fxartinvest.com';
            $mail_message_text .= "<p>Hello</p>";
            $mail_message_text .= "</br>";
            $mail_message_text .= "<p>your new password: <strong>$password</strong></p>";
            $mail_message_text .= "</br>";
            $mail_message_text .= "</br>";
            $mail_message_text .= "<p>Sincerely, FXArtInvest platform administration</p>";
        }else{
            $title = 'Восстановление пароля на www.fxartinvest.com';
            $mail_message_text .= "<p>Здравствуйте</p>";
            $mail_message_text .= "</br>";
            $mail_message_text .= "<p>Ваш новый пароль: <strong>$password</strong></p>";
            $mail_message_text .= "</br>";
            $mail_message_text .= "</br>";
            $mail_message_text .= "<p>С Уважением, администрация платформы FXArtInvest</p>";
        }
        
        controller::send_mail(["email"=>$user['email'], "title"=>$title, "text"=>$mail_message_text]);

        DB::update("UPDATE `users` SET ?set WHERE `id`='{$user['id']}' LIMIT 1", array("password" => $password_md5));
      
        Controller::telegram("Восстановление пароля. Логин: {$user['login']}");
        message::new_msg("restore_password", "success", "[:ru]Новый пароль отправлен на Ваш E-mail. <a href='/login'>Войти</a>[:en]A new password has been sent to your E-mail. <a href='/login'> Login </a>[:]");
        return $return;
    }
    
    function check_payment_details($user_id = 0) {
        if(empty($user_id)){
            $user_id = $_SESSION["user"]['id'];
        }
        $all_payment_details_keys = array_keys(data::payment_details());
        foreach ($all_payment_details_keys as $payment_detail) {
            $check_payment_detail = DB::select("SELECT * FROM `user_payment_details` WHERE `user`='$user_id' AND `type` = '$payment_detail'", 'row');
            if(empty($check_payment_detail)){
                DB::insert("INSERT INTO `user_payment_details` ?set", ["user"=>$user_id, "type"=>$payment_detail, "date_update"=>date("Y-m-d H:i:s")]);
            }
        }
    }
    

}
