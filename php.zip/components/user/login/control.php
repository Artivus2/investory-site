<?php

class comUser_controlLogin {

    function display($data = array()) {
        global $url_data;
        if (empty($_SESSION['user'])) {
            $form_data = $_SESSION["form_data"];
            unset($_SESSION["form_data"]);
            
            
            $this_language_key = language::lang();

            $languages_text = [];
            $languages_text["title"]["ru"] = "Вход";
            $languages_text["title"]["en"] = "Entrance";
            
            $languages_text["label_login"]["ru"] = "Логин или E-mail";
            $languages_text["label_login"]["en"] = "Login or Email";
            
            $languages_text["label_password"]["ru"] = "Пароль";
            $languages_text["label_password"]["en"] = "Password";
            
            $languages_text["restore_password"]["ru"] = "Забыли пароль?";
            $languages_text["restore_password"]["en"] = "Forgot your password";
            
            $languages_text["no_account"]["ru"] = "Нет аккаунта?";
            $languages_text["no_account"]["en"] = "No account?";
            
            $languages_text["sign_up"]["ru"] = "Зарегистрироваться";
            $languages_text["sign_up"]["en"] = "Sign up";
            
            $languages_text["come_in"]["ru"] = "Войти";
            $languages_text["come_in"]["en"] = "To come in";
                                    
            
            
            ob_start();
            require_once ( COM_PATH . "/user/login/view.php" );
            return ob_get_clean();
        } else {
            Controller::redirect('/');
        }
    }

    function display_password() {

            $this_language_key = language::lang();

            $languages_text = [];
            $languages_text["title"]["ru"] = "Восстановление пароля";
            $languages_text["title"]["en"] = "Password recovery";
            
            $languages_text["label_email"]["ru"] = "Ваш E-mail";
            $languages_text["label_email"]["en"] = "Your email";
            
            $languages_text["sign_up"]["ru"] = "Зарегистрироваться";
            $languages_text["sign_up"]["en"] = "Sign up";
            
            $languages_text["remember_password"]["ru"] = "Вспомнили пароль?";
            $languages_text["remember_password"]["en"] = "Remember your password?";
            
            $languages_text["come_in"]["ru"] = "Войти";
            $languages_text["come_in"]["en"] = "To come in";
            
            $languages_text["restore"]["ru"] = "Восстановить";
            $languages_text["restore"]["en"] = "Restore";
            
            
        ob_start();
        require_once ( COM_PATH . "/user/login/view_password.php" );
        return ob_get_clean();
    }

}
