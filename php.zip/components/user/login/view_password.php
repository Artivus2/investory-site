<section class="auth-reg auth-bord">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8">
                <div class="wrapper_form">
                    <form method="POST" action="restore_password/do">
                        <h3><?=$languages_text["title"][$this_language_key]?></h3>
                        <?if(message::is_msg("restore_password", "success")):?>
                            <?= message::msg("restore_password"); ?>
                        <?else:?>
                            <div class="form-group">
                                <label for="email" class="label"><?=$languages_text["label_email"][$this_language_key]?></label>
                                <input type="text" class="form-control input" name="email" id="email" required="" autocomplete="off" value="<?= (string) $form_data["login"] ?>">
                            </div>
                            <p class="group group-between">
                                <span><a href="/registration"><?=$languages_text["sign_up"][$this_language_key]?></a></span>
                                <span><span><?=$languages_text["remember_password"][$this_language_key]?></span> <a href="/login"><?=$languages_text["come_in"][$this_language_key]?></a></span>
                            </p>
                            <?= message::msg("restore_password"); ?>
                            <input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response" />
                            <button type="submit" class="btn__green"><?=$languages_text["restore"][$this_language_key]?></button>
                        <?endif;?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>