<?php

class comUser_controlRegistration {

    function display($data = array()) {
        global $url_data;
        // $data = $url_data["data"];

        require_once (COM_PATH . "/user/registration/model.php" );

        $form_data = $_SESSION["form_data"];
        unset($_SESSION["form_data"]);
        
        if (empty($_SESSION['user'])) {
            ob_start();
            require_once ( COM_PATH . "/user/registration/view.php" );
            return ob_get_clean();
        } else {
            Controller::redirect('/');
        }
    }

    function display_confirm() {
        global $url_data;
        require_once (COM_PATH . "/user/registration/model.php" );
        $result = comUser_modelRegistration::confirm();

        ob_start();
        require_once ( COM_PATH . "/user/registration/view_confirm.php" );
        return ob_get_clean();
    }

}
