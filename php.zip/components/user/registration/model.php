<?php

class comUser_modelRegistration {


    function registration_check($data) {

        if (empty($data["post"])) {
            $login = trim(strip_tags($_POST["login"]));
            $email = trim(strip_tags($_POST["email"]));
            $password = trim($_POST["password1"]);
            $password2 = trim($_POST["password2"]);
        } else {
            $login = trim(strip_tags($data["post"]["login"]));
            $email = trim(strip_tags($data["post"]["email"]));
            $password1 = trim($data["post"]["password1"]);
            $password2 = trim($data["post"]["password2"]);
        }

        $captcha = controller::getCaptcha($_POST['g-recaptcha-response']);
        if($captcha->success == false && $captcha->score < 0.5){
            return array('result' => 0, 'text' => "[:ru]Сайт защищен от роботов через reCaptcha[:en]The site is protected from robots through reCaptcha[:]");
        } 

        $return["result"] = 1;
        if (empty($login)) {
            $return["result"] = 0;
            $return["error_list"]["login"] = "[:ru]Поле не должно быть пустым[:en]The field must not be empty[:]";
        }elseif (preg_match("|[а-яА-Я]|i", $login)) {
            $return["result"] = 0;
            $return["error_list"]["login"] = "[:ru]В логине не должно быть кириллических символов[:en]Login must not contain Cyrillic characters[:]";
        }elseif (!preg_match("|^[a-zA-Z]{1,}|i", $login)) {
            $return["result"] = 0;
            $return["error_list"]["login"] = "[:ru]Логин должен начинаться с букв[:en]Login must begin with letters[:]";
        } else {
            $user_login = DB::select("SELECT * FROM `users` WHERE `login`='$login' LIMIT 1", 'row');
            if (!empty($user_email)) {
                $return["result"] = 0;
                $return["error_list"]["login"] = "[:ru]Такой логин уже зарегистрирован[:en]This login is already registered[:]";
            }
        }

        if (empty($email)) {
            $return["result"] = 0;
            $return["error_list"]["email"] = "[:ru]Поле не должно быть пустым[:en]The field must not be empty[:]";
        } elseif (!preg_match("|^[a-z0-9_\.-]+@[-0-9a-z_^\.]+\.[a-z]{2,8}$|i", $email)) {
            $return["result"] = 0;
            $return["error_list"]["email"] = "[:ru]E-mail введен не правильно[:en]Email entered incorrectly[:]";
        } else {
            $user_email = DB::select("SELECT * FROM `users` WHERE `email`='$email' LIMIT 1", 'row');
            if (!empty($user_email)) {
                $return["result"] = 0;
                $return["error_list"]["email"] = "[:ru]Такой E-mail уже зарегистрирован[:en]This email is already registered[:]";
            }
        }


        if (empty($password1)) {
            $return["result"] = 0;
            $return["error_list"]["password1"] = "[:ru]Пароль не должен быть пустым[:en]Password must not be blank[:]";
        } elseif (strlen($password1) < 6) {
            $return["result"] = 0;
            $return["error_list"]["password1"] = "[:ru]Длина пароля должна быть не меньше 6-и символов[:en]Password must be at least 6 characters long[:]";
        } elseif ($password1 != $password2) {
            $return["result"] = 0;
            $return["error_list"]["password2"] = "[:ru]Пароли не совпадают[:en]Passwords do not match[:]";
        }

        return $return;
    }

    function registration_save() {
        $login = trim(strip_tags($_POST["login"]));
        $email = trim(strip_tags($_POST["email"]));
        $password1 = trim($_POST["password1"]);
        $password2 = trim($_POST["password2"]);
        /*
        
        require_once ( COM_PATH . "/user/invite/model.php" );
        $invite_hash = trim(strip_tags($_POST["invite"]));
        if (!empty($invite_hash)) {
            $invite = comUser_modelInvite::invite($invite_hash);
            if (!empty($invite["email"])) {
                $email = $invite["email"];
            }
        }*/
        $check = self::registration_check(["post" => ["login" => $login, "email" => $email, "password1" => $password1, "password2" => $password2]]);
       
        if ($check['result'] == 1) {

            $insert_passwrd = controller::as_md5($password1);
            $this_date = date('Y-m-d H:i:s');


            $data["login"] = $login;
            $data["email"] = $email;
            $data["password"] = $insert_passwrd;
            $data["date_registration"] = $this_date;
            $data["hash"] = md5($this_date . $login . 'email');
            $data["email_confirm"] = (int) 0;
            
            $check_referal = self::check_referal();
            if(!empty($check_referal)){
                $data["referrer"] = (int) $check_referal["user"];
            }

            $new_user = DB::insert("INSERT INTO `users` ?set", $data);
//            require_once (COM_PATH . "/user/login/model.php" );
//            comUser_modelLogin::login_end($new_user["id"]);

            if ($data['email'] != "") {
                $link_confirm = URL."/registration/confirmation?login={$data["login"]}&hash={$data["hash"]}";
                if(language::lang() == "en"){
                    $title = 'Registration at www.fxartinvest.com';
                    $mail_message_text .= "<p>Hello, Congratulations on your successful registration on our site. <a href='".URL."' target='_blank'>".URL."</a> </p>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "<p>your login: <strong>{$data['login']}</strong></p>";
                    $mail_message_text .= "<p>your password: <strong>{$password1}</strong></p>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "<p>To activate your account, follow the links: <a href='$link_confirm' target='_blank'>$link_confirm</a></p>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "<p>Sincerely, FXArtInvest platform administration</p>";
                }else{
                    $title = 'Регистрация на www.fxartinvest.com';
                    $mail_message_text .= "<p>Здравствуйте, Поздравляем Вас с успешной регистрацией на нашем сайте <a href='".URL."' target='_blank'>".URL."</a> </p>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "<p>Ваш логин: <strong>{$data['login']}</strong></p>";
                    $mail_message_text .= "<p>Ваш пароль: <strong>{$password1}</strong></p>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "<p>Для активации аккаунта перейдите по ссылкеы: <a href='$link_confirm' target='_blank'>$link_confirm</a></p>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "</br>";
                    $mail_message_text .= "<p>С Уважением, администрация платформы FXArtInvest</p>";
                }
                controller::send_mail(["email"=>$data['email'], "title"=>$title, "text"=>$mail_message_text]);
            }
            
            if(!empty($check_referal)){
                DB::update("UPDATE `referal_views` SET ?set WHERE `id`='{$check_referal["id"]}' LIMIT 1", ["registration"=>1, "date_registration"=>$this_date]);
                setcookie("referal", "", time() - 2592000, "/");
                setcookie("referal_hash", "", time() - 2592000, "/");
            }
            message::new_msg("registration", "success", "[:ru]Регистрация прошла успешно. На ваш почтовый ящик было отправлено письмо с инструкцией[:en]Registration completed successfully. An instruction letter was sent to your inbox[:]");
            Controller::telegram("Регистрация. Логин: {$data['login']}, Реферал: {$check_referal["referal"]}");
        } else {
            $_SESSION["form_data"] = $_POST;
            foreach ($check["error_list"] as $key => $error) {
                message::new_msg("registration_$key", "danger", $error);
            }
        }
        controller::redirect();
    }


    function confirm() {
        $login = trim(strip_tags($_GET['login']));
        $hash = trim(strip_tags($_GET['hash']));
        if (empty($login) || empty($hash)) {
            message::new_msg("email_confirm", "danger", "[:ru]Параметры подтверждении регистрации не найдены[:en]Registration confirmation parameters not found[:]");
            return false;
        }

        $user = DB::select("SELECT * FROM `users` WHERE `login`='$login'  AND `hash`='$hash' LIMIT 1", 'row');
      
        if (empty($user)) {
            message::new_msg("email_confirm", "danger", "[:ru]Учетная запись не найдена[:en]Account not found[:]");
            return false;
        }elseif($user["email_confirm"] == 1){
            message::new_msg("email_confirm", "danger", "[:ru]Учетная запись уже активирована[:en]Account already activated[:]");
            return false;
        }
        
        DB::update("UPDATE `users` SET ?set WHERE `id`='{$user["id"]}' LIMIT 1", ["email_confirm"=>1]);
        return true;
    }
    
    function user_ref_kod($kod){
        return DB::select("SELECT * FROM `users` u WHERE u.`partner_kod` = '$kod' LIMIT 1 ");
    }
    
    
    function check_referal(){
        if(empty($_COOKIE['referal'])){
            return false;
        }
        
        //Проверяtv hash
        $ip = Controller::userIP();
        $os = Controller::getOS();
        $hash = md5($ip.$os.$_COOKIE['referal']);
        
        if($hash != $_COOKIE['referal_hash']){
            return false;
        }
        
        
        $referal_data =  DB::select("SELECT rw.* FROM `referal_views` rw WHERE  rw.`referal` = '{$_COOKIE['referal']}' AND rw.`hash` = '{$_COOKIE['referal_hash']}' LIMIT 1", "row");
        
        if(empty($referal_data)){
            return false;
        }
        
        return $referal_data;
    }
}
