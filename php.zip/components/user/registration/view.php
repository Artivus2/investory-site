<section class="auth-reg">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8">
                <div class="wrapper_form">
                    <form role="form" action="/registration/do" method="POST">
                        <h3>Регистрация</h3>

                        <div class="hide" style="display: none;">
                            <input type="text" name="t_email" />
                            <input type="password" name="t_password" />
                        </div>
                        <div class="form-group">
                            <label for="input_login" class="label">Ваше Логин</label>
                            <input type="text" name="login" placeholder="Введите Логин" id="input_login" class="form-control input" value="<?= (string) $form_data["login"] ?>">
                            <?= message::msg("registration_login", "<span class='input-error'>", "</span>"); ?>
                        </div>
                        <div class="form-group">
                            <label for="input_email" class="label">Ваш E-mail</label>
                            <input type="email" name="email" placeholder="Введите E-mail" id="input_email" class="form-control input" value="<?= (string) $form_data["email"] ?>">
                            <?= message::msg("registration_email", "<span class='input-error'>", "</span>"); ?>
                        </div>
                        <div class="form-group">
                            <label for="input_password1" class="label">Придумайте пароль</label>
                            <input type="password" name="password1" placeholder="Введите пароль" id="input_password1" class="form-control input" value="<?= (string) $form_data["password1"] ?>">
                            <?= message::msg("registration_password1", "<span class='input-error'>", "</span>"); ?>
                        </div>
                        <div class="form-group">
                            <label for="input_password2" class="label">Повторите пароль</label>
                            <input type="password" name="password2" placeholder="Введите пароль" id="input_password2" class="form-control input" value="<?= (string) $form_data["password2"] ?>">
                            <?= message::msg("registration_password2", "<span class='input-error'>", "</span>"); ?>
                        </div>
                        <p>Нажав кнопку "Подтвердить и продолжить", вы соглашаетесь с <a href="/uploads/usloviya.pdf" target="blank">условиями FXARTINVEST</a> и подтверждаете, что вам более 18 лет.</p>
                        <p class="group">
                            <span>
                                <span>Уже зарегистрированы?</span>
                                <a href="/login">Войти</a>
                            </span>
                        </p>
                        <?= message::msg("registration"); ?>
                        <input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response" />
                        <button type="submit" class="btn__green">Зарегистрироваться</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>