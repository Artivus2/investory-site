
<section class="auth-reg">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8">
                Вы успешно зарегистрировались. 
            </div>
        </div>
    </div>
</section>