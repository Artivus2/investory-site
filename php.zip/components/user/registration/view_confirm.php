<section class="auth-reg auth-bord">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8">
                <div class="wrapper_form">
                    <?= message::msg("email_confirm") ?>
                    <?if($result):?>
                        <h3 class="group">Учетная запись успешно активирована. <a href="/login">Войти</a></h3>
                    <?endif;?>
                </div>
            </div>
        </div>
    </div>
</section>