<?php

class modalBlock {
/*
$size = modal-lgx - 1000px, modal-lg - 900px, middle - 600px, mini - 430px
  */
    function view($data = []) {
       if(empty($data["content"])){
           $data["content"] = "Информацция для моделього окна не получена";
       }
       
        
        
        ob_start();
        require_once ( COM_PATH . "/modalBlock/view.php" );
        return ob_get_clean();
    }

}
