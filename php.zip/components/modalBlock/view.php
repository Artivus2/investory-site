<div class="modal-dialog <?= $data["size"] ?>">
    <div class="modal-content c-square modal-<?= $data["class"] ?>">

        <div class="modal-header">
            
            <h5 class="modal-title"><?= $data["title"] ?></h5>
            <button class="close" aria-hidden="true" data-dismiss="modal" type="button">×</button>
            
        </div>

        <div class="modal-body">
            <?= $data["content"] ?>    
        </div>

    </div>
</div>