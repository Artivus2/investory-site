
<?= $greeting ?>
<?= $purses ?>

<h3 class="analytics_title">
    <?=$languages_text["title"][$this_language_key]?>
</h3>

<div class="analytics_widget">


    <a href="https://www.myfxbook.com/statements/349314/statement.html"><img  border="0" src="https://widgets.myfxbook.com/widgets/349314/large.jpg"/></a>

    <!-- myfxbook.com top news widget - Start -->
    <div><script class="powered" type="text/javascript" src="https://widgets.myfxbook.com/scripts/fxTopNews.js"></script>
        <div style="color: #706f6f;font-weight: bold;font-size: 11px;font-family: Tahoma;">Powered by <a href="https://www.myfxbook.com"class="myfxbookLink" ><b style="color: #575454;">Myfxbook.com</b></a></div>
        <script type="text/javascript">showTopNewsWidget()</script></div>
    <!-- myfxbook.com top news widget - End -->
</div>