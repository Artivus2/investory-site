<?php

class comPages_controlAnalytics {

    static function display() {
        
        
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses = comCommon_controlPurses::display();
        
        $this_language_key = language::lang();
        
        $languages_text["title"]["ru"] = "Вы можете наблюдать за одним из торговых счетов FXARTINVEST онлайн";
        $languages_text["title"]["en"] = "You can watch one of FXARTINVEST trading accounts online.";
        
        ob_start();
        require_once ( COM_PATH . "/pages/analytics/view.php" );
        return ob_get_clean();
    }

}
