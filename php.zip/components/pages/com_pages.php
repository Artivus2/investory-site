<?php

class comPages {

    public $act = null;
    public $view = null;
    public $id = null;
    public $model = null;
    public $content = null;

    function __construct($get) {
        $this->act = (int) $get['act'];
        $this->view = $get['view'];
        $this->id = $get['id'];
        global $url_data;


        if (isset($this->act)) {
            switch ($this->act) {
                
            }
        }
        if (isset($this->view)) {
            switch ($this->view) {
                case "index":
                    require_once ( COM_PATH . "/pages/index/control.php" );
                    $this->content = comPages_controlIndex::display();
                    break;
                case "lk_index":
                    require_once ( COM_PATH . "/pages/lk_index/control.php" );
                    $this->content = comPages_controlLKIndex::display();
                    break;
                case "404":
                    require_once ( COM_PATH . "/pages/404/control.php" );
                    $this->content = comPages_control404::display();
                    break;
                case "about":
                    require_once ( COM_PATH . "/pages/about/control.php" );
                    $this->content = comPages_controlAbout::display();
                    $this->scripts = comPages_controlAbout::scripts();
                    break;
                case "feedbacks":
                    require_once ( COM_PATH . "/pages/feedbacks/control.php" );
                    $this->content = comPages_controlFeedbacks::display();
                    break;
                case "partners":
                    require_once ( COM_PATH . "/pages/partners/control.php" );
                    $this->content = comPages_controlPartners::display();
                    break;
                case "contacts":
                    require_once ( COM_PATH . "/pages/contacts/control.php" );
                    $this->content = comPages_controlContacts::display();
                    break;
                case "trade":
                    require_once ( COM_PATH . "/pages/trade/control.php" );
                    $this->content = comPages_controlTrade::display();
                    break;
                case "analytics":
                    require_once ( COM_PATH . "/pages/analytics/control.php" );
                    $this->content = comPages_controlAnalytics::display();
                    break;
                case "faq":
                    require_once ( COM_PATH . "/pages/faq/control.php" );
                    $this->content = comPages_controlFaq::display();
                    break;
                case "investment":
                    require_once ( COM_PATH . "/pages/investment/control.php" );
                    $this->content = comPages_controlInvestment::display();
                    break;
                case "partnership":
                    require_once ( COM_PATH . "/pages/partnership/control.php" );
                    $this->content = comPages_controlPartnership::display();
                    break;
                case "terms":
                    require_once ( COM_PATH . "/pages/terms/control.php" );
                    $this->content = comPages_controlTerms::display();
                    break;
            }
        }
    }

}
