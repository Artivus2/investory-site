<?php

class comPages_controlTrade {

    static function display() {
        
        
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses = comCommon_controlPurses::display();
        
        $this_language_key = language::lang();
        
        $languages_text["text"]["ru"] = "Вы желаете зарабатывать на Forex, но не хотите вникать в тонкости совершения торговых операций или просто не обладаете достаточным опытом для ведения прибыльной торговли. Мы предоставляем Вам возможность работать с опытным трейдером от платформы Fxartinvest, копируя его сделки на свой счёт. ";
        $languages_text["text"]["en"] = "You want to make money on Forex, but you don’t want to delve into the intricacies of performing trading operations or simply do not have enough experience to conduct profitable trading. We give you the opportunity to work with an experienced trader from the Fxartinvest platform, copying his transactions to your account.";
        
        
        $languages_text["more"]["ru"] = "подробнее...";
        $languages_text["more"]["en"] = "more details ...";
        
        ob_start();
        require_once ( COM_PATH . "/pages/trade/view.php" );
        return ob_get_clean();
    }

}
