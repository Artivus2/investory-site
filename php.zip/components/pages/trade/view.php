<?= $greeting ?>
<?= $purses ?>

<div class="trade_text">
    <?=$languages_text["text"][$this_language_key]?>
    <a href="https://www.copyfx.com/ru/client/investor/" target="blank"><?=$languages_text["more"][$this_language_key]?></a>
</div>

<div class="trade_widget">
    <iframe src="https://staticmy.roboforex.com/ru/informers/providers/frame/large/546143/" width="405" height="508" frameborder="0"></iframe>
</div>