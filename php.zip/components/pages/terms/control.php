<?php

class comPages_controlTerms {
    function display() {
        global $url_data;

        require_once ( COM_PATH . "/common/investing/control.php" );
        $investing_block = comCommon_controlInvesting::display();
        
        require_once ( COM_PATH . "/common/paysystem/control.php" );
        $paysystem_block = comCommon_controlPaysystem::display();
        
        $this_language_key = language::lang();
        
        $languages_text["page_title"]["ru"] = "Условия использования";
        $languages_text["page_title"]["en"] = "Terms of Use";
        
        $languages_text["text_1"]["ru"] = "Торговля инструментами - такими, как Forex, - сопряжена с высоким уровнем риска.";
        $languages_text["text_1"]["en"] = "Trading instruments - such as Forex - carries a high level of risk.";
        
        $languages_text["text_2"]["ru"] = "Не следует рисковать больше, чем вы можете позволить себе потерять - возможно, что вы потеряете больше суммы ваших инвестиций. Не следует начинать торговлю или инвестирование, если вы не до конца понимаете реальную степень убытков и риска, которым вы подвергаетесь.";
        $languages_text["text_2"]["en"] = "You should not risk more than you can afford to lose - it is possible that you lose more than the amount of your investment. You should not start trading or investing if you do not fully understand the real extent of the losses and risks to which you are exposed.";
        
        $languages_text["text_3"]["ru"] = "Торгуя или инвестируя, вы должны всегда принимать в расчёт уровень своего опыта.";
        $languages_text["text_3"]["en"] = "When trading or investing, you should always take into account the level of your experience.";
        
        $languages_text["text_4"]["ru"] = "Если степень возможного риска вам не до конца понятна, пожалуйста, обратитесь к независимому специалисту за дополнительной консультацией или в техническую поддержку нашей компании.";
        $languages_text["text_4"]["en"] = "If the degree of possible risk is not fully understood by you, please contact an independent specialist for additional advice or to the technical support of our company.";
        
        $languages_text["text_5"]["ru"] = "Клиент соглашается с тем, что торговля на рынке Форекс является одним из рискованных видов трейдинга на финансовых рынках, и такой деятельностью могут заниматься только физические или юридические лица с соответствующим уровнем финансовой подготовки.";
        $languages_text["text_5"]["en"] = "The client agrees that trading in the Forex market is one of the risky types of trading in the financial markets, and only individuals or legal entities with the appropriate level of financial training can engage in such activities.";
        
        $languages_text["text_6"]["ru"] = "Цены в маржинальной торговле являются высоковолатильными, и при максимальном уровне кредитного плеча весь баланс счета может быть потерян в случае, если цена актива изменится на 2%.";
        $languages_text["text_6"]["en"] = "Prices in margin trading are highly volatile, and at the maximum level of leverage, the entire balance of the account may be lost if the price of the asset changes by 2%.";
        
        $languages_text["text_7"]["ru"] = "Поскольку торговля на финансовых рынках может привести к полной потере капитала, Клиенту рекомендуется торговать только с помощью рискового капитала, т.е. капитала, потеря которого существенно не скажется на финансовом благополучии Клиента.";
        $languages_text["text_7"]["en"] = "Since trading in financial markets can lead to a complete loss of capital, it is recommended that the Client trade with risk capital only, i.e. capital, the loss of which will not significantly affect the financial well-being of the Client.";
        
        $languages_text["text_8"]["ru"] = "Клиенту необходимо подтвердить, что капитал, используемый им на Сайте, является исключительно рисковым, и его потеря никак не отразится на материальном положении Клиента в настоящем или будущем, в том числе и не коснется его пенсионной программы.";
        $languages_text["text_8"]["en"] = "The Client needs to confirm that the capital used by him on the Site is exclusively risky, and his loss will not affect the Client’s financial situation in the present or in the future, including his pension program.";
        
        $languages_text["text_9"]["ru"] = "Кроме того, подтверждая свое осознание рисков торговли на рынке Форекс, Клиент тем самым заявляет, что потеря его капитала не скажется на его возможности выплаты долговых обязательств другим физическим и юридическим лицам.";
        $languages_text["text_9"]["en"] = "In addition, confirming its awareness of the risks of trading in the Forex market, the Client thereby declares that the loss of his capital will not affect his ability to pay debt to other individuals and legal entities.";
        
        
        
        ob_start();
        require_once ( COM_PATH . "/pages/terms/view.php" );
        return ob_get_clean();
    }
}
