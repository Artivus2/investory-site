<div class="breadcrumb terms">
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 class="breadcrumb__title"><?=$languages_text["page_title"][$this_language_key]?></h2>
            </div>
        </div>
    </div>
</div>
<section class="contacts">
    <div class="container">
        <p><?=$languages_text["text_1"][$this_language_key]?></p>
        <br />
        <p><?=$languages_text["text_2"][$this_language_key]?></p>
        <br />
        <p><?=$languages_text["text_3"][$this_language_key]?></p>
        <p><?=$languages_text["text_4"][$this_language_key]?></p>
        <br />
        <p><?=$languages_text["text_5"][$this_language_key]?></p>
        <br />
        <p><?=$languages_text["text_6"][$this_language_key]?></p>
        <p><?=$languages_text["text_7"][$this_language_key]?></p>
        <br />
        <p><?=$languages_text["text_8"][$this_language_key]?></p>
        <br />
        <p><?=$languages_text["text_9"][$this_language_key]?></p>
    </div>
</section>

<?= $investing_block ?>
<?=
$paysystem_block?>