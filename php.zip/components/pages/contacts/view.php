<div class="breadcrumb contact">
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 class="breadcrumb__title"><?=$languages_text["page_title"][$this_language_key]?></h2>
                <p class="breadcrumb__text"><?=$languages_text["page_title_text"][$this_language_key]?></p>
            </div>
        </div>
    </div>
</div>
<section class="contacts">
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="item">
                    <img src="/templates/images/mail.png" alt="">
                    <div class="text">
                        <p><?=$languages_text["support"][$this_language_key]?>:</p>
                        <p><a href="mailto:support@fxartinvest.com">support@fxartinvest.com</a></p>
                    </div>
                    <div class="text">
                        <p><?=$languages_text["finance"][$this_language_key]?>:</p>
                        <p><a href="mailto:fin@fxartinvest.com">fin@fxartinvest.com</a></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="item">
                    <img src="/templates/images/phone-call.png" alt="">
                    <div class="text">
                        <p><?=$languages_text["phone"][$this_language_key]?></p>
                        <p><a class="phone" href="mailto:+442071939932"><b>+44 207 193 9932</b></a></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="item">
                    <img src="/templates/images/speech-bubble.png" alt="">
                    <div class="text">
                        <p><?=$languages_text["social"][$this_language_key]?></p>
                        <ul class="socials">
                            <li><a href="http://vk.com/fx_artinvest" target="blank"><i class="fab fa-vk"></i><div>Vkontakte</div></a></li>
                            <li><a href="http://t.me/fxartinvest" target="blank"><i class="fab fa-telegram-plane"></i><div>Telegram</div></a></li>
                            <li><a href="https://www.instagram.com/invites/contact/?i=37ox9vnld7md&utm_content=5184smj" target="blank"><i class="fab fa-instagram"></i><div>Instagram</div></a></li>
                            <li><a href="https://www.youtube.com/channel/UCMYNzC29rzpg_YL9jM01cRg" target="blank"><i class="fab fa-youtube"></i><div>YouTube</div></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?=$investing_block?>
<?=$paysystem_block?>