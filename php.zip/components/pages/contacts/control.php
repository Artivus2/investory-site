<?php

class comPages_controlContacts {
    function display() {
        global $url_data;

        require_once ( COM_PATH . "/common/investing/control.php" );
        $investing_block = comCommon_controlInvesting::display();
        
        require_once ( COM_PATH . "/common/paysystem/control.php" );
        $paysystem_block = comCommon_controlPaysystem::display();
        
        $this_language_key = language::lang();
        
        $languages_text["page_title"]["ru"] = "Наши контакты";
        $languages_text["page_title"]["en"] = "Our contacts";
        
        $languages_text["page_title_text"]["ru"] = "О том, что мы делаем, и почему мы выбрали деятельность на Форекс";
        $languages_text["page_title_text"]["en"] = "About what we do and why we chose Forex trading";
        
        $languages_text["support"]["ru"] = "По вопросам работы с сервисом обращаться в службу технической поддержки";
        $languages_text["support"]["en"] = "For questions about working with the service, contact the technical support service";
        
        $languages_text["finance"]["ru"] = "По финансовым вопросам обращаться в финансовую службу";
        $languages_text["finance"]["en"] = "For financial matters, contact the financial service";
        
        $languages_text["phone"]["ru"] = "Телефон";
        $languages_text["phone"]["en"] = "Phone";
        
        $languages_text["social"]["ru"] = "Мы в соцсетях";
        $languages_text["social"]["en"] = "We are in social networks";
        
        
        ob_start();
        require_once ( COM_PATH . "/pages/contacts/view.php" );
        return ob_get_clean();
    }
}
