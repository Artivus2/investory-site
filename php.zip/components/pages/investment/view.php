<div class="breadcrumb investing">
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 class="breadcrumb__title"><?=$languages_text["page_title"][$this_language_key]?></h2>
                <p class="breadcrumb__text"><?=$languages_text["page_title_text"][$this_language_key]?></p>
            </div>
        </div>
    </div>
</div>
<div class="investing__list">
    <div class="container">
        <div class="row">
            <div class="investing__item col-lg-11">
                <div class="investing__number col-lg-1">
                    <div class="circle">
                        <span>01</span>
                    </div>
                </div>
                <div class="investing__item-icon">
                    <img src="/templates/images/investing_icon_1.png" alt="<?=$languages_text["investing_title_1"][$this_language_key]?>">
                </div>

                <div class="investing__item-text">
                    <h4><?=$languages_text["investing_title_1"][$this_language_key]?></h4>
                    <p><?=$languages_text["investing_text_1"][$this_language_key]?></p>
                </div>
            </div>

            <div class="investing__item col-lg-11">
                <div class="investing__number col-lg-1">
                    <div class="circle">
                        <span>02</span>
                    </div>
                </div>
                <div class="investing__item-icon">
                    <img src="/templates/images/investing_icon_2.png" alt="<?=$languages_text["investing_title_2"][$this_language_key]?>">
                </div>

                <div class="investing__item-text">
                    <h4><?=$languages_text["investing_title_2"][$this_language_key]?></h4>
                    <p><?=$languages_text["investing_text_2"][$this_language_key]?></p>
                </div>
            </div>

            <div class="investing__item col-lg-11">
                <div class="investing__number col-lg-1">
                    <div class="circle">
                        <span>03</span>
                    </div>
                </div>

                <div class="investing__item-icon">
                    <img src="/templates/images/investing_icon_3.png" alt="<?=$languages_text["investing_title_3"][$this_language_key]?>">
                </div>

                <div class="investing__item-text">
                    <h4><?=$languages_text["investing_title_3"][$this_language_key]?></h4>
                    <p><?=$languages_text["investing_text_3"][$this_language_key]?></p>
                </div>
            </div>

            <div class="investing__item col-lg-11">
                <div class="investing__number col-lg-1">
                    <div class="circle">
                        <span>04</span>
                    </div>
                </div>

                <div class="investing__item-icon">
                    <img src="/templates/images/investing_icon_4.png" alt="<?=$languages_text["investing_title_4"][$this_language_key]?>">
                </div>

                <div class="investing__item-text">
                    <h4><?=$languages_text["investing_title_4"][$this_language_key]?></h4>
                    <p><?=$languages_text["investing_text_4"][$this_language_key]?></p>
                </div>
            </div>

            <div class="investing__item col-lg-11">
                <div class="investing__number col-lg-1">
                    <div class="circle">
                        <span>05</span>
                    </div>
                </div>

                <div class="investing__item-icon">
                    <img src="/templates/images/investing_icon_5.png" alt="<?=$languages_text["investing_title_5"][$this_language_key]?>">
                </div>

                <div class="investing__item-text">
                    <h4><?=$languages_text["investing_title_5"][$this_language_key]?></h4>
                    <p><?=$languages_text["investing_text_5"][$this_language_key]?></p>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="investing__plan">

    <div class="container">
        <div class="row">
            <?$t=0;?>
            <? foreach ($plans_group as $type => $plan_group): ?>
                <div class="investing__plan-item col-lg-12">
                    <div class="investing__plan-item-left col-lg-3">
                        <div class="investing__plan-icon">
                            <img src="/templates/images/daposit_plan_<?= $plan_group["type"] ?>.png" />
                        </div>
                        <h4><?= language::lang_text($plan_group["name"]) ?></h4>  
                    </div>
                    <div class="flip-containers <?if($t == 0) echo "hover"?>">
                        <div class="flippers">
                            <div class="fronts">
                                <div class="arrow">
                                    <i class="fal fa-long-arrow-right"></i>
                                </div>
                            </div>
                            <div class="backs">
                                <div class="investing__plan-item-right no-gutters">
                                    <? foreach ($plan_group["plans"] as $plan): ?>
                                    <div class="investing__text col-lg-4">
                                        <div class="left">
                                            <h5><?= $plan["percent"] ?></h5>
                                            <span><?=$languages_text["in_day"][$this_language_key]?></span>
                                            <p><?= data::currency_rounding($plan["min"], $plan["currency"], true, "icon", false) ?></p>
                                        </div>
                                        <div class="right">
                                            <h5><?= $plan["days"] ?></h5>
                                            <span><?=$languages_text["days"][$this_language_key]?></span>
                                            <p><?= data::currency_rounding($plan["max"], $plan["currency"], true, "icon", false) ?></p>
                                        </div>
                                    </div>
                                    <? endforeach;?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?$t++;?>
            <? endforeach; ?>


        </div>
    </div>
</div>


<?= $investing_block ?>
<?=
$paysystem_block?>