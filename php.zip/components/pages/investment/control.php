<?php

class comPages_controlInvestment {
    function display() {
        global $url_data;

        require_once ( COM_PATH . "/common/investing/control.php" );
        $investing_block = comCommon_controlInvesting::display();
        
        require_once ( COM_PATH . "/common/paysystem/control.php" );
        $paysystem_block = comCommon_controlPaysystem::display();
        
        require_once ( COM_PATH . "/invest/deposits/model.php" );
        $plans = comInvest_modelDeposits::plans();
        $plans_group = [];
        foreach ($plans as $plan) {            
            $plans_group[$plan["type"]]["type"] = $plan["type"];
            $plans_group[$plan["type"]]["name"] = $plan["name"];
            $plans_group[$plan["type"]]["plans"][] = $plan;
        }
        
        $this_language_key = language::lang();
        
        $languages_text["page_title"]["ru"] = "Инвестирование";
        $languages_text["page_title"]["en"] = "Investment";
        
        $languages_text["page_title_text"]["ru"] = "Как работает платформа FX ARTINVEST?";
        $languages_text["page_title_text"]["en"] = "How does the FX ARTINVEST platform work?";
        
        $languages_text["investing_title_1"]["ru"] = "Заработок инвесторов";
        $languages_text["investing_title_1"]["en"] = "Investor Earnings";
        
        $languages_text["investing_text_1"]["ru"] = "Пройдите простую процедуру регистрации на сайте. Для вашего удобства мы не требуем от вас личных данных для верификации - только краткая информация для персонализации пользователя в системе и связи с вами.";
        $languages_text["investing_text_1"]["en"] = "Follow the simple registration procedure on the site. For your convenience, we do not require personal data from you for verification - only brief information for personalizing the user in the system and communicating with you.";
        
        $languages_text["investing_title_2"]["ru"] = "Выбор тарифа";
        $languages_text["investing_title_2"]["en"] = "Tariff selection";
        
        $languages_text["investing_text_2"]["ru"] = "Внимательно просмотрите условия каждого из тарифов, выберите подходящий вам. Пополните баланс вашего личного кабинета, воспользовавшись платежными системами, которые предоставляет наша платформа. После поступления средств, инвестируйте в выбранный вами тариф.";
        $languages_text["investing_text_2"]["en"] = "Carefully review the conditions of each of the tariffs, select the one that suits you. Replenish the balance of your personal account using the payment systems provided by our platform. After the receipt of funds, invest in your chosen tariff.";
                
        $languages_text["investing_title_3"]["ru"] = "Создание депозита";
        $languages_text["investing_title_3"]["en"] = "Making a deposit";
        
        $languages_text["investing_text_3"]["ru"] = "Ваши средства будут направлены на общий операционный счёт, где они будут распределены по направлениям для дальнейшей работы.";
        $languages_text["investing_text_3"]["en"] = "Your funds will be directed to the general operating account, where they will be distributed in directions for further work.";
                
        $languages_text["investing_title_4"]["ru"] = "Получение прибыли*";
        $languages_text["investing_title_4"]["en"] = "Receiving a profit*";
        
        $languages_text["investing_text_4"]["ru"] = "Пройдите простую процедуру регистрации на сайте. Для вашего удобства мы не требуем от вас личных данных для верификации - только краткая информация для персонализации пользователя в системе и связи с вами.";
        $languages_text["investing_text_4"]["en"] = "Follow the simple registration procedure on the site. For your convenience, we do not require personal data from you for verification - only brief information for personalizing the user in the system and communicating with you.";
                
        $languages_text["investing_title_5"]["ru"] = "Вывод средств";
        $languages_text["investing_title_5"]["en"] = "Withdraw funds";
        
        $languages_text["investing_text_5"]["ru"] = "Регламент вывода средств составляет 24 часа с момента подачи заявки в личном кабинете, с понедельника по пятницу, в рабочее время (с 09-00 по 21-00 МСК)(либо круглосуточно при наличии онлайн-консультантов).";
        $languages_text["investing_text_5"]["en"] = "The withdrawal procedure is 24 hours from the moment of filing the application in your personal account, from Monday to Friday, during business hours (from 09-00 to 21-00 Moscow time) (or around the clock with online consultants).";
                
        $languages_text["in_day"]["ru"] = "в день";
        $languages_text["in_day"]["en"] = "in a day";
        
        $languages_text["days"]["ru"] = "Дней";
        $languages_text["days"]["en"] = "Days";
        
        ob_start();
        require_once ( COM_PATH . "/pages/investment/view.php" );
        return ob_get_clean();
    }
}
