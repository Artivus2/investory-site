<?php

class comPages_controlIndex {

    static function display() {
        global $url_data;
        require_once ( COM_PATH . "/pages/index/model.php" );

        require_once ( COM_PATH . "/common/investing/control.php" );
        $investing_block = comCommon_controlInvesting::display();

        require_once ( COM_PATH . "/common/paysystem/control.php" );
        $paysystem_block = comCommon_controlPaysystem::display();

        require_once ( COM_PATH . "/invest/calculator/control.php" );
        $calculator = comInvest_controlCalculator::display();
        
        
        $this_language_key = language::lang();

        $languages_text = [];
        $languages_text["slide_button"]["ru"] = "Инвестировать сейчас";
        $languages_text["slide_button"]["en"] = "Invest now";

        $languages_text["slide_title"]["ru"] = "Истинное стремление к саморазвитию";
        $languages_text["slide_title"]["en"] = "True desire for self-development";

        $languages_text["slide_text_1"]["ru"] = "Сделать прибыльное инвестирование максимально доступным для всех категорий граждан во всем мире!";
        $languages_text["slide_text_1"]["en"] = "Make profitable investment as accessible as possible for all categories of citizens around the world!";

        $languages_text["slide_text_2"]["ru"] = "Сделайте вашу торговлю более эффективной!";
        $languages_text["slide_text_2"]["en"] = "Make your trading more efficient!";

        $languages_text["slide_text_3"]["ru"] = "Объединять инвесторов по всему миру в единую систему для максимально эффективной работы.";
        $languages_text["slide_text_3"]["en"] = "Combine investors around the world in a single system for maximum efficiency.";
        
        $languages_text["setion_2_title"]["ru"] = "Мы рады приветствовать Вас на нашей инвестиционной платформе";
        $languages_text["setion_2_title"]["en"] = "We are pleased to welcome you on our investment platform.";
        
        $languages_text["setion_2_text_1"]["ru"] = "Наша компания использует несколько проверенных торговых систем на рынке Форекс. Уменьшение (деверсификация) рисков реализуется посредством использования нескольких (на данный момент 7 ) торговых счетов, что в свою очередь позволяет контролировать риски и просадки на торговых счетах своевременно 24/5. ";
        $languages_text["setion_2_text_1"]["en"] = "Our company uses several proven trading systems in the Forex market. Risk reduction (diversification) is realized through the use of several (currently 7) trading accounts, which in turn allows you to control risks and drawdowns on trading accounts in a timely manner 24/5.";
        
        $languages_text["setion_2_text_2"]["ru"] = "В среднем торговые роботы приносят прибыль порядка 1% , ежедневно по рабочим дням. Таким образом, позволяет в полной мере выплачивать проценты нашим инвесторам в течение срока работы депозита. Тело депозита (сумма инвестиции) включено в ежесуточные выплаты и выплачивается в течении 365 календарных дней(~240 рабочих) равными долями + % в соответствии с тарифным планом.";
        $languages_text["setion_2_text_2"]["en"] = "On average, trading robots generate a profit of about 1%, daily on business days. Thus, it allows us to fully pay interest to our investors during the term of the deposit. The body of the deposit (investment amount) is included in daily payments and is paid out within 365 calendar days (~ 240 workers) in equal shares +% in accordance with the tariff plan.";
        
        $languages_text["setion_2_button"]["ru"] = "О нас";
        $languages_text["setion_2_button"]["en"] = "About";
        
        $languages_text["setion_3_title"]["ru"] = "Наши преимущества";
        $languages_text["setion_3_title"]["en"] = "Our advantages";
        
        $languages_text["setion_3_text"]["ru"] = "Наша миссия - обеспечение роста благосостояния наших инвесторов.";
        $languages_text["setion_3_text"]["en"] = "Our mission is to ensure the growth of wealth of our investors.";
        
        $languages_text["setion_3_list_1"]["ru"] = "Торговля на валютных парах несколькими проверенными торговыми системами";
        $languages_text["setion_3_list_1"]["en"] = "Trading on currency pairs with several proven trading systems";
        
        $languages_text["setion_3_list_2"]["ru"] = "Пониженный риск торговли в виду использования нескольких торговых счетов с разными рисками";
        $languages_text["setion_3_list_2"]["en"] = "Reduced trading risk due to the use of multiple trading accounts with different risks";
        
        $languages_text["setion_3_list_3"]["ru"] = "Ручная торговля валютными парами профессиональными трейдерами";
        $languages_text["setion_3_list_3"]["en"] = "Manual trading in currency pairs by professional traders";
        
        $languages_text["setion_3_list_4"]["ru"] = "Использование только ликвидных инструментов на валютном рынке";
        $languages_text["setion_3_list_4"]["en"] = "Using only liquid instruments in the foreign exchange market";
        

        $languages_text["setion_5_title"]["ru"] = "Наши партнеры";
        $languages_text["setion_5_title"]["en"] = "Our partners";

        $languages_text["setion_6_title"]["ru"] = "Удобный личный кабинет для Вас";
        $languages_text["setion_6_title"]["en"] = "Convenient personal account for you";

        $languages_text["setion_6_text"]["ru"] = "Заработок инвесторов: Регистрация. Пройдите простую процедуру регистрации на сайте. Для вашего удобства мы не требуем от вас личных данных для верификации - только краткая информация для персонализации пользователя в системе и связи с вам";
        $languages_text["setion_6_text"]["en"] = "Earnings for investors: Registration. Follow the simple registration procedure on the site. For your convenience, we do not require you to provide personal data for verification - only brief information to personalize the user in the system and to contact you";

        $languages_text["setion_5_button"]["ru"] = "Зарегистрироваться";
        $languages_text["setion_5_button"]["en"] = "Sign up";
        

        ob_start();
        require_once ( COM_PATH . "/pages/index/view.php" );
        return ob_get_clean();
    }

}
