<div class="section__1">
    <div class="owl-carousel owl-theme">
        <div class="item" style="background-image: url(/templates/images/section-bg-1.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 content__slide">
                        <h1 class="wow zoomIn"><?=$languages_text["slide_title"][$this_language_key]?></h1>
                        <p class="wow zoomIn" data-wow-delay="0.3s"><?=$languages_text["slide_text_1"][$this_language_key]?></p>
                        <a href="/registration" class="btn__green wow jackInTheBox"><?=$languages_text["slide_button"][$this_language_key]?></a>
                    </div>
                </div>  
            </div>
        </div>
        <div class="item" style="background-image: url(/templates/images/section-bg-1.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 content__slide">
                        <h1 class="wow zoomIn"><?=$languages_text["slide_title"][$this_language_key]?></h1>
                        <p class="wow zoomIn" data-wow-delay="0.3s"><?=$languages_text["slide_text_2"][$this_language_key]?></p>
                        <a href="/registration" class="btn__green"><?=$languages_text["slide_button"][$this_language_key]?></a>
                    </div>
                </div>  
            </div>
        </div>
        <div class="item" style="background-image: url(/templates/images/section-bg-1.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 content__slide">
                        <h1 class="wow zoomIn"><?=$languages_text["slide_title"][$this_language_key]?></h1>
                        <p class="wow zoomIn" data-wow-delay="0.3s"><?=$languages_text["slide_text_3"][$this_language_key]?></p>
                        <a href="/registration" class="btn__green"><?=$languages_text["slide_button"][$this_language_key]?></a>
                    </div>
                </div>  
            </div>
        </div>
    </div>
    <div class="container wow zoomIn">
        <div class="row">
            <div class="col-md-12">
                <div class="owl-navigation">
                    <button type="button" role="presentation" class="owl-prev"><i class="fa fa-chevron-left"></i></button>
                    <button type="button" role="presentation" class="owl-next"><i class="fa fa-chevron-right"></i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="section__2">
    <div class="container">
        <div class="row">
            <div class="col-md-12 wow animate bounceInUp">                             
                <h2><?=$languages_text["setion_2_title"][$this_language_key]?></h2>
            </div>                            
        </div>
        <div class="section__content">
            <div class="row">
                <div class="section__content-left col-md-6 wow slideInLeft" >
                    <div class="section__bg-ridge">
                        <div class="img"></div>
                        <!--<img src="images/section-img-2.jpg" alt="Инвестиционная программа">-->
                    </div>
                </div>
                <div class="section__content-right col-md-6 wow slideInRight">
                    <p>
                        <?=$languages_text["setion_2_text_1"][$this_language_key]?>
                    </p>
                    <p>
                        <?=$languages_text["setion_2_text_2"][$this_language_key]?>
                    </p>
                    <a class="btn__border" href="/about"><?=$languages_text["setion_2_button"][$this_language_key]?></a>
                </div>     
            </div>

        </div>
    </div>
</div>


<div class="section__3">
    <div class="container">
        <div class="section__content">
            <div class="row">
                <div class="section__content-text col-md-4 wow slideInLeft">
                    <h2><?=$languages_text["setion_3_title"][$this_language_key]?></h2>
                    <p><?=$languages_text["setion_3_text"][$this_language_key]?></p>
                </div>
                <div class="section__content-list col-12 col-md-8">
                    <div class="section__list-left col-12 col-md-6">
                        <div class="section__content-item wow flipInX">
                            <div class="item__circle">
                                <img src="/templates/images/section-3-icon1.png" alt="">
                            </div>
                            <p><?=$languages_text["setion_3_list_1"][$this_language_key]?></p>
                        </div>
                        <div class="section__content-item wow flipInX">
                            <div class="item__circle">
                                <img src="/templates/images/section-3-icon2.png" alt="">
                            </div>
                            <p><?=$languages_text["setion_3_list_2"][$this_language_key]?></p>
                        </div>
                    </div>
                    <div class="section__list-right col-12  col-md-6">
                        <div class="section__content-item wow flipInX">
                            <div class="item__circle">
                                <img src="/templates/images/section-3-icon3.png" alt="">
                            </div>
                            <p><?=$languages_text["setion_3_list_3"][$this_language_key]?></p>
                        </div>
                        <div class="section__content-item wow flipInX">
                            <div class="item__circle">
                                <img src="/templates/images/section-3-icon4.png" alt="">
                            </div>
                            <p><?=$languages_text["setion_3_list_4"][$this_language_key]?></p>
                        </div>
                    </div>               
                </div>
            </div>
        </div>
    </div>
</div>

<?=$calculator?>

<div class="section__5">
    <h2><?=$languages_text["setion_5_title"][$this_language_key]?></h2>
    <div class="partner">
        <div class="container">
            <div class="row">
                <?if(false):?>
                    <div class="col-md-6 partner__left">
                        <script
                            class="xlrj"
                            type="text/javascript"
                            src="https://my.roboforex.com/en/banner_rotator.js?size=728:90&type=gif&office=1&agentid=xlrj">
                        </script>	
                    </div>
                    <div class="col-md-6 partner__right">
                        <a href="https://www.forex4you.com/?affid=nupf7jn:FXARTINVEST" rel="nofollow">
                            <img src="https://cdn.eglobal-group.com/marketing-materials/banners/web/71e28540a6f6b9271ea2d25000dd2a02.jpg"/>
                        </a>
                    </div>
                <?endif;?>
                
                <div class="col-md-6 partner__left wow zoomIn">
                    <script class="xlrj" type="text/javascript" src="https://my.roboforex.com/ru/banner_rotator.js?size=728:90&type=gif&office=1&agentid=xlrj"></script>
                </div>
                <div class="col-md-6 partner__right wow zoomIn">
                    <a href="https://www.forex4you.com/?affid=nupf7jn:FXARTINVEST" rel="nofollow">
                        <img src="https://cdn.eglobal-group.com/marketing-materials/banners/web/cfdfb40e5f8ca11a692e73870a735161.jpg"/>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="section__6">
    <div class="container-fluid">
        <div class="row">
            <div class="offset-md-7 col-md-5 section__device-relative">
                <div class="section__device"></div>
            </div>
        </div>
        <div class="section__content wow slideInLeft">
            <div class="row">
                <div class="section__content-left col-md-12">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <h2><?=$languages_text["setion_6_title"][$this_language_key]?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <img src="/templates/images/section_6_device_mobile.jpg">
            <div class="row">
                <div class="section__content-left col-md-12">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <p><?=$languages_text["setion_6_text"][$this_language_key]?></p>
                                <a class="btn__border" href="/registration"><?=$languages_text["setion_5_button"][$this_language_key]?></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?=$investing_block?>
<?=$paysystem_block?>
