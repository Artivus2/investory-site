<?php

class comPages_control404 {

    static function display() {
        global $URL;
        header("HTTP/1.0 404 Not Found");
        $URL->alias = "page_404";
        $URL->template = "404";
        $URL->url = "com=pages&view=404";
        $URL->url_type = 404;
        return true;
    }

}
