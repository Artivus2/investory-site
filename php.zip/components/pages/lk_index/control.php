<?php

class comPages_controlLKIndex {

    static function display() {
        global $url_data;
        require_once ( COM_PATH . "/pages/lk_index/model.php" );
        
        

        
        require_once ( COM_PATH . "/common/greeting/control.php" );
        $greeting = comCommon_controlGreeting::display();
        
        require_once ( COM_PATH . "/common/purses/control.php" );
        $purses = comCommon_controlPurses::display();
        
        require_once ( COM_PATH . "/common/referal_link/control.php" );
        $referal_link = comCommon_controlReferallink::display();
        
        require_once ( COM_PATH . "/invest/deposits/model.php" );
        $deposits = comInvest_modelDeposits::deposits();
        $deposits_currency = [];
        foreach ($deposits["deposits"] as $deposit) {
            if($deposit["status"] == 0){
                $deposits_currency[$deposit["currency"]] += $deposit["summa"];
            }
        }
        
        $limit = 10;
        require_once ( COM_PATH . "/invest/deposits/model.php" );
        $list = comInvest_modelDeposits::deposits_history(["limit"=>$limit]);
        
        require_once (COM_PATH . "/pagination/pagination.php" );
        $pagination = Pagination::view($list["count"], $limit);
        
        
        
            
            $this_language_key = language::lang();

            $languages_text = [];
            $languages_text["investions_plans_title"]["ru"] = "Ваши инвестиции";
            $languages_text["investions_plans_title"]["en"] = "Your investment";
            
            $languages_text["table_title"]["ru"] = "История начислений";
            $languages_text["table_title"]["en"] = "Accrual history";
            
            
            $languages_text["table_col_1"]["ru"] = "Депозит №";
            $languages_text["table_col_1"]["en"] = "Deposit No.";
            
            $languages_text["table_col_2"]["ru"] = "Дата начисления";
            $languages_text["table_col_2"]["en"] = "Accrual date";
            
            $languages_text["table_col_3"]["ru"] = "Сумма";
            $languages_text["table_col_3"]["en"] = "Amount";
            
            $languages_text["table_col_4"]["ru"] = "Тариф";
            $languages_text["table_col_4"]["en"] = "Rate";
            
            $languages_text["table_col_5"]["ru"] = "Статус";
            $languages_text["table_col_5"]["en"] = "Status";
            
            
            $languages_text["label_success"]["ru"] = "Начислено";
            $languages_text["label_success"]["en"] = "Accrued";
            
            $languages_text["empty_table"]["ru"] = "Начисления отсутствуют";
            $languages_text["empty_table"]["en"] = "No accruals";
        
            
            
        
        ob_start();
        require_once ( COM_PATH . "/pages/lk_index/view.php" );
        return ob_get_clean();
    }

}
