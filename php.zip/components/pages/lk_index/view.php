
<?= $greeting ?>
<?= $purses ?>
<?= $referal_link ?>

<div class="row">
    <div class="col-sm-4">

        <div class="investions_plans_wallets">

            <h3><?=$languages_text["investions_plans_title"][$this_language_key]?></h3>
            <? foreach (data::currency() as $currency => $currency_text):?>
            <div class="investions_plan_wallets">
                <span class="wallet" data-currency="<?=$currency?>">
                    <?=data::currency_icon($currency);?>
                </span>
                <span class="currency"><?=data::currency_rod($currency);?></span>
                <span class="summa"><?=data::currency_rounding($deposits_currency[$currency], $currency);?></span>
            </div>
            <? endforeach;?>
        
        </div>
    </div>
    <div class="col-sm-8">
        <div class="calendar" data-year="<?= date("Y") ?>" data-month="<?= date("m") - 1 ?>"></div>
    </div>
</div>

<div class="row" id="list">
    <div class="col-sm-12">
        <div class="table_block">
            <h3><?=$languages_text["table_title"][$this_language_key]?></h3>
            <? if (!empty($list["list"])): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th><?=$languages_text["table_col_1"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_2"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_3"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_4"][$this_language_key]?></th>
                            <th><?=$languages_text["table_col_5"][$this_language_key]?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <? foreach ($list["list"] as $statistic): ?>
                            <tr>
                                <td data-label="<?=$languages_text["table_col_1"][$this_language_key]?>">
                                    <?= $statistic["deposit"] ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_2"][$this_language_key]?>">
                                    <?= date::dateFormatView(["datetime" => $statistic["date_created"]]); ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_3"][$this_language_key]?>">
                                    <?= data::currency_rounding($statistic["summa"], $statistic["currency"], true) ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_4"][$this_language_key]?>">
                                    <?= language::lang_text($statistic["plan_name"]) ?>
                                </td>
                                <td data-label="<?=$languages_text["table_col_5"][$this_language_key]?>">
                                    <span class="label label-success"><?=$languages_text["label_success"][$this_language_key]?></span>
                                </td>
                            </tr>
                        <? endforeach; ?>
                    </tbody>
                </table>
                <?= $pagination ?>
            <? else: ?>
                <div class="alert alert-warning">
                    <?=$languages_text["empty_table"][$this_language_key]?>
                </div>
            <? endif; ?>
        </div>
    </div>
</div>