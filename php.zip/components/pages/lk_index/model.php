<?php

class comPages_modelLKIndex {

    
}
 