<?php

class comPages_controlPartnership {
    function display() {
        global $url_data;

        require_once ( COM_PATH . "/common/investing/control.php" );
        $investing_block = comCommon_controlInvesting::display();
        
        require_once ( COM_PATH . "/common/paysystem/control.php" );
        $paysystem_block = comCommon_controlPaysystem::display();
        
        $this_language_key = language::lang();
        
        $languages_text["title"]["ru"] = "Мгновенное вознаграждение";
        $languages_text["title"]["en"] = "Instant reward";
        
        $languages_text["text"]["ru"] = "Выплачивается сразу после приобретения инвестиционного пакета новым инвесторам.";
        $languages_text["text"]["en"] = "HIt is paid immediately after the acquisition of the investment package to new investors.";
        
        
        $languages_text["level_1"]["ru"] = "от депозита 1 уровня";
        $languages_text["level_1"]["en"] = "from a level 1 deposit";
        
        $languages_text["level_2"]["ru"] = "от депозита 2 уровня";
        $languages_text["level_2"]["en"] = "from a level 2 deposit";
        
        $languages_text["level_3"]["ru"] = "от депозита 3 уровня";
        $languages_text["level_3"]["en"] = "from a level 3 deposit";
        
        $languages_text["level_4"]["ru"] = "от депозита 4 уровня";
        $languages_text["level_4"]["en"] = "from a level 4 deposit";
        
        $languages_text["level_5"]["ru"] = "от депозита 5 уровня";
        $languages_text["level_5"]["en"] = "from a level 5 deposit";

        
        
        ob_start();
        require_once ( COM_PATH . "/pages/partnership/view.php" );
        return ob_get_clean();
    }
}
