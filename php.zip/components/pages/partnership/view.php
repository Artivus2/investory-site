<section class="partners">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 partners_levels_wrp">

                <div class="partner_info">
                    <div class="hide_half_circle"></div>
                    <div class="circle">
                        <div class="circle-center">
                            <p><b><?=$languages_text["title"][$this_language_key]?>:</b></p>
                            <p><?=$languages_text["text"][$this_language_key]?></p>
                        </div>
                    </div>
                </div>


                <div class="partners_levels">
                    <div class="partners_level" style="background-color: #84bb25;">
                        <div class="line_horizontal">
                            <div class="line_guide"></div>
                        </div>
                        <div class="number" style="background-color: #84bb25;">
                            <div class="number-2" style="background-color: #ffffff;">
                                <div class="number-3" style="background-color: #84bb25;">
                                    3%
                                </div>
                            </div>
                        </div>
                        <div class="text"><?=$languages_text["level_1"][$this_language_key]?></div>
                    </div>
                    <div class="partners_level" style="background-color: #5fd2f1;">
                        <div class="line_horizontal">
                            <div class="line_guide"></div>
                        </div>
                        <div class="number" style="background-color: #5fd2f1;">
                            <div class="number-2" style="background-color: #ffffff;">
                                <div class="number-3" style="background-color: #5fd2f1;">
                                    1%
                                </div>
                            </div>
                        </div>
                        <div class="text"><?=$languages_text["level_2"][$this_language_key]?></div>
                    </div>
                    <div class="partners_level" style="background-color: #1c1c1c;">
                        <div class="line_horizontal">
                            <div class="line_guide"></div>
                        </div>
                        <div class="number" style="background-color: #1c1c1c;">
                            <div class="number-2" style="background-color: #ffffff;">
                                <div class="number-3" style="background-color: #1c1c1c;">
                                    0.5%
                                </div>
                            </div>
                        </div>
                        <div class="text"><?=$languages_text["level_3"][$this_language_key]?></div>
                    </div>
                    <div class="partners_level" style="background-color: #5299a4;">
                        <div class="line_horizontal">
                            <div class="line_guide"></div>
                        </div>
                        <div class="number" style="background-color: #5299a4;">
                            <div class="number-2" style="background-color: #ffffff;">
                                <div class="number-3" style="background-color: #5299a4;">
                                    0.5%
                                </div>
                            </div>
                        </div>
                        <div class="text"><?=$languages_text["level_4"][$this_language_key]?></div>
                    </div>
                    <div class="partners_level" style="background-color: #d29229;">
                        <div class="line_horizontal">
                            <div class="line_guide"></div>
                        </div>

                        <div class="number" style="background-color: #d29229;">
                            <div class="number-2" style="background-color: #ffffff;">
                                <div class="number-3" style="background-color: #d29229;">
                                    0.3%
                                </div>
                            </div>
                        </div>
                        <div class="text"><?=$languages_text["level_5"][$this_language_key]?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $investing_block ?>
<?= $paysystem_block?>