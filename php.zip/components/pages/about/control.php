<?php

class comPages_controlAbout {
    function display() {
        require_once ( COM_PATH . "/pages/about/model.php" );
       
        
        require_once ( COM_PATH . "/common/investing/control.php" );
        $investing_block = comCommon_controlInvesting::display();
        
        require_once ( COM_PATH . "/common/paysystem/control.php" );
        $paysystem_block = comCommon_controlPaysystem::display();
        
        
 $this_language_key = language::lang();

        $languages_text = [];
        $languages_text["page_title"]["ru"] = "О компании";
        $languages_text["page_title"]["en"] = "About company";
        
        $languages_text["page_title_text"]["ru"] = "О том, что мы делаем, и почему мы выбрали деятельность на Форекс";
        $languages_text["page_title_text"]["en"] = "About what we do and why we chose Forex trading";
        
        $languages_text["graphics_title"]["ru"] = "Мы рады приветствовать Вас на нашей инвестиционной платформе";
        $languages_text["graphics_title"]["en"] = "We are pleased to welcome you on our investment platform";
        
        $languages_text["graphics_text_1"]["ru"] = "В мире бизнеса все работает по конкретной схеме. Появляется идея, разрабатывается бизнес-план, который в процессе своего становления и развития превращается в многообещающий бизнес. Шаг за шагом он проходит стадии становления, активного роста, стабилизации и масштабирования — от идеи к созданию глобальной компании. ";
        $languages_text["graphics_text_1"]["en"] = "In the business world, everything works according to a specific scheme. An idea appears, a business plan is being developed, which in the process of its formation and development turns into a promising business. Step by step, it goes through the stages of formation, active growth, stabilization and scaling - from the idea to creating a global company.";
        
        $languages_text["graphics_text_2"]["ru"] = "Биржа Форекс – это всемирная биржа по обмену валюты или Foreign Exchange. Здесь происходит купля/продажа валютных пар, например EUR/USD. Обьемы торгов на данной бирже составляют триллионы долларов. ";
        $languages_text["graphics_text_2"]["en"] = "Forex Exchange is a global currency exchange or foreign exchange. Here is the purchase / sale of currency pairs, for example EUR / USD. The volume of trading on this exchange is trillions of dollars.";
        
        $languages_text["mission_title"]["ru"] = "Наша миссия";
        $languages_text["mission_title"]["en"] = "Our mission";
        
        $languages_text["mission_text"]["ru"] = "Обеспечение роста благосостояния наших инвесторов. Они получают до 22% в месяц, что больше, чем дает депозит в любом банке. Объединять инвесторов по всему миру в единую систему для максимально эффективной работы. Сделать прибыльное инвестирование максимально доступным для всех категорий граждан во всем мире!";
        $languages_text["mission_text"]["en"] = "Ensuring the growth of wealth of our investors. They receive up to 22% per month, which is more than the deposit at any bank. Combine investors around the world in a single system for maximum efficiency. Make profitable investment as accessible as possible for all categories of citizens around the world!";
                
        $languages_text["perspective_title"]["ru"] = "Перспективы развития";
        $languages_text["perspective_title"]["en"] = "Development prospects";
        
        $languages_text["perspective_text"]["ru"] = "Компания FX ARTINVEST преследует долговременные стратегические цели для создания в мире цивилизованного, социально-ориентированного общества, характеризующегося высоким качеством жизни населения, в основе которого лежит смешанная экономика, предполагающая не только совместное эффективное функционирование различных форм собственности, но и интернационализацию рынка товаров, рабочей силы и капитала. ";
        $languages_text["perspective_text"]["en"] = "FX ARTINVEST pursues long-term strategic goals for creating a civilized, socially-oriented society in the world characterized by a high quality of life, based on a mixed economy that assumes not only the joint effective functioning of various forms of ownership, but also the internationalization of the market for goods, labor and capital.";
        
        
        ob_start();
        require_once ( COM_PATH . "/pages/about/view.php" );
        return ob_get_clean();
    }
    
    function scripts() {
        $return = [];
        $return[] = "<script src='/templates/script/chart.min.js' type='text/javascript'></script> ";
        ob_start();
        require_once ( COM_PATH . "/pages/about/scripts.php" );
        $return[] = ob_get_clean();
        return implode("\n", $return);
    }
    
}
