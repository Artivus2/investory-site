<script>
    $(function () {
        // Graphick plagin Charts
        var config = {
            type: 'line',
            data: {
                labels: ['Янв 2019', 'Фев 2019', 'Март 2019', 'Апр 2019', 'Май 2019', 'Июнь 2019', 'Июль 2019'],
                datasets: [{
                        label: '',
                        backgroundColor: 'rgba(89, 168, 26, 0.05)',
                        borderColor: 'rgba(89, 168, 26, 1)',
                        lineTension: 0,
                        data: [
                            18, 16, 30, 35.66, 30, 42, 38, 45, 60, 0
                        ],
                        borderWidth: 2,
                        fill: true,
                        fillColor: "rgba(0, 0, 0, 1)",
                        pointBorderColor: 'rgba(89, 168, 26, 1)',
                        pointBackgroundColor: '#ffffff',
                        pointRadius: 10,
                        pointHoverRadius: 20,
                        pointHitRadius: 40,
                        pointBorderWidth: 2,
                        strokeColor: "rgba(255.255,255,1)",
                        pointStrokeColor: "rgba(255,255,255,1.00)",
                    }]
            },
            options: {
                maintainAspectRatio: false,
                legend: {
                    display: false,
                    position: 'top',
                    labels: {
                        boxWidth: 80,
                        fontColor: 'black'
                    }
                },
                responsive: true,
                title: {
                    display: false,
                    text: 'Chart.js Line Chart'
                },
                tooltips: {
                    intersect: false,
                    yPadding: 10,
                    xPadding: 14,
                    x: 100,
                    y: 100,
                    caretSize: 6,
                    caretX: 70,
                    caretY: 70,
                    caretHeight: 200,
                    xAlign: 'bottom',
                    backgroundColor: 'rgba(89, 168, 26, 1)',
                    titleFontColor: '#000000',
                    titleFontSize: 0,
                    titleMarginBottom: -4,
                    bodyFontSize: 17,
                    bodyFontStyle: '600',
                    bodySpacing: 20,
                    bodyFontFamily: 'Roboto',
                    cornerRadius: 12,
                    bodyFontColor: '#ffffff',
                    borderColor: 'rgba(0,0,0,1)',
                    borderWidth: 1,
                    footerMarginTop: 10,
                    footerMarginBottom: 100,
                    footerSpacing: 50,
                    callbacks: {
                        callback: function (value) {
                            if (value == 0 || value == 20 || value == 40 || value == 60) {
                                return value + '%';
                            }
                        },
                        labelColor: function (tooltipItem, chart) {
                            return {
                                borderColor: 'rgb(255, 0, 0)',
                                backgroundColor: 'rgb(255, 0, 0)'
                            };
                        },
                        labelTextColor: function (tooltipItem, chart) {
                            return '#543453';
                        },
                        label: function (tooltipItems, data) {
                            return tooltipItems.yLabel + "%";
                        }
                    }
                },
                hover: {
                    mode: 'nearest',
                    intersect: true
                },
                scales: {
                    xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: false,
                                labelString: 'Month'
                            },
                            gridLines: {
                                color: "rgba(0, 0, 0, 0)",
                                drawOnChartArea: true,
                                lineWidth: 7,
                            },
                            tooltipFormat: 'll HH:mm',
                            ticks: {
                                fontSize: 13,
                                fontColor: '#a0acb9',
                                tickMarkLength: 30,
                            }
                        }],
                    yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: false,
                                labelString: 'Value'
                            },
                            ticks: {
                                beginAtZero: true,
                                callback: function (value) {
                                    if (value == 0 || value == 20 || value == 40 || value == 60) {
                                        return value + '%      ';
                                    }
                                },
                                min: 0,
                                fontSize: 20,
                                fontColor: '#a0acb9',
                                tickMarkLength: 30,
                            }
                        }]
                }
            }
        };

        Chart.defaults.global.defaultFontFamily = "Roboto";
        Chart.defaults.global.defaultFontSize = 15;

        var ctx = document.getElementById('line-chart').getContext('2d');
        var lineChart = new Chart(ctx, config);

        var originalStroke = ctx.stroke;
        ctx.stroke = function () {
            ctx.save();
            ctx.shadowColor = 'rgba(89, 168, 26, 0.4)';
            ctx.shadowBlur = 20;
            ctx.shadowOffsetX = -0;
            ctx.shadowOffsetY = -10;
            originalStroke.apply(this, arguments)
            ctx.restore();
        }

    })

</script>

