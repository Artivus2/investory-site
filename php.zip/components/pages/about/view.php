<div class="breadcrumb company">
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 class="breadcrumb__title"><?=$languages_text["page_title"][$this_language_key]?></h2>
                <p class="breadcrumb__text"><?=$languages_text["page_title_text"][$this_language_key]?></p>
            </div>
        </div>
    </div>
</div>
<div class="about__graphics">
    <div class="container">
        <div class="row">
            <div class="col-12 no-gutters">
                <h3><?=$languages_text["graphics_title"][$this_language_key]?></h3>
            </div>
        </div>

        <div class="section__content">
            <div class="row">

                <div class="col-12 col-md-6 no-gutters">
                    <p>
                        <?=$languages_text["graphics_text_1"][$this_language_key]?>
                    </p>
                </div>
                <div class="col-12 col-md-6 no-gutters">
                    <p>
                        <?=$languages_text["graphics_text_2"][$this_language_key]?>
                    </p>
                </div>
            </div> 
            <div class="graphics">
                <div class="graphics_insert">
                    <canvas id="line-chart" height="266"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="about__mission">
    <div class="container">
        <div class="section__content"> 
            <div class="row">
                <div class="col-12 col-sm-7 col-lg-7">
                    <h3><?=$languages_text["mission_title"][$this_language_key]?></h3>
                    <p><?=$languages_text["mission_text"][$this_language_key]?></p>
                </div>
                <div class="col-12 col-sm-5 col-lg-4">
                    <img src="/templates/images/about_mission.png" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<div class="about__perspective">
    <div class="container">
        <div class="col-lg-12">
            <h3><?=$languages_text["perspective_title"][$this_language_key]?></h3>
        </div>
        <div class="section__content">
            <div class="row">
                <div class="col-12 col-lg-6 col-md-6 col-xl-6">
                    <p><?=$languages_text["perspective_text"][$this_language_key]?></p>
                </div>
                <div class="col-12 col-lg-6 col-md-6 offset-xl-1 col-xl-5">
                    <div class="about__perspective-bg">
                        <div class="about__perspective-img"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?= $investing_block ?>
<?=$paysystem_block?>