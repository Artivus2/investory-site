<?php

class comPages_modelAbout {

}
