<?php

class comPages_controlFaq {
    function display() {
        global $url_data;


        require_once ( COM_PATH . "/common/investing/control.php" );
        $investing_block = comCommon_controlInvesting::display();
        
        require_once ( COM_PATH . "/common/paysystem/control.php" );
        $paysystem_block = comCommon_controlPaysystem::display();
        
        $this_language_key = language::lang();
        
        $languages_text["page_title"]["ru"] = "Вопросы и ответы";
        $languages_text["page_title"]["en"] = "Our mission";
        
        $languages_text["page_title_text"]["ru"] = "Здесь, в разделе FAQ, вы можете найти ответы на наиболее часто задаваемые вопросы. ";
        $languages_text["page_title_text"]["en"] = "Ensuring the growth of wealth of our investors. They receive up to 22% per month, which is more than the deposit at any bank. Combine investors around the world in a single system for maximum efficiency. Make profitable investment as accessible as possible for all categories of citizens around the world!";
                
        
        $languages_text["question_1"]["ru"] = "С какими платежными системами вы работаете?";
        $languages_text["question_1"]["en"] = "What payment systems do you work with?";
        
        $languages_text["answer_1"]["ru"] = "Мы принимаем : Яндекс Деньги, QIWI, банковские карты, Bitcoin, AdvCash, Payeer, Perfect Money";
        $languages_text["answer_1"]["en"] = "We accept: Yandex Money, QIWI, bank cards, Bitcoin, AdvCash, Payeer, Perfect Money";
                
        $languages_text["question_2"]["ru"] = "Что нужно, что бы начать инвестировать и получать прибыль?";
        $languages_text["question_2"]["en"] = "What is needed to start investing and make a profit?";
        
        $languages_text["answer_2"]["ru"] = "Зарегистрироваться на сайте, пополнить баланс кабинета одной из платежных систем, с которыми сотрудничает компания, выбрать подходящий инвестиционный план, инвестировать и получать прибыль.";
        $languages_text["answer_2"]["en"] = "Register on the site, replenish the account balance of one of the payment systems with which the company cooperates, choose the appropriate investment plan, invest and make a profit.";
        
        $languages_text["question_3"]["ru"] = "Какие средства вы используете для безопасности?";
        $languages_text["question_3"]["en"] = "What tools do you use for security?";
        
        $languages_text["answer_3"]["ru"] = "Мы используем ДДоС защиту а так же SSL сертификат, резервное копирование данных и БД";
        $languages_text["answer_3"]["en"] = "We use DDoS protection as well as SSL certificate, data backup and database";
        
        $languages_text["question_4"]["ru"] = "Возможно ли самостоятельно сменить платежные реквизиты?";
        $languages_text["question_4"]["en"] = "Is it possible to independently change the payment details?";
        
        $languages_text["answer_4"]["ru"] = "Нет, для смены реквизитов необходимо обратиться в техническую поддержку.";
        $languages_text["answer_4"]["en"] = "No, to change the details you need to contact technical support.";
        
        $languages_text["question_5"]["ru"] = "Как восстановить пароль?";
        $languages_text["question_5"]["en"] = "How to recover a password?";
        
        $languages_text["answer_5"]["ru"] = "Вам необходимо пройти процедуру восстановления пароля. Это можно сделать при входе в кабинет. Вам будет отправлено письмо с информацией для восстановления.";
        $languages_text["answer_5"]["en"] = "You need to go through the password recovery procedure. This can be done at the entrance to the office. You will be sent an email with recovery information.";
               
        $languages_text["question_6"]["ru"] = "Сколько я могу открыть депозитов?";
        $languages_text["question_6"]["en"] = "How much can I open deposits?";
        
        $languages_text["answer_6"]["ru"] = "Разрешено иметь неограниченое количество депозитов на каждый из тарифных планов. Вы сможете открыть новый депозит в любое время.";
        $languages_text["answer_6"]["en"] = "It is allowed to have an unlimited number of deposits for each of the tariff plans. You can open a new deposit at any time.";
        
        $languages_text["question_7"]["ru"] = "Какая минимальная сумма депозита?";
        $languages_text["question_7"]["en"] = "What is the minimum deposit amount?";
        
        $languages_text["answer_7"]["ru"] = "Минимальный объем инвестиций 1000 руб или эквивалент в биткоине.";
        $languages_text["answer_7"]["en"] = "The minimum investment is 1000 rubles or the equivalent in bitcoin.";
        
        $languages_text["question_8"]["ru"] = "Какой максимальный объем инвестиции?";
        $languages_text["question_8"]["en"] = "What is the maximum investment?";
        
        $languages_text["answer_8"]["ru"] = "Максимальный объем инвестиции 1000000 руб или эквивалент в биткоине";
        $languages_text["answer_8"]["en"] = "The maximum investment amount is 1,000,000 rubles or the equivalent in bitcoin";
        
        $languages_text["question_9"]["ru"] = "Существует ли комиссия на вывод?";
        $languages_text["question_9"]["en"] = "Is there a withdrawal commission?";
        
        $languages_text["answer_9"]["ru"] = "Да, комиссия на вывод средств составляет до 2.5% в не зависимости от выбранной платежной системы.";
        $languages_text["answer_9"]["en"] = "Yes, the commission for withdrawing funds is up to 2.5%, regardless of the selected payment system.";
        
        ob_start();
        require_once ( COM_PATH . "/pages/faq/view.php" );
        return ob_get_clean();
    }
}
