<div class="breadcrumb faq">
    <div class="container">
        <div class="row">
            <div class="col">
                <h2 class="breadcrumb__title"><?=$languages_text["page_title"][$this_language_key]?></h2>
                <p class="breadcrumb__text"><?=$languages_text["page_title_text"][$this_language_key]?></p>
            </div>
        </div>
    </div>
</div>
<section class="faq">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 faq-col">
                <div class="faq-select">
                    <div class="item active" data-id="1">
                        <div><?=$languages_text["question_1"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob active" data-id="1">
                        <?=$languages_text["answer_1"][$this_language_key]?>
                    </div>
                    
                    <div class="item" data-id="2">
                        <div><?=$languages_text["question_2"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="2">
                        <?=$languages_text["answer_2"][$this_language_key]?>
                    </div>
                    
                    <div class="item" data-id="3">
                        <div><?=$languages_text["question_3"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="3">
                       <?=$languages_text["answer_3"][$this_language_key]?>
                    </div>
                    
                    <div class="item" data-id="4">
                        <div><?=$languages_text["question_4"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="4">
                        <?=$languages_text["answer_4"][$this_language_key]?>
                    </div>
                    
                    <div class="item" data-id="5">
                        <div><?=$languages_text["question_5"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="5">
                        <?=$languages_text["answer_5"][$this_language_key]?>
                    </div>
                    
                    <div class="item" data-id="6">
                        <div><?=$languages_text["question_6"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="6">
                        <?=$languages_text["answer_6"][$this_language_key]?>
                    </div>
                    
                    <div class="item" data-id="7">
                        <div><?=$languages_text["question_7"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="7">
                        <?=$languages_text["answer_7"][$this_language_key]?>
                    </div>
                    
                    <div class="item" data-id="8">
                        <div><?=$languages_text["question_8"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="8">
                        <?=$languages_text["answer_8"][$this_language_key]?>
                    </div>
                    <div class="item" data-id="9">
                        <div><?=$languages_text["question_9"][$this_language_key]?></div>
                        <div><i class="far fa-angle-right"></i></div>
                    </div>
                    <div class="text-mob" data-id="9">
                       <?=$languages_text["answer_9"][$this_language_key]?>
                    </div>
                </div>
                <div class="text">
                    <div class="active" data-id="1">
                        <?=$languages_text["answer_1"][$this_language_key]?>
                    </div>
                    <div data-id="2">
                        <?=$languages_text["answer_2"][$this_language_key]?>
                    </div>
                    <div data-id="3">
                        <?=$languages_text["answer_3"][$this_language_key]?>
                    </div>
                    <div data-id="4">
                        <?=$languages_text["answer_4"][$this_language_key]?>
                    </div>
                    <div data-id="5">
                        <?=$languages_text["answer_5"][$this_language_key]?>
                    </div>
                    <div data-id="6">
                        <?=$languages_text["answer_6"][$this_language_key]?>
                    </div>
                    <div data-id="7">
                        <?=$languages_text["answer_7"][$this_language_key]?>
                    </div>
                    <div data-id="8">
                        <?=$languages_text["answer_8"][$this_language_key]?>
                    </div>
                    <div data-id="9">
                        <?=$languages_text["answer_9"][$this_language_key]?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?=$investing_block?>
<?=$paysystem_block?>