<? if ($countpages > 1): ?>
    <div class="pagination">
        <ul>
            <? for ($n = 1; $n <= $countpages; $n++): ?>
                <? if ($n <= $page - 4 && $page != 5 && $page != 6): ?>
                    <? if (!$other_prev): ?>
                        <li class="1"><a title="страница 1" href="<?= $link ?>page=1" >1</a></li>
                        <li>...</li>
                        <? $other_prev = true; ?>
                    <? endif; ?>
                <? elseif ($n >= $page + 4 && $page != $countpages-5 && $page != $countpages-6): ?>
                    <? if (!$other_next): ?>
                        <li>...</li>
                        <li class="<?= $countpages; ?>"><a title="страница <?= $countpages; ?>" href="<?= $link ?>page=<?= $countpages; ?>" ><?= $countpages; ?></a></li>
                        <? $other_next = true; ?>
                    <? endif; ?>
                <? else: ?>
                    <? if ($n == $page || (empty($page) && $n == 1 )): ?> 
                        <li class="<?= $n; ?> active"><a title="страница <?= $n; ?>" href="<?= $link ?>page=<?= $n; ?>" ><?= $n; ?></a></li>
                        <? else: ?>
                        <li class="<?= $n; ?>"><a title="страница <?= $n; ?>" href="<?= $link ?>page=<?= $n; ?>" ><?= $n; ?></a></li>
                    <? endif; ?>
                <? endif; ?>

            <? endfor; ?>

        </ul>
    </div>
<? endif; ?>