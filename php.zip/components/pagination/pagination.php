<?php

class Pagination {
    function view($count, $countview = 5, $dop_class = "", $url = null) {
        $get = "";
        $page = (int) $_GET['page'];
        $link = (!empty($url)) ? controller::delete_get_url(array("page" => 1), $url) : controller::delete_get_url(array("page" => 1));
        $query_str = parse_url($link);
        $thisPage = (isset($page)) ? $page : 1;

        $start_row = ($countview * $thisPage - $countview) + 1;
        $end_row = ($countview * $thisPage > $count) ? $count : $countview * $thisPage;

        //сколько в бд пропустить
        $startP = 1;
        if ($page != 0) {
            $prevP = $page - 1;
            $prev = $link . 'page=' . $prevP;
        }
        $countpages = ceil($count / $countview);
        $link = ($query_str["query"]) ? $link . '&' : $link . "?";
        ob_start();
        require ( COM_PATH . "/pagination/view.php" );
        return ob_get_clean();
    }
}
?>
