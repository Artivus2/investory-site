<?php

class comMenu_controlFooter_menu {

    function display() {
        global $url_data;
        require_once ( COM_PATH . "/menu/footer_menu/model.php" );
       
        ob_start();
        require_once ( COM_PATH . "/menu/footer_menu/view.php" );
        $this->content = ob_get_clean();
    }

}
