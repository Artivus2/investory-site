<ul class="rd-navbar-nav">
    <? foreach ($types_publication as $type): ?>
        <li class="<? if ($url_data["alias"] == $type['sysname']) echo 'active'; ?>">
            <a href="<?=BASEURL?>/<?= $type['sysname'] ?>"><?= $type['name'] ?></a>
        </li>
    <? endforeach; ?>
</ul>