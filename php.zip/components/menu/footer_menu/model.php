<?php
class comMenu_modelFooter_menu {
    

    
}
