<ul class="header__menu-nav-list">
    <ul class="header__menu-mobile">
        <button class="close-menu"></button>
        <li class="top__header-left-item"><a href="#" class="top__header-left-item-active">Главная</a></li>
        <li class="top__header-left-item"><a href="#">О компании</a></li>
        <li class="top__header-left-item"><a href="#">Инвестиции</a></li>
        <li class="top__header-left-item"><a href="#">Партнеру</a></li>
        <li class="top__header-left-item"><a href="#">Вебинары</a></li>
        <li class="top__header-left-item"><a href="#">Контакты</a></li>
        <li><div class="hr"></div></li>
    </ul>
    <li class="nav__item">
        <a href="#" <? if ($URL->url == "com=pages&view=webinars") echo "nav__item-active" ?>>Вебинары</a>
    </li>
    <li class="nav__item">
        <a href="/news" <? if ($URL->url == "com=blogs&view=list&category=1") echo "nav__item-active" ?>>Новости</a>
    </li>
    <li class="nav__item">
        <a href="/faq" <? if ($URL->url == "com=pages&view=faq") echo "nav__item-active" ?>>faq</a>
    </li>
    <li class="nav__item">
        <a href="/conditions" <? if ($URL->url == "com=pages&view=conditions") echo "nav__item-active" ?>>Условия использования</a>
    </li>
</ul> 