<?php

class comMenu {

    public $act = null;
    public $view = null;
    public $id = null;
    public $model = null;
    public $content = null;
    public $content_head = null;

    function __construct($get) {
        $this->act = $get['act'];
        $this->view = $get['view'];
        $this->id = $get['id'];
     

        if (isset($this->act)) {
            switch ($this->act) {


            }
        }

        if (isset($this->view)) {
            switch ($this->view) {
                case "top_menu":
                    require_once ( COM_PATH . "/menu/top_menu/control.php" );
                    return comMenu_controlTop_menu::display();
                    break;
                case "header_menu":
                    require_once ( COM_PATH . "/menu/header_menu/control.php" );
                    return comMenu_controlHeader_menu::display();
                    break;
                case "user_menu":
                    require_once ( COM_PATH . "/menu/user_menu/control.php" );
                    return comMenu_controlUser_menu::display();
                    break;
            }
        }
    }

}
