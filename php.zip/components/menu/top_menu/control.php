<?php

class comMenu_controlTop_menu {

    function display() {
        global $URL;
        ob_start();
        require_once ( COM_PATH . "/menu/top_menu/view.php" );
        $this->content = ob_get_clean();
    }

}
