<div class="top__header-left col-lg-6">
    <ul class="top__header-left-list">
        <li class="top__header-left-item">
            <a href="/" class="<? if ($URL->url == "com=pages&view=index") echo "top__header-left-item-active" ?>">Главная</a>
        </li>
        <li class="top__header-left-item">
            <a href="/about_us"  class="<? if ($URL->url == "com=pages&view=about") echo "top__header-left-item-active" ?>">О компании</a>
        </li>
        <li class="top__header-left-item">
            <a href="#"  class="<? if ($URL->url == "com=pages&view=investion") echo "top__header-left-item-active" ?>">Инвестиции</a>
        </li>
        <li class="top__header-left-item">
            <a href="#"  class="<? if ($URL->url == "com=pages&view=partner") echo "top__header-left-item-active" ?>">Партнеру</a>
        </li>
        <li class="top__header-left-item">
            <a href="/contacts"  class="<? if ($URL->url == "com=pages&view=contacts") echo "top__header-left-item-active" ?>">Контакты</a>
        </li>
    </ul>
</div>
<div class="top__header-right offset-lg-2 col-lg-4">
    <div class="nav-toogle">
        <span></span>
        <span></span>
        <span></span>
    </div>
    <div class="top__header-right-board">
        <div class="dropdown">
            <div class="dropbtn">Русский</div>
            <div class="dropdown-content">
                <a href="#">English</a>
            </div>
        </div>
        <div class="top__header-right-lk">
            <? if (!empty($_SESSION["user"])): ?>
                <a href="/lk" class="cabinet">
                    <img src="/templates/images/header-icon-unclock.png" alt=""/>
                    Личный кабинет
                </a>
            <? else: ?>
                <a href="/login" class="cabinet">
                    <img src="/templates/images/header-icon-unclock.png" alt=""/>
                    Личный кабинет
                </a>
            <? endif; ?>
        </div>
    </div>

</div>