<?php

class comMenu_modelTop_menu {
    
    function list_types() {
        $sql = "SELECT * FROM `types` ORDER BY `order` ASC";
        $types = DB::select($sql, "all");
        
        return $types;
    }
    
    
    
}
