<aside class="col-md-3 sidebar">
    <div class="sidebar_mobile_insert">
        <button class="close-menu"></button>
        <div class="sidebar__logo">
            <a href="/lk">
                <?if($this_language_key == "en"):?>
                    <img src="/templates/images/logo_en.png" alt="">
                <?else:?>
                    <img src="/templates/images/logo.png" alt="">
                <?endif;?>
            </a>
        </div>

        <ul class="sidebar_menu">
            
            <li class="<?if($URL->alias == "lk") echo "active";?>" >
                <a href="/lk">
                    <i class="fal fa-th-large"></i>
                    <?= $languages_text["home"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "refill") echo "active";?>">
                <a href="/refill">
                    <i class="fal fa-piggy-bank"></i>
                    <?= $languages_text["refill"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "withdraw") echo "active";?>">
                <a href="/withdraw">
                    <i class="fal fa-credit-card"></i>
                    <?= $languages_text["withdraw"][$this_language_key] ?>
                </a>
            </li>
            <li class="">
                <a href="/deposits#form">
                    <i class="fal fa-wallet"></i>
                    <?= $languages_text["new_deposit"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "deposits") echo "active";?>">
                <a href="/deposits#list">
                    <i class="fal fa-receipt"></i>
                    <?= $languages_text["list_deposits"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "deposits_history") echo "active";?>">
                <a href="/deposits_history">
                    <i class="fal fa-list-ul"></i>
                    <?= $languages_text["deposits_history"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "transfers") echo "active";?>">
                <a href="/transfers">
                    <i class="fal fa-retweet"></i>
                    <?= $languages_text["transfers"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "referals") echo "active";?>">
                <a href="/referals">
                    <i class="fal fa-user-friends"></i>
                    <?= $languages_text["referals"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "referals_history") echo "active";?>">
                <a href="/referals_history">
                    <i class="fal fa-list-alt"></i>
                    <?= $languages_text["referals_history"][$this_language_key] ?>
                </a>
            </li>
            <li class="divider"></li>
            <li class="<?if($URL->alias == "trade") echo "active";?>">
                <a href="/trade">
                    <i class="fal fa-coins"></i>
                    <?= $languages_text["trade"][$this_language_key] ?>
                </a>
            </li>
            <li class="<?if($URL->alias == "analytics") echo "active";?>">
                <a href="/analytics">
                    <i class="fal fa-chart-line"></i>
                    <?= $languages_text["analytics"][$this_language_key] ?>
                </a>
            </li>
        </ul>
    </div>
</aside>