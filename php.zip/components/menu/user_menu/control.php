<?php

class comMenu_controlUser_menu {

    function display() {
        global $URL;
      
        if(empty($_SESSION["user"]["id"])){
            return "";
        }

        require_once ( COM_PATH . "/invest/purses/control.php" );
        $purses = comInvest_controlPurses::display();

        $this_language_key = language::lang();

        $languages_text = [];
        $languages_text["home"]["ru"] = "Главная";
        $languages_text["home"]["en"] = "Home";

        $languages_text["refill"]["ru"] = "Пополнение";
        $languages_text["refill"]["en"] = "Replenishment";

        $languages_text["withdraw"]["ru"] = "Вывод средств";
        $languages_text["withdraw"]["en"] = "Withdraw funds";

        $languages_text["new_deposit"]["ru"] = "Создать депозит";
        $languages_text["new_deposit"]["en"] = "Create deposit";

        $languages_text["list_deposits"]["ru"] = "Мои депозиты";
        $languages_text["list_deposits"]["en"] = "My deposits";

        $languages_text["deposits_history"]["ru"] = "История начислений";
        $languages_text["deposits_history"]["en"] = "Accrual history";            

        $languages_text["transfers"]["ru"] = "Внутренний перевод";
        $languages_text["transfers"]["en"] = "Internal translation";


        $languages_text["referals"]["ru"] = "Мои рефералы";
        $languages_text["referals"]["en"] = "My referrals";


        $languages_text["referals_history"]["ru"] = "История реферальных";
        $languages_text["referals_history"]["en"] = "Referral History";


        $languages_text["trade"]["ru"] = "Торговля";
        $languages_text["trade"]["en"] = "Trade"; 

        $languages_text["analytics"]["ru"] = "Аналитика";
        $languages_text["analytics"]["en"] = "Analytics";

        ob_start();
        require_once ( COM_PATH . "/menu/user_menu/view.php" );
        $this->content = ob_get_clean();
    }

}
